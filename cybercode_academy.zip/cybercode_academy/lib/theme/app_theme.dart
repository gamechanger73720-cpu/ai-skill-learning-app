import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// A class that contains all theme configurations for the application.
/// Implements Refined Cyberpunk Minimalism design system for educational mobile applications.
class AppTheme {
  AppTheme._();

  // Cyberpunk Color Palette - Neon-Accented Dark Professional
  static const Color primaryCyan =
      Color(0xFF00F5FF); // Electric cyan for primary actions
  static const Color hotPink = Color(0xFFFF1493); // Hot pink for achievements
  static const Color neonGreen =
      Color(0xFF39FF14); // Neon green for success states
  static const Color deepSpaceBlue =
      Color(0xFF0A0A0F); // Deep space blue-black background
  static const Color elevatedDark =
      Color(0xFF1A1A2E); // Elevated dark blue-gray for surfaces
  static const Color pureWhite =
      Color(0xFFFFFFFF); // Pure white for primary text
  static const Color lightGray =
      Color(0xFFB0B0B0); // Light gray for secondary text
  static const Color brightRed = Color(0xFFFF4444); // Bright red for errors
  static const Color amberOrange =
      Color(0xFFFFB347); // Amber orange for warnings
  static const Color brightMint =
      Color(0xFF00FF88); // Bright mint green for confirmations

  // Additional theme colors
  static const Color cardDark = Color(0xFF1E1E1E);
  static const Color dialogDark = Color(0xFF2D2D2D);
  static const Color shadowCyan = Color(0x1A00F5FF); // Cyberpunk-tinted shadows
  static const Color dividerCyan =
      Color(0x4D00F5FF); // Cyan dividers at 30% opacity
  static const Color borderCyan =
      Color(0x4D00F5FF); // Cyan borders at 30% opacity

  // Text emphasis colors for dark theme
  static const Color textHighEmphasisDark = Color(0xDEFFFFFF); // 87% opacity
  static const Color textMediumEmphasisDark = Color(0x99FFFFFF); // 60% opacity
  static const Color textDisabledDark = Color(0x61FFFFFF); // 38% opacity

  /// Dark theme - Primary theme for cyberpunk educational app
  static ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    colorScheme: ColorScheme(
      brightness: Brightness.dark,
      primary: primaryCyan,
      onPrimary: deepSpaceBlue,
      primaryContainer: primaryCyan.withValues(alpha: 0.2),
      onPrimaryContainer: pureWhite,
      secondary: hotPink,
      onSecondary: deepSpaceBlue,
      secondaryContainer: hotPink.withValues(alpha: 0.2),
      onSecondaryContainer: pureWhite,
      tertiary: neonGreen,
      onTertiary: deepSpaceBlue,
      tertiaryContainer: neonGreen.withValues(alpha: 0.2),
      onTertiaryContainer: pureWhite,
      error: brightRed,
      onError: pureWhite,
      surface: elevatedDark,
      onSurface: pureWhite,
      onSurfaceVariant: lightGray,
      outline: borderCyan,
      outlineVariant: dividerCyan,
      shadow: shadowCyan,
      scrim: deepSpaceBlue.withValues(alpha: 0.8),
      inverseSurface: pureWhite,
      onInverseSurface: deepSpaceBlue,
      inversePrimary: primaryCyan,
    ),
    scaffoldBackgroundColor: deepSpaceBlue,
    cardColor: elevatedDark,
    dividerColor: dividerCyan,

    // AppBar Theme - Cyberpunk styling
    appBarTheme: AppBarTheme(
      backgroundColor: deepSpaceBlue,
      foregroundColor: pureWhite,
      elevation: 0,
      shadowColor: shadowCyan,
      surfaceTintColor: Colors.transparent,
      titleTextStyle: GoogleFonts.orbitron(
        fontSize: 20,
        fontWeight: FontWeight.w700,
        color: pureWhite,
        letterSpacing: 0.5,
      ),
      iconTheme: const IconThemeData(
        color: primaryCyan,
        size: 24,
      ),
      actionsIconTheme: const IconThemeData(
        color: primaryCyan,
        size: 24,
      ),
    ),

    // Card Theme - Elevated surfaces with subtle glow
    cardTheme: CardTheme(
      color: elevatedDark,
      elevation: 4.0,
      shadowColor: shadowCyan,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0),
        side: BorderSide(
          color: borderCyan,
          width: 1.0,
        ),
      ),
      margin: const EdgeInsets.all(8.0),
    ),

    // Bottom Navigation - Cyberpunk navigation rail
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: elevatedDark,
      selectedItemColor: primaryCyan,
      unselectedItemColor: lightGray,
      selectedLabelStyle: GoogleFonts.inter(
        fontSize: 12,
        fontWeight: FontWeight.w500,
        letterSpacing: 0.4,
      ),
      unselectedLabelStyle: GoogleFonts.inter(
        fontSize: 12,
        fontWeight: FontWeight.w400,
        letterSpacing: 0.4,
      ),
      type: BottomNavigationBarType.fixed,
      elevation: 8.0,
    ),

    // Navigation Bar Theme - Modern bottom navigation
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: elevatedDark,
      indicatorColor: primaryCyan.withValues(alpha: 0.2),
      surfaceTintColor: Colors.transparent,
      shadowColor: shadowCyan,
      elevation: 8.0,
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return GoogleFonts.inter(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: primaryCyan,
            letterSpacing: 0.4,
          );
        }
        return GoogleFonts.inter(
          fontSize: 12,
          fontWeight: FontWeight.w400,
          color: lightGray,
          letterSpacing: 0.4,
        );
      }),
      iconTheme: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return const IconThemeData(
            color: primaryCyan,
            size: 24,
          );
        }
        return const IconThemeData(
          color: lightGray,
          size: 24,
        );
      }),
    ),

    // Floating Action Button - Primary action with pulsing effect
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: primaryCyan,
      foregroundColor: deepSpaceBlue,
      elevation: 8.0,
      focusElevation: 12.0,
      hoverElevation: 12.0,
      highlightElevation: 16.0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.0),
      ),
    ),

    // Button Themes - Cyberpunk styling
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        foregroundColor: deepSpaceBlue,
        backgroundColor: primaryCyan,
        elevation: 4.0,
        shadowColor: shadowCyan,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0),
        ),
        textStyle: GoogleFonts.inter(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.5,
        ),
      ),
    ),

    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: primaryCyan,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        side: const BorderSide(color: primaryCyan, width: 2.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0),
        ),
        textStyle: GoogleFonts.inter(
          fontSize: 16,
          fontWeight: FontWeight.w500,
          letterSpacing: 0.5,
        ),
      ),
    ),

    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: primaryCyan,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8.0),
        ),
        textStyle: GoogleFonts.inter(
          fontSize: 16,
          fontWeight: FontWeight.w500,
          letterSpacing: 0.5,
        ),
      ),
    ),

    // Text Theme - Cyberpunk typography
    textTheme: _buildCyberpunkTextTheme(),

    // Input Decoration - Form elements with cyberpunk styling
    inputDecorationTheme: InputDecorationTheme(
      fillColor: elevatedDark,
      filled: true,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12.0),
        borderSide: BorderSide(color: borderCyan, width: 1.0),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12.0),
        borderSide: BorderSide(color: borderCyan, width: 1.0),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12.0),
        borderSide: const BorderSide(color: primaryCyan, width: 2.0),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12.0),
        borderSide: const BorderSide(color: brightRed, width: 1.0),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12.0),
        borderSide: const BorderSide(color: brightRed, width: 2.0),
      ),
      labelStyle: GoogleFonts.inter(
        color: lightGray,
        fontSize: 16,
        fontWeight: FontWeight.w400,
      ),
      hintStyle: GoogleFonts.inter(
        color: textDisabledDark,
        fontSize: 16,
        fontWeight: FontWeight.w400,
      ),
      prefixIconColor: primaryCyan,
      suffixIconColor: primaryCyan,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
    ),

    // Interactive Elements
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return primaryCyan;
        }
        return lightGray;
      }),
      trackColor: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return primaryCyan.withValues(alpha: 0.3);
        }
        return lightGray.withValues(alpha: 0.3);
      }),
    ),

    checkboxTheme: CheckboxThemeData(
      fillColor: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return primaryCyan;
        }
        return Colors.transparent;
      }),
      checkColor: WidgetStateProperty.all(deepSpaceBlue),
      side: const BorderSide(color: primaryCyan, width: 2.0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(4.0),
      ),
    ),

    radioTheme: RadioThemeData(
      fillColor: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return primaryCyan;
        }
        return lightGray;
      }),
    ),

    // Progress Indicators - Cyberpunk progress visualization
    progressIndicatorTheme: const ProgressIndicatorThemeData(
      color: primaryCyan,
      linearTrackColor: elevatedDark,
      circularTrackColor: elevatedDark,
    ),

    sliderTheme: SliderThemeData(
      activeTrackColor: primaryCyan,
      thumbColor: primaryCyan,
      overlayColor: primaryCyan.withValues(alpha: 0.2),
      inactiveTrackColor: lightGray.withValues(alpha: 0.3),
      valueIndicatorColor: primaryCyan,
      valueIndicatorTextStyle: GoogleFonts.jetBrainsMono(
        color: deepSpaceBlue,
        fontSize: 14,
        fontWeight: FontWeight.w500,
      ),
    ),

    // Tab Bar Theme
    tabBarTheme: TabBarTheme(
      labelColor: primaryCyan,
      unselectedLabelColor: lightGray,
      indicatorColor: primaryCyan,
      indicatorSize: TabBarIndicatorSize.tab,
      labelStyle: GoogleFonts.orbitron(
        fontSize: 16,
        fontWeight: FontWeight.w600,
        letterSpacing: 0.5,
      ),
      unselectedLabelStyle: GoogleFonts.orbitron(
        fontSize: 16,
        fontWeight: FontWeight.w400,
        letterSpacing: 0.5,
      ),
    ),

    // Tooltip Theme
    tooltipTheme: TooltipThemeData(
      decoration: BoxDecoration(
        color: elevatedDark,
        borderRadius: BorderRadius.circular(8.0),
        border: Border.all(color: borderCyan, width: 1.0),
        boxShadow: [
          BoxShadow(
            color: shadowCyan,
            blurRadius: 8.0,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      textStyle: GoogleFonts.inter(
        color: pureWhite,
        fontSize: 14,
        fontWeight: FontWeight.w400,
      ),
    ),

    // Snackbar Theme
    snackBarTheme: SnackBarThemeData(
      backgroundColor: elevatedDark,
      contentTextStyle: GoogleFonts.inter(
        color: pureWhite,
        fontSize: 16,
        fontWeight: FontWeight.w400,
      ),
      actionTextColor: primaryCyan,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0),
        side: BorderSide(color: borderCyan, width: 1.0),
      ),
      elevation: 8.0,
    ),

    // Dialog Theme
    dialogTheme: DialogTheme(
      backgroundColor: elevatedDark,
      surfaceTintColor: Colors.transparent,
      elevation: 16.0,
      shadowColor: shadowCyan,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.0),
        side: BorderSide(color: borderCyan, width: 1.0),
      ),
      titleTextStyle: GoogleFonts.orbitron(
        fontSize: 24,
        fontWeight: FontWeight.w700,
        color: pureWhite,
        letterSpacing: 0.5,
      ),
      contentTextStyle: GoogleFonts.inter(
        fontSize: 16,
        fontWeight: FontWeight.w400,
        color: lightGray,
        letterSpacing: 0.25,
      ),
    ),

    // List Tile Theme
    listTileTheme: ListTileThemeData(
      tileColor: elevatedDark,
      selectedTileColor: primaryCyan.withValues(alpha: 0.1),
      iconColor: primaryCyan,
      textColor: pureWhite,
      selectedColor: primaryCyan,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.0),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    ),

    // Chip Theme
    chipTheme: ChipThemeData(
      backgroundColor: elevatedDark,
      selectedColor: primaryCyan.withValues(alpha: 0.2),
      disabledColor: lightGray.withValues(alpha: 0.3),
      labelStyle: GoogleFonts.inter(
        fontSize: 14,
        fontWeight: FontWeight.w500,
        color: pureWhite,
      ),
      secondaryLabelStyle: GoogleFonts.inter(
        fontSize: 14,
        fontWeight: FontWeight.w500,
        color: deepSpaceBlue,
      ),
      side: BorderSide(color: borderCyan, width: 1.0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.0),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
    ),
  );

  /// Light theme - Minimal implementation for accessibility
  static ThemeData lightTheme = ThemeData(
    brightness: Brightness.light,
    colorScheme: ColorScheme(
      brightness: Brightness.light,
      primary: primaryCyan,
      onPrimary: pureWhite,
      primaryContainer: primaryCyan.withValues(alpha: 0.1),
      onPrimaryContainer: deepSpaceBlue,
      secondary: hotPink,
      onSecondary: pureWhite,
      secondaryContainer: hotPink.withValues(alpha: 0.1),
      onSecondaryContainer: deepSpaceBlue,
      tertiary: neonGreen,
      onTertiary: deepSpaceBlue,
      tertiaryContainer: neonGreen.withValues(alpha: 0.1),
      onTertiaryContainer: deepSpaceBlue,
      error: brightRed,
      onError: pureWhite,
      surface: pureWhite,
      onSurface: deepSpaceBlue,
      onSurfaceVariant: lightGray,
      outline: borderCyan,
      outlineVariant: dividerCyan,
      shadow: Colors.black26,
      scrim: Colors.black54,
      inverseSurface: deepSpaceBlue,
      onInverseSurface: pureWhite,
      inversePrimary: primaryCyan,
    ),
    scaffoldBackgroundColor: pureWhite,
    textTheme: _buildCyberpunkTextTheme(isLight: true),
  );

  /// Helper method to build cyberpunk text theme
  static TextTheme _buildCyberpunkTextTheme({bool isLight = false}) {
    final Color textColor = isLight ? deepSpaceBlue : pureWhite;
    final Color secondaryTextColor = isLight ? lightGray : lightGray;
    final Color disabledTextColor =
        isLight ? lightGray.withValues(alpha: 0.6) : textDisabledDark;

    return TextTheme(
      // Display styles - Orbitron for futuristic headings
      displayLarge: GoogleFonts.orbitron(
        fontSize: 57,
        fontWeight: FontWeight.w900,
        color: textColor,
        letterSpacing: -0.25,
      ),
      displayMedium: GoogleFonts.orbitron(
        fontSize: 45,
        fontWeight: FontWeight.w700,
        color: textColor,
        letterSpacing: 0,
      ),
      displaySmall: GoogleFonts.orbitron(
        fontSize: 36,
        fontWeight: FontWeight.w700,
        color: textColor,
        letterSpacing: 0,
      ),

      // Headline styles - Orbitron for section headers
      headlineLarge: GoogleFonts.orbitron(
        fontSize: 32,
        fontWeight: FontWeight.w700,
        color: textColor,
        letterSpacing: 0,
      ),
      headlineMedium: GoogleFonts.orbitron(
        fontSize: 28,
        fontWeight: FontWeight.w700,
        color: textColor,
        letterSpacing: 0,
      ),
      headlineSmall: GoogleFonts.orbitron(
        fontSize: 24,
        fontWeight: FontWeight.w600,
        color: textColor,
        letterSpacing: 0,
      ),

      // Title styles - Orbitron for component titles
      titleLarge: GoogleFonts.orbitron(
        fontSize: 22,
        fontWeight: FontWeight.w600,
        color: textColor,
        letterSpacing: 0,
      ),
      titleMedium: GoogleFonts.orbitron(
        fontSize: 16,
        fontWeight: FontWeight.w600,
        color: textColor,
        letterSpacing: 0.15,
      ),
      titleSmall: GoogleFonts.orbitron(
        fontSize: 14,
        fontWeight: FontWeight.w600,
        color: textColor,
        letterSpacing: 0.1,
      ),

      // Body styles - Inter for optimal readability
      bodyLarge: GoogleFonts.inter(
        fontSize: 16,
        fontWeight: FontWeight.w400,
        color: textColor,
        letterSpacing: 0.5,
        height: 1.5,
      ),
      bodyMedium: GoogleFonts.inter(
        fontSize: 14,
        fontWeight: FontWeight.w400,
        color: textColor,
        letterSpacing: 0.25,
        height: 1.43,
      ),
      bodySmall: GoogleFonts.inter(
        fontSize: 12,
        fontWeight: FontWeight.w400,
        color: secondaryTextColor,
        letterSpacing: 0.4,
        height: 1.33,
      ),

      // Label styles - Inter for UI elements
      labelLarge: GoogleFonts.inter(
        fontSize: 14,
        fontWeight: FontWeight.w500,
        color: textColor,
        letterSpacing: 0.1,
      ),
      labelMedium: GoogleFonts.inter(
        fontSize: 12,
        fontWeight: FontWeight.w500,
        color: textColor,
        letterSpacing: 0.5,
      ),
      labelSmall: GoogleFonts.inter(
        fontSize: 11,
        fontWeight: FontWeight.w500,
        color: disabledTextColor,
        letterSpacing: 0.5,
      ),
    );
  }
}
