import 'package:flutter/material.dart';
import '../presentation/profile_dashboard/profile_dashboard.dart';
import '../presentation/learning_path/learning_path.dart';
import '../presentation/lesson_detail/lesson_detail.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/dashboard_home/dashboard_home.dart';
import '../presentation/code_editor/code_editor.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String profileDashboard = '/profile-dashboard';
  static const String learningPath = '/learning-path';
  static const String lessonDetail = '/lesson-detail';
  static const String login = '/login-screen';
  static const String dashboardHome = '/dashboard-home';
  static const String codeEditor = '/code-editor';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const LoginScreen(),
    profileDashboard: (context) => const ProfileDashboard(),
    learningPath: (context) => const LearningPath(),
    lessonDetail: (context) => const LessonDetail(),
    login: (context) => const LoginScreen(),
    dashboardHome: (context) => const DashboardHome(),
    codeEditor: (context) => const CodeEditor(),
    // TODO: Add your other routes here
  };
}