import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

/// Custom Bottom Navigation Bar implementing cyberpunk design system
/// Provides consistent navigation across main application screens
class CustomBottomBar extends StatefulWidget {
  /// Current selected index
  final int currentIndex;

  /// Callback when navigation item is tapped
  final ValueChanged<int>? onTap;

  /// Bottom bar variant for different contexts
  final CustomBottomBarVariant variant;

  /// Whether to show labels
  final bool showLabels;

  const CustomBottomBar({
    super.key,
    required this.currentIndex,
    this.onTap,
    this.variant = CustomBottomBarVariant.primary,
    this.showLabels = true,
  });

  @override
  State<CustomBottomBar> createState() => _CustomBottomBarState();
}

class _CustomBottomBarState extends State<CustomBottomBar>
    with TickerProviderStateMixin {
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _glowAnimation = Tween<double>(
      begin: 0.3,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _glowController,
      curve: Curves.easeInOut,
    ));
    _glowController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    // Navigation items configuration
    final items = _getNavigationItems();

    // Determine colors based on variant
    Color backgroundColor;
    Color selectedColor;
    Color unselectedColor;

    switch (widget.variant) {
      case CustomBottomBarVariant.primary:
        backgroundColor = const Color(0xFF1A1A2E);
        selectedColor = const Color(0xFF00F5FF);
        unselectedColor = const Color(0xFFB0B0B0);
        break;
      case CustomBottomBarVariant.floating:
        backgroundColor = const Color(0xFF1A1A2E).withValues(alpha: 0.95);
        selectedColor = const Color(0xFF00F5FF);
        unselectedColor = const Color(0xFFB0B0B0);
        break;
      case CustomBottomBarVariant.minimal:
        backgroundColor = const Color(0xFF0A0A0F);
        selectedColor = const Color(0xFF00F5FF);
        unselectedColor = const Color(0xFFB0B0B0);
        break;
    }

    return Container(
      decoration: BoxDecoration(
        color: backgroundColor,
        border: Border(
          top: BorderSide(
            color: const Color(0xFF00F5FF).withValues(alpha: 0.3),
            width: 1.0,
          ),
        ),
        boxShadow: widget.variant == CustomBottomBarVariant.floating
            ? [
                BoxShadow(
                  color: const Color(0x1A00F5FF),
                  blurRadius: 16.0,
                  offset: const Offset(0, -4),
                ),
              ]
            : [
                BoxShadow(
                  color: const Color(0x1A00F5FF),
                  blurRadius: 8.0,
                  offset: const Offset(0, -2),
                ),
              ],
      ),
      child: SafeArea(
        child: Container(
          height: widget.showLabels ? 80 : 60,
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: items.asMap().entries.map((entry) {
              final index = entry.key;
              final item = entry.value;
              final isSelected = index == widget.currentIndex;

              return Expanded(
                child: _NavigationItem(
                  item: item,
                  isSelected: isSelected,
                  selectedColor: selectedColor,
                  unselectedColor: unselectedColor,
                  showLabel: widget.showLabels,
                  glowAnimation: _glowAnimation,
                  onTap: () {
                    HapticFeedback.lightImpact();
                    widget.onTap?.call(index);
                    _navigateToRoute(context, item.route);
                  },
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  /// Get navigation items configuration
  List<_NavigationItemData> _getNavigationItems() {
    return [
      _NavigationItemData(
        icon: Icons.home_outlined,
        selectedIcon: Icons.home_rounded,
        label: 'Home',
        route: '/dashboard-home',
      ),
      _NavigationItemData(
        icon: Icons.school_outlined,
        selectedIcon: Icons.school_rounded,
        label: 'Learn',
        route: '/learning-path',
      ),
      _NavigationItemData(
        icon: Icons.code_outlined,
        selectedIcon: Icons.code_rounded,
        label: 'Code',
        route: '/code-editor',
      ),
      _NavigationItemData(
        icon: Icons.person_outline_rounded,
        selectedIcon: Icons.person_rounded,
        label: 'Profile',
        route: '/profile-dashboard',
      ),
    ];
  }

  /// Navigate to the specified route
  void _navigateToRoute(BuildContext context, String route) {
    final currentRoute = ModalRoute.of(context)?.settings.name;
    if (currentRoute != route) {
      Navigator.pushNamedAndRemoveUntil(
        context,
        route,
        (route) => false,
      );
    }
  }
}

/// Individual navigation item widget
class _NavigationItem extends StatelessWidget {
  final _NavigationItemData item;
  final bool isSelected;
  final Color selectedColor;
  final Color unselectedColor;
  final bool showLabel;
  final Animation<double> glowAnimation;
  final VoidCallback onTap;

  const _NavigationItem({
    required this.item,
    required this.isSelected,
    required this.selectedColor,
    required this.unselectedColor,
    required this.showLabel,
    required this.glowAnimation,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Icon with glow effect
            AnimatedBuilder(
              animation: glowAnimation,
              builder: (context, child) {
                return Container(
                  padding: const EdgeInsets.all(8),
                  decoration: isSelected
                      ? BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: selectedColor.withValues(
                                alpha: glowAnimation.value * 0.5,
                              ),
                              blurRadius: 12.0,
                              spreadRadius: 2.0,
                            ),
                          ],
                        )
                      : null,
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    child: Icon(
                      isSelected ? item.selectedIcon : item.icon,
                      key: ValueKey(isSelected),
                      color: isSelected ? selectedColor : unselectedColor,
                      size: 24,
                    ),
                  ),
                );
              },
            ),

            // Label
            if (showLabel) ...[
              const SizedBox(height: 4),
              AnimatedDefaultTextStyle(
                duration: const Duration(milliseconds: 200),
                style: GoogleFonts.inter(
                  fontSize: 12,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                  color: isSelected ? selectedColor : unselectedColor,
                  letterSpacing: 0.4,
                ),
                child: Text(
                  item.label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// Data class for navigation items
class _NavigationItemData {
  final IconData icon;
  final IconData selectedIcon;
  final String label;
  final String route;

  const _NavigationItemData({
    required this.icon,
    required this.selectedIcon,
    required this.label,
    required this.route,
  });
}

/// Enum defining different bottom bar variants
enum CustomBottomBarVariant {
  /// Primary bottom bar with solid background
  primary,

  /// Floating bottom bar with blur effect
  floating,

  /// Minimal bottom bar with reduced visual elements
  minimal,
}
