import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

/// Custom Tab Bar implementing cyberpunk design system
/// Provides consistent tabbed navigation within screens
class CustomTabBar extends StatefulWidget implements PreferredSizeWidget {
  /// List of tab labels
  final List<String> tabs;

  /// Current selected tab index
  final int currentIndex;

  /// Callback when tab is selected
  final ValueChanged<int>? onTap;

  /// Tab bar variant for different contexts
  final CustomTabBarVariant variant;

  /// Whether tabs are scrollable
  final bool isScrollable;

  /// Custom tab controller
  final TabController? controller;

  /// Whether to show indicator
  final bool showIndicator;

  const CustomTabBar({
    super.key,
    required this.tabs,
    required this.currentIndex,
    this.onTap,
    this.variant = CustomTabBarVariant.primary,
    this.isScrollable = false,
    this.controller,
    this.showIndicator = true,
  });

  @override
  State<CustomTabBar> createState() => _CustomTabBarState();

  @override
  Size get preferredSize => const Size.fromHeight(48);
}

class _CustomTabBarState extends State<CustomTabBar>
    with TickerProviderStateMixin {
  late TabController _tabController;
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    _tabController = widget.controller ??
        TabController(
          length: widget.tabs.length,
          vsync: this,
          initialIndex: widget.currentIndex,
        );

    _glowController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
    _glowAnimation = Tween<double>(
      begin: 0.4,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _glowController,
      curve: Curves.easeInOut,
    ));
    _glowController.repeat(reverse: true);
  }

  @override
  void dispose() {
    if (widget.controller == null) {
      _tabController.dispose();
    }
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Determine colors based on variant
    Color backgroundColor;
    Color selectedColor;
    Color unselectedColor;
    Color indicatorColor;

    switch (widget.variant) {
      case CustomTabBarVariant.primary:
        backgroundColor = const Color(0xFF1A1A2E);
        selectedColor = const Color(0xFF00F5FF);
        unselectedColor = const Color(0xFFB0B0B0);
        indicatorColor = const Color(0xFF00F5FF);
        break;
      case CustomTabBarVariant.surface:
        backgroundColor = const Color(0xFF0A0A0F);
        selectedColor = const Color(0xFF00F5FF);
        unselectedColor = const Color(0xFFB0B0B0);
        indicatorColor = const Color(0xFF00F5FF);
        break;
      case CustomTabBarVariant.transparent:
        backgroundColor = Colors.transparent;
        selectedColor = const Color(0xFF00F5FF);
        unselectedColor = const Color(0xFFB0B0B0);
        indicatorColor = const Color(0xFF00F5FF);
        break;
      case CustomTabBarVariant.minimal:
        backgroundColor = const Color(0xFF1A1A2E).withValues(alpha: 0.8);
        selectedColor = const Color(0xFF00F5FF);
        unselectedColor = const Color(0xFFB0B0B0);
        indicatorColor = const Color(0xFF00F5FF);
        break;
    }

    return Container(
      decoration: BoxDecoration(
        color: backgroundColor,
        border: widget.variant != CustomTabBarVariant.transparent
            ? Border(
                bottom: BorderSide(
                  color: const Color(0xFF00F5FF).withValues(alpha: 0.2),
                  width: 1.0,
                ),
              )
            : null,
        boxShadow: widget.variant == CustomTabBarVariant.surface
            ? [
                BoxShadow(
                  color: const Color(0x1A00F5FF),
                  blurRadius: 8.0,
                  offset: const Offset(0, 2),
                ),
              ]
            : null,
      ),
      child: TabBar(
        controller: _tabController,
        tabs: widget.tabs.asMap().entries.map((entry) {
          final index = entry.key;
          final label = entry.value;
          final isSelected = index == widget.currentIndex;

          return _CustomTab(
            label: label,
            isSelected: isSelected,
            selectedColor: selectedColor,
            unselectedColor: unselectedColor,
            glowAnimation: _glowAnimation,
          );
        }).toList(),
        onTap: (index) {
          HapticFeedback.lightImpact();
          widget.onTap?.call(index);
        },
        isScrollable: widget.isScrollable,
        labelColor: selectedColor,
        unselectedLabelColor: unselectedColor,
        indicatorColor:
            widget.showIndicator ? indicatorColor : Colors.transparent,
        indicatorWeight: 3.0,
        indicatorSize: TabBarIndicatorSize.tab,
        indicator: widget.showIndicator
            ? _CyberpunkTabIndicator(
                color: indicatorColor,
                glowAnimation: _glowAnimation,
              )
            : null,
        labelStyle: GoogleFonts.orbitron(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.5,
        ),
        unselectedLabelStyle: GoogleFonts.orbitron(
          fontSize: 14,
          fontWeight: FontWeight.w400,
          letterSpacing: 0.5,
        ),
        labelPadding: widget.isScrollable
            ? const EdgeInsets.symmetric(horizontal: 16)
            : null,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        splashFactory: NoSplash.splashFactory,
        overlayColor: WidgetStateProperty.all(Colors.transparent),
      ),
    );
  }
}

/// Custom tab widget with cyberpunk styling
class _CustomTab extends StatelessWidget {
  final String label;
  final bool isSelected;
  final Color selectedColor;
  final Color unselectedColor;
  final Animation<double> glowAnimation;

  const _CustomTab({
    required this.label,
    required this.isSelected,
    required this.selectedColor,
    required this.unselectedColor,
    required this.glowAnimation,
  });

  @override
  Widget build(BuildContext context) {
    return Tab(
      child: AnimatedBuilder(
        animation: glowAnimation,
        builder: (context, child) {
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: isSelected
                ? BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: selectedColor.withValues(
                          alpha: glowAnimation.value * 0.3,
                        ),
                        blurRadius: 8.0,
                        spreadRadius: 1.0,
                      ),
                    ],
                  )
                : null,
            child: Text(
              label,
              style: GoogleFonts.orbitron(
                fontSize: 14,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                color: isSelected ? selectedColor : unselectedColor,
                letterSpacing: 0.5,
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Custom cyberpunk tab indicator with glow effect
class _CyberpunkTabIndicator extends Decoration {
  final Color color;
  final Animation<double> glowAnimation;

  const _CyberpunkTabIndicator({
    required this.color,
    required this.glowAnimation,
  });

  @override
  BoxPainter createBoxPainter([VoidCallback? onChanged]) {
    return _CyberpunkTabIndicatorPainter(
      color: color,
      glowAnimation: glowAnimation,
      onChanged: onChanged,
    );
  }
}

/// Painter for cyberpunk tab indicator
class _CyberpunkTabIndicatorPainter extends BoxPainter {
  final Color color;
  final Animation<double> glowAnimation;

  _CyberpunkTabIndicatorPainter({
    required this.color,
    required this.glowAnimation,
    VoidCallback? onChanged,
  }) : super(onChanged);

  @override
  void paint(Canvas canvas, Offset offset, ImageConfiguration configuration) {
    final rect = Rect.fromLTWH(
      offset.dx,
      configuration.size!.height - 3,
      configuration.size!.width,
      3,
    );

    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    // Draw main indicator
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(1.5)),
      paint,
    );

    // Draw glow effect
    final glowPaint = Paint()
      ..color = color.withValues(alpha: glowAnimation.value * 0.5)
      ..style = PaintingStyle.fill
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        rect.inflate(2),
        const Radius.circular(2.5),
      ),
      glowPaint,
    );
  }
}

/// Factory constructors for common use cases
extension CustomTabBarFactory on CustomTabBar {
  /// Factory constructor for lesson navigation
  static CustomTabBar lesson({
    required List<String> tabs,
    required int currentIndex,
    ValueChanged<int>? onTap,
    TabController? controller,
    Key? key,
  }) {
    return CustomTabBar(
      key: key,
      tabs: tabs,
      currentIndex: currentIndex,
      onTap: onTap,
      controller: controller,
      variant: CustomTabBarVariant.surface,
      isScrollable: tabs.length > 4,
    );
  }

  /// Factory constructor for dashboard sections
  static CustomTabBar dashboard({
    required List<String> tabs,
    required int currentIndex,
    ValueChanged<int>? onTap,
    TabController? controller,
    Key? key,
  }) {
    return CustomTabBar(
      key: key,
      tabs: tabs,
      currentIndex: currentIndex,
      onTap: onTap,
      controller: controller,
      variant: CustomTabBarVariant.primary,
      isScrollable: false,
    );
  }

  /// Factory constructor for code editor tabs
  static CustomTabBar codeEditor({
    required List<String> tabs,
    required int currentIndex,
    ValueChanged<int>? onTap,
    TabController? controller,
    Key? key,
  }) {
    return CustomTabBar(
      key: key,
      tabs: tabs,
      currentIndex: currentIndex,
      onTap: onTap,
      controller: controller,
      variant: CustomTabBarVariant.minimal,
      isScrollable: true,
      showIndicator: false,
    );
  }

  /// Factory constructor for overlay tabs
  static CustomTabBar overlay({
    required List<String> tabs,
    required int currentIndex,
    ValueChanged<int>? onTap,
    TabController? controller,
    Key? key,
  }) {
    return CustomTabBar(
      key: key,
      tabs: tabs,
      currentIndex: currentIndex,
      onTap: onTap,
      controller: controller,
      variant: CustomTabBarVariant.transparent,
      isScrollable: false,
    );
  }
}

/// Enum defining different tab bar variants
enum CustomTabBarVariant {
  /// Primary tab bar with solid background
  primary,

  /// Surface tab bar with elevated styling
  surface,

  /// Transparent tab bar for overlays
  transparent,

  /// Minimal tab bar with reduced visual elements
  minimal,
}
