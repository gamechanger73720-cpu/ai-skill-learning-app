import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

/// Custom AppBar widget implementing cyberpunk design system
/// Provides consistent navigation header across the application
class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  /// The title to display in the app bar
  final String title;

  /// Whether to show the back button
  final bool showBackButton;

  /// Custom leading widget (overrides showBackButton if provided)
  final Widget? leading;

  /// List of action widgets to display on the right
  final List<Widget>? actions;

  /// Whether to center the title
  final bool centerTitle;

  /// Custom background color (optional)
  final Color? backgroundColor;

  /// Whether to show elevation shadow
  final bool showElevation;

  /// App bar variant for different contexts
  final CustomAppBarVariant variant;

  const CustomAppBar({
    super.key,
    required this.title,
    this.showBackButton = true,
    this.leading,
    this.actions,
    this.centerTitle = true,
    this.backgroundColor,
    this.showElevation = false,
    this.variant = CustomAppBarVariant.primary,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    // Determine colors based on variant
    Color effectiveBackgroundColor;
    Color effectiveForegroundColor;
    Color effectiveIconColor;

    switch (variant) {
      case CustomAppBarVariant.primary:
        effectiveBackgroundColor = backgroundColor ?? const Color(0xFF0A0A0F);
        effectiveForegroundColor = const Color(0xFFFFFFFF);
        effectiveIconColor = const Color(0xFF00F5FF);
        break;
      case CustomAppBarVariant.transparent:
        effectiveBackgroundColor = backgroundColor ?? Colors.transparent;
        effectiveForegroundColor = const Color(0xFFFFFFFF);
        effectiveIconColor = const Color(0xFF00F5FF);
        break;
      case CustomAppBarVariant.surface:
        effectiveBackgroundColor = backgroundColor ?? const Color(0xFF1A1A2E);
        effectiveForegroundColor = const Color(0xFFFFFFFF);
        effectiveIconColor = const Color(0xFF00F5FF);
        break;
    }

    return AppBar(
      title: Text(
        title,
        style: GoogleFonts.orbitron(
          fontSize: 20,
          fontWeight: FontWeight.w700,
          color: effectiveForegroundColor,
          letterSpacing: 0.5,
        ),
      ),
      centerTitle: centerTitle,
      backgroundColor: effectiveBackgroundColor,
      foregroundColor: effectiveForegroundColor,
      elevation: showElevation ? 4.0 : 0,
      shadowColor: showElevation ? const Color(0x1A00F5FF) : null,
      surfaceTintColor: Colors.transparent,
      systemOverlayStyle: SystemUiOverlayStyle.light.copyWith(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
      ),
      leading: leading ??
          (showBackButton && Navigator.canPop(context)
              ? IconButton(
                  icon: Icon(
                    Icons.arrow_back_ios_new_rounded,
                    color: effectiveIconColor,
                    size: 20,
                  ),
                  onPressed: () {
                    HapticFeedback.lightImpact();
                    Navigator.pop(context);
                  },
                  tooltip: 'Back',
                )
              : null),
      actions: actions?.map((action) {
        if (action is IconButton) {
          return IconButton(
            icon: action.icon,
            onPressed: () {
              HapticFeedback.lightImpact();
              action.onPressed?.call();
            },
            color: effectiveIconColor,
            tooltip: action.tooltip,
          );
        }
        return action;
      }).toList(),
      flexibleSpace: variant == CustomAppBarVariant.transparent
          ? Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    const Color(0xFF0A0A0F).withValues(alpha: 0.9),
                    const Color(0xFF0A0A0F).withValues(alpha: 0.7),
                    Colors.transparent,
                  ],
                ),
              ),
            )
          : null,
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  /// Factory constructor for dashboard screens
  factory CustomAppBar.dashboard({
    required String title,
    List<Widget>? actions,
    Key? key,
  }) {
    return CustomAppBar(
      key: key,
      title: title,
      showBackButton: false,
      actions: actions ??
          [
            Builder(
              builder: (context) => IconButton(
                icon: const Icon(Icons.person_outline_rounded),
                onPressed: () {
                  HapticFeedback.lightImpact();
                  Navigator.pushNamed(context, '/profile-dashboard');
                },
                tooltip: 'Profile',
              ),
            ),
          ],
      variant: CustomAppBarVariant.primary,
    );
  }

  /// Factory constructor for lesson screens
  factory CustomAppBar.lesson({
    required String title,
    VoidCallback? onMenuPressed,
    Key? key,
  }) {
    return CustomAppBar(
      key: key,
      title: title,
      showBackButton: true,
      actions: [
        Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.more_vert_rounded),
            onPressed: () {
              HapticFeedback.lightImpact();
              onMenuPressed?.call();
            },
            tooltip: 'More options',
          ),
        ),
      ],
      variant: CustomAppBarVariant.surface,
    );
  }

  /// Factory constructor for code editor
  factory CustomAppBar.codeEditor({
    required String title,
    VoidCallback? onRunPressed,
    VoidCallback? onSavePressed,
    Key? key,
  }) {
    return CustomAppBar(
      key: key,
      title: title,
      showBackButton: true,
      actions: [
        if (onSavePressed != null)
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.save_outlined),
              onPressed: () {
                HapticFeedback.lightImpact();
                onSavePressed.call();
              },
              tooltip: 'Save',
            ),
          ),
        if (onRunPressed != null)
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.play_arrow_rounded),
              onPressed: () {
                HapticFeedback.lightImpact();
                onRunPressed.call();
              },
              tooltip: 'Run code',
            ),
          ),
      ],
      variant: CustomAppBarVariant.surface,
      showElevation: true,
    );
  }

  /// Factory constructor for transparent overlay
  factory CustomAppBar.transparent({
    required String title,
    List<Widget>? actions,
    Key? key,
  }) {
    return CustomAppBar(
      key: key,
      title: title,
      showBackButton: true,
      actions: actions,
      variant: CustomAppBarVariant.transparent,
    );
  }
}

/// Enum defining different app bar variants
enum CustomAppBarVariant {
  /// Primary app bar with solid background
  primary,

  /// Transparent app bar with gradient overlay
  transparent,

  /// Surface app bar with elevated background
  surface,
}
