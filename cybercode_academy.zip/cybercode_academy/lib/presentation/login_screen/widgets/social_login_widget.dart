import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

/// Social login widget containing Google, Apple, and GitHub login options
class SocialLoginWidget extends StatefulWidget {
  final Function(String provider) onSocialLogin;
  final bool isLoading;

  const SocialLoginWidget({
    super.key,
    required this.onSocialLogin,
    required this.isLoading,
  });

  @override
  State<SocialLoginWidget> createState() => _SocialLoginWidgetState();
}

class _SocialLoginWidgetState extends State<SocialLoginWidget>
    with TickerProviderStateMixin {
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 1800),
      vsync: this,
    );
    _glowAnimation = Tween<double>(
      begin: 0.4,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _glowController,
      curve: Curves.easeInOut,
    ));
    _glowController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Divider with text
        Row(
          children: [
            Expanded(
              child: AnimatedBuilder(
                animation: _glowAnimation,
                builder: (context, child) {
                  return Container(
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          AppTheme.primaryCyan.withValues(
                            alpha: _glowAnimation.value * 0.6,
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: Text(
                'Or jack in with',
                style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightGray,
                  fontSize: 12.sp,
                ),
              ),
            ),
            Expanded(
              child: AnimatedBuilder(
                animation: _glowAnimation,
                builder: (context, child) {
                  return Container(
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          AppTheme.primaryCyan.withValues(
                            alpha: _glowAnimation.value * 0.6,
                          ),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),

        SizedBox(height: 4.h),

        // Social Login Buttons
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _SocialLoginButton(
              provider: 'Google',
              iconName: 'g_translate',
              color: const Color(0xFF4285F4),
              onTap: () => _handleSocialLogin('Google'),
              glowAnimation: _glowAnimation,
              isLoading: widget.isLoading,
            ),
            _SocialLoginButton(
              provider: 'Apple',
              iconName: 'apple',
              color: AppTheme.pureWhite,
              onTap: () => _handleSocialLogin('Apple'),
              glowAnimation: _glowAnimation,
              isLoading: widget.isLoading,
            ),
            _SocialLoginButton(
              provider: 'GitHub',
              iconName: 'code',
              color: const Color(0xFF333333),
              onTap: () => _handleSocialLogin('GitHub'),
              glowAnimation: _glowAnimation,
              isLoading: widget.isLoading,
            ),
          ],
        ),
      ],
    );
  }

  void _handleSocialLogin(String provider) {
    if (!widget.isLoading) {
      HapticFeedback.lightImpact();
      widget.onSocialLogin(provider);
    }
  }
}

/// Individual social login button widget
class _SocialLoginButton extends StatelessWidget {
  final String provider;
  final String iconName;
  final Color color;
  final VoidCallback onTap;
  final Animation<double> glowAnimation;
  final bool isLoading;

  const _SocialLoginButton({
    required this.provider,
    required this.iconName,
    required this.color,
    required this.onTap,
    required this.glowAnimation,
    required this.isLoading,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: AnimatedBuilder(
        animation: glowAnimation,
        builder: (context, child) {
          return Container(
            width: 20.w,
            height: 20.w,
            decoration: BoxDecoration(
              color: AppTheme.elevatedDark,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.borderCyan.withValues(alpha: 0.3),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: color.withValues(alpha: glowAnimation.value * 0.2),
                  blurRadius: 12,
                  spreadRadius: 1,
                  offset: const Offset(0, 4),
                ),
                BoxShadow(
                  color: AppTheme.shadowCyan,
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Center(
              child: isLoading
                  ? SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(color),
                      ),
                    )
                  : CustomIconWidget(
                      iconName: iconName,
                      color: color,
                      size: 24,
                    ),
            ),
          );
        },
      ),
    );
  }
}
