import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

/// Biometric login widget for Face ID, Touch ID, and fingerprint authentication
class BiometricLoginWidget extends StatefulWidget {
  final Function() onBiometricLogin;
  final bool isAvailable;

  const BiometricLoginWidget({
    super.key,
    required this.onBiometricLogin,
    required this.isAvailable,
  });

  @override
  State<BiometricLoginWidget> createState() => _BiometricLoginWidgetState();
}

class _BiometricLoginWidgetState extends State<BiometricLoginWidget>
    with TickerProviderStateMixin {
  late AnimationController _scanController;
  late AnimationController _pulseController;
  late Animation<double> _scanAnimation;
  late Animation<double> _pulseAnimation;
  
  bool _isScanning = false;

  @override
  void initState() {
    super.initState();
    
    _scanController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    
    _scanAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _scanController,
      curve: Curves.easeInOut,
    ));
    
    _pulseAnimation = Tween<double>(
      begin: 0.5,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    ));
    
    _pulseController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _scanController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  String get _biometricType {
    if (Platform.isIOS) {
      return 'Face ID / Touch ID';
    } else {
      return 'Fingerprint';
    }
  }

  IconData get _biometricIcon {
    if (Platform.isIOS) {
      return Icons.face_retouching_natural;
    } else {
      return Icons.fingerprint;
    }
  }

  void _handleBiometricLogin() async {
    if (!widget.isAvailable || _isScanning) return;
    
    setState(() {
      _isScanning = true;
    });
    
    HapticFeedback.lightImpact();
    _scanController.forward();
    
    // Simulate biometric scanning animation
    await Future.delayed(const Duration(milliseconds: 2000));
    
    _scanController.reset();
    setState(() {
      _isScanning = false;
    });
    
    widget.onBiometricLogin();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isAvailable) {
      return const SizedBox.shrink();
    }

    return Column(
      children: [
        SizedBox(height: 3.h),
        
        // Biometric Login Button
        GestureDetector(
          onTap: _handleBiometricLogin,
          child: AnimatedBuilder(
            animation: Listenable.merge([_scanAnimation, _pulseAnimation]),
            builder: (context, child) {
              return Container(
                width: 25.w,
                height: 25.w,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppTheme.elevatedDark,
                  border: Border.all(
                    color: _isScanning
                        ? AppTheme.primaryCyan
                        : AppTheme.borderCyan.withValues(alpha: 0.5),
                    width: 2,
                  ),
                  boxShadow: [
                    if (_isScanning)
                      BoxShadow(
                        color: AppTheme.primaryCyan.withValues(
                          alpha: _scanAnimation.value * 0.5,
                        ),
                        blurRadius: 20,
                        spreadRadius: 4,
                      ),
                    BoxShadow(
                      color: AppTheme.primaryCyan.withValues(
                        alpha: _pulseAnimation.value * 0.2,
                      ),
                      blurRadius: 16,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Scanning overlay
                    if (_isScanning)
                      Container(
                        width: 20.w,
                        height: 20.w,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [
                              AppTheme.primaryCyan.withValues(
                                alpha: _scanAnimation.value * 0.3,
                              ),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    
                    // Biometric Icon
                    CustomIconWidget(
                      iconName: Platform.isIOS ? 'face' : 'fingerprint',
                      color: _isScanning
                          ? AppTheme.primaryCyan
                          : AppTheme.lightGray,
                      size: 32,
                    ),
                    
                    // Scanning lines effect
                    if (_isScanning)
                      Positioned.fill(
                        child: CustomPaint(
                          painter: _ScanningLinesPainter(
                            progress: _scanAnimation.value,
                            color: AppTheme.primaryCyan,
                          ),
                        ),
                      ),
                  ],
                ),
              );
            },
          ),
        ),
        
        SizedBox(height: 2.h),
        
        // Biometric Login Text
        AnimatedBuilder(
          animation: _pulseAnimation,
          builder: (context, child) {
            return Text(
              _isScanning ? 'Scanning...' : 'Use $_biometricType',
              style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                color: _isScanning
                    ? AppTheme.primaryCyan
                    : AppTheme.lightGray.withValues(
                        alpha: _pulseAnimation.value,
                      ),
                fontSize: 12.sp,
                fontWeight: _isScanning ? FontWeight.w500 : FontWeight.w400,
              ),
            );
          },
        ),
      ],
    );
  }
}

/// Custom painter for scanning lines effect
class _ScanningLinesPainter extends CustomPainter {
  final double progress;
  final Color color;

  _ScanningLinesPainter({
    required this.progress,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withValues(alpha: 0.6)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    // Draw scanning lines
    for (int i = 0; i < 8; i++) {
      final angle = (i * 45) * (3.14159 / 180);
      final startRadius = radius * 0.3;
      final endRadius = radius * 0.9;
      
      final start = Offset(
        center.dx + startRadius * math.cos(angle + progress * 2 * 3.14159),
        center.dy + startRadius * math.sin(angle + progress * 2 * 3.14159),
      );
      
      final end = Offset(
        center.dx + endRadius * math.cos(angle + progress * 2 * 3.14159),
        center.dy + endRadius * math.sin(angle + progress * 2 * 3.14159),
      );
      
      canvas.drawLine(start, end, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

// Helper function for cos calculation
double cos(double radians) {
  return radians.cos();
}

// Helper function for sin calculation  
double sin(double radians) {
  return radians.sin();
}

// Extension for cos/sin on double
extension DoubleExtension on double {
  double cos() {
    return math.cos(this);
  }
  
  double sin() {
    return math.sin(this);
  }
}