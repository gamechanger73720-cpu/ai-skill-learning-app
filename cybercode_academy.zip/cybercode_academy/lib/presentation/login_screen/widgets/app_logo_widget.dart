import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'dart:math' as math;

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

/// App logo widget with cyberpunk styling and glow animation
class AppLogoWidget extends StatefulWidget {
  const AppLogoWidget({super.key});

  @override
  State<AppLogoWidget> createState() => _AppLogoWidgetState();
}

class _AppLogoWidgetState extends State<AppLogoWidget>
    with TickerProviderStateMixin {
  late AnimationController _glowController;
  late AnimationController _rotationController;
  late Animation<double> _glowAnimation;
  late Animation<double> _rotationAnimation;

  @override
  void initState() {
    super.initState();
    
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 3000),
      vsync: this,
    );
    
    _rotationController = AnimationController(
      duration: const Duration(seconds: 20),
      vsync: this,
    );
    
    _glowAnimation = Tween<double>(
      begin: 0.3,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _glowController,
      curve: Curves.easeInOut,
    ));
    
    _rotationAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _rotationController,
      curve: Curves.linear,
    ));
    
    _glowController.repeat(reverse: true);
    _rotationController.repeat();
  }

  @override
  void dispose() {
    _glowController.dispose();
    _rotationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Logo Container with Holographic Effect
        AnimatedBuilder(
          animation: Listenable.merge([_glowAnimation, _rotationAnimation]),
          builder: (context, child) {
            return Container(
              width: 35.w,
              height: 35.w,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    AppTheme.primaryCyan.withValues(
                      alpha: _glowAnimation.value * 0.2,
                    ),
                    AppTheme.hotPink.withValues(
                      alpha: _glowAnimation.value * 0.1,
                    ),
                    Colors.transparent,
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.primaryCyan.withValues(
                      alpha: _glowAnimation.value * 0.4,
                    ),
                    blurRadius: 30,
                    spreadRadius: 5,
                  ),
                  BoxShadow(
                    color: AppTheme.hotPink.withValues(
                      alpha: _glowAnimation.value * 0.2,
                    ),
                    blurRadius: 20,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Rotating outer ring
                  Transform.rotate(
                    angle: _rotationAnimation.value * 2 * math.pi,
                    child: Container(
                      width: 30.w,
                      height: 30.w,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: AppTheme.primaryCyan.withValues(
                            alpha: _glowAnimation.value * 0.6,
                          ),
                          width: 2,
                        ),
                      ),
                      child: CustomPaint(
                        painter: _CircuitPatternPainter(
                          color: AppTheme.primaryCyan,
                          opacity: _glowAnimation.value,
                        ),
                      ),
                    ),
                  ),
                  
                  // Inner logo container
                  Container(
                    width: 25.w,
                    height: 25.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppTheme.elevatedDark,
                      border: Border.all(
                        color: AppTheme.primaryCyan.withValues(alpha: 0.8),
                        width: 1,
                      ),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // Code icon
                          CustomIconWidget(
                            iconName: 'code',
                            color: AppTheme.primaryCyan,
                            size: 32,
                          ),
                          SizedBox(height: 0.5.h),
                          // Academy text
                          Text(
                            'CA',
                            style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                              color: AppTheme.primaryCyan,
                              fontWeight: FontWeight.w700,
                              fontSize: 12.sp,
                              letterSpacing: 2,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        
        SizedBox(height: 3.h),
        
        // App Name
        AnimatedBuilder(
          animation: _glowAnimation,
          builder: (context, child) {
            return Column(
              children: [
                Text(
                  'CyberCode Academy',
                  style: AppTheme.darkTheme.textTheme.headlineSmall?.copyWith(
                    color: AppTheme.pureWhite,
                    fontWeight: FontWeight.w700,
                    fontSize: 20.sp,
                    shadows: [
                      Shadow(
                        color: AppTheme.primaryCyan.withValues(
                          alpha: _glowAnimation.value * 0.5,
                        ),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 1.h),
                Text(
                  'Jack into the Matrix of Code',
                  style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.lightGray.withValues(
                      alpha: _glowAnimation.value,
                    ),
                    fontSize: 12.sp,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            );
          },
        ),
      ],
    );
  }
}

/// Custom painter for circuit pattern around logo
class _CircuitPatternPainter extends CustomPainter {
  final Color color;
  final double opacity;

  _CircuitPatternPainter({
    required this.color,
    required this.opacity,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withValues(alpha: opacity * 0.4)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;

    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    // Draw circuit lines
    for (int i = 0; i < 6; i++) {
      final angle = (i * 60) * (math.pi / 180);
      final startRadius = radius * 0.7;
      final endRadius = radius * 0.9;
      
      final start = Offset(
        center.dx + startRadius * math.cos(angle),
        center.dy + startRadius * math.sin(angle),
      );
      
      final end = Offset(
        center.dx + endRadius * math.cos(angle),
        center.dy + endRadius * math.sin(angle),
      );
      
      canvas.drawLine(start, end, paint);
      
      // Draw small circles at line ends
      canvas.drawCircle(end, 2, paint..style = PaintingStyle.fill);
      paint.style = PaintingStyle.stroke;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

// Helper functions for trigonometry
double cos(double radians) => math.cos(radians);
double sin(double radians) => math.sin(radians);

extension on double {
  double cos() => math.cos(this);
  double sin() => math.sin(this);
}