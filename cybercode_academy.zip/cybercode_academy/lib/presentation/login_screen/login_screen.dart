import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/app_logo_widget.dart';
import './widgets/biometric_login_widget.dart';
import './widgets/login_form_widget.dart';
import './widgets/social_login_widget.dart';

/// Login Screen for CyberCode Academy
/// Provides secure authentication with cyberpunk-themed UI
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with TickerProviderStateMixin {
  bool _isLoading = false;
  bool _isBiometricAvailable = false;
  late AnimationController _backgroundController;
  late Animation<double> _backgroundAnimation;

  // Mock credentials for testing
  final Map<String, String> _mockCredentials = {
    'admin@cybercode.com': 'admin123',
    'student@cybercode.com': 'student123',
    'hacker@cybercode.com': 'hacker123',
  };

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _checkBiometricAvailability();
  }

  void _initializeAnimations() {
    _backgroundController = AnimationController(
      duration: const Duration(seconds: 10),
      vsync: this,
    );
    _backgroundAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _backgroundController,
      curve: Curves.linear,
    ));
    _backgroundController.repeat();
  }

  void _checkBiometricAvailability() {
    // Simulate biometric availability check
    setState(() {
      _isBiometricAvailable = Platform.isIOS || Platform.isAndroid;
    });
  }

  @override
  void dispose() {
    _backgroundController.dispose();
    super.dispose();
  }

  Future<void> _handleLogin(String email, String password) async {
    setState(() {
      _isLoading = true;
    });

    // Simulate network delay
    await Future.delayed(const Duration(milliseconds: 1500));

    // Check mock credentials
    if (_mockCredentials.containsKey(email) &&
        _mockCredentials[email] == password) {
      // Success - navigate to dashboard
      HapticFeedback.heavyImpact();
      _showSuccessMessage();
      await Future.delayed(const Duration(milliseconds: 500));

      if (mounted) {
        Navigator.pushNamedAndRemoveUntil(
          context,
          '/dashboard-home',
          (route) => false,
        );
      }
    } else {
      // Show error message
      HapticFeedback.vibrate();
      _showErrorMessage(
          'Invalid credentials. Please check your email and password.');
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _handleSocialLogin(String provider) async {
    setState(() {
      _isLoading = true;
    });

    // Simulate social login process
    await Future.delayed(const Duration(milliseconds: 2000));

    HapticFeedback.heavyImpact();
    _showSuccessMessage('$provider login successful!');
    await Future.delayed(const Duration(milliseconds: 500));

    if (mounted) {
      Navigator.pushNamedAndRemoveUntil(
        context,
        '/dashboard-home',
        (route) => false,
      );
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _handleBiometricLogin() async {
    HapticFeedback.heavyImpact();
    _showSuccessMessage('Biometric authentication successful!');
    await Future.delayed(const Duration(milliseconds: 500));

    if (mounted) {
      Navigator.pushNamedAndRemoveUntil(
        context,
        '/dashboard-home',
        (route) => false,
      );
    }
  }

  void _showSuccessMessage([String? message]) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              color: AppTheme.neonGreen,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Expanded(
              child: Text(
                message ?? 'Login successful! Welcome to CyberCode Academy',
                style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.pureWhite,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: AppTheme.elevatedDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: BorderSide(
            color: AppTheme.neonGreen.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showErrorMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'error',
              color: AppTheme.brightRed,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Expanded(
              child: Text(
                message,
                style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.pureWhite,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: AppTheme.elevatedDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: BorderSide(
            color: AppTheme.brightRed.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _navigateToSignUp() {
    HapticFeedback.lightImpact();
    // Navigate to sign up screen (placeholder)
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Sign up feature coming soon!',
          style: AppTheme.darkTheme.textTheme.bodyMedium,
        ),
        backgroundColor: AppTheme.elevatedDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.deepSpaceBlue,
      body: Stack(
        children: [
          // Animated background
          AnimatedBuilder(
            animation: _backgroundAnimation,
            builder: (context, child) {
              return Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.topRight,
                    radius: 1.5,
                    colors: [
                      AppTheme.primaryCyan.withValues(alpha: 0.1),
                      AppTheme.hotPink.withValues(alpha: 0.05),
                      AppTheme.deepSpaceBlue,
                    ],
                    stops: [
                      0.0,
                      _backgroundAnimation.value,
                      1.0,
                    ],
                  ),
                ),
              );
            },
          ),

          // Matrix-style particles
          Positioned.fill(
            child: CustomPaint(
              painter: _MatrixParticlesPainter(
                animation: _backgroundAnimation,
              ),
            ),
          ),

          // Main content
          SafeArea(
            child: GestureDetector(
              onTap: () => FocusScope.of(context).unfocus(),
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 6.w),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    minHeight: MediaQuery.of(context).size.height -
                        MediaQuery.of(context).padding.top -
                        MediaQuery.of(context).padding.bottom,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(height: 5.h),

                      // App Logo
                      const AppLogoWidget(),

                      SizedBox(height: 6.h),

                      // Login Form
                      LoginFormWidget(
                        onLogin: _handleLogin,
                        isLoading: _isLoading,
                      ),

                      SizedBox(height: 5.h),

                      // Social Login
                      SocialLoginWidget(
                        onSocialLogin: _handleSocialLogin,
                        isLoading: _isLoading,
                      ),

                      // Biometric Login
                      BiometricLoginWidget(
                        onBiometricLogin: _handleBiometricLogin,
                        isAvailable: _isBiometricAvailable,
                      ),

                      SizedBox(height: 4.h),

                      // Sign Up Link
                      GestureDetector(
                        onTap: _navigateToSignUp,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            vertical: 12,
                            horizontal: 16,
                          ),
                          child: RichText(
                            text: TextSpan(
                              text: 'New hacker? ',
                              style: AppTheme.darkTheme.textTheme.bodyMedium
                                  ?.copyWith(
                                color: AppTheme.lightGray,
                                fontSize: 14.sp,
                              ),
                              children: [
                                TextSpan(
                                  text: 'Sign Up',
                                  style: AppTheme.darkTheme.textTheme.bodyMedium
                                      ?.copyWith(
                                    color: AppTheme.primaryCyan,
                                    fontSize: 14.sp,
                                    fontWeight: FontWeight.w600,
                                    decoration: TextDecoration.underline,
                                    decorationColor: AppTheme.primaryCyan,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      SizedBox(height: 3.h),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Custom painter for matrix-style background particles
class _MatrixParticlesPainter extends CustomPainter {
  final Animation<double> animation;

  _MatrixParticlesPainter({required this.animation});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppTheme.primaryCyan.withValues(alpha: 0.1)
      ..strokeWidth = 1;

    // Draw floating particles
    for (int i = 0; i < 20; i++) {
      final x = (size.width / 20) * i;
      final y = (size.height * animation.value + (i * 50)) % size.height;

      canvas.drawCircle(
        Offset(x, y),
        1 + (i % 3),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
