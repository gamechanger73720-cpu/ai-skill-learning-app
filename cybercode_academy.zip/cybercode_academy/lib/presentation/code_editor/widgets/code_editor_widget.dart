import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter/foundation.dart'; // Add this import for ValueListenable

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

/// Main code editor widget with syntax highlighting and cyberpunk styling
class CodeEditorWidget extends StatefulWidget {
  final String initialCode;
  final String language;
  final Function(String) onCodeChanged;
  final VoidCallback? onRun;
  final bool isReadOnly;

  const CodeEditorWidget({
    super.key,
    required this.initialCode,
    required this.language,
    required this.onCodeChanged,
    this.onRun,
    this.isReadOnly = false,
  });

  @override
  State<CodeEditorWidget> createState() => _CodeEditorWidgetState();
}

class _CodeEditorWidgetState extends State<CodeEditorWidget>
    with TickerProviderStateMixin {
  late TextEditingController _controller;
  late FocusNode _focusNode;
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;
  int _currentLine = 1;
  int _currentColumn = 1;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialCode);
    _focusNode = FocusNode();

    _glowController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
    _glowAnimation = Tween<double>(
      begin: 0.3,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _glowController,
      curve: Curves.easeInOut,
    ));
    _glowController.repeat(reverse: true);

    _controller.addListener(() {
      widget.onCodeChanged(_controller.text);
      _updateCursorPosition();
    });

    _focusNode.addListener(() {
      if (_focusNode.hasFocus) {
        _updateCursorPosition();
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    _glowController.dispose();
    super.dispose();
  }

  void _updateCursorPosition() {
    final text = _controller.text;
    final selection = _controller.selection;

    if (selection.baseOffset >= 0) {
      final textBeforeCursor = text.substring(0, selection.baseOffset);
      final lines = textBeforeCursor.split('\n');

      setState(() {
        _currentLine = lines.length;
        _currentColumn = lines.last.length + 1;
      });
    }
  }

  void _insertText(String text) {
    final selection = _controller.selection;
    final currentText = _controller.text;

    final newText = currentText.replaceRange(
      selection.start,
      selection.end,
      text,
    );

    _controller.text = newText;
    _controller.selection = TextSelection.collapsed(
      offset: selection.start + text.length,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.elevatedDark,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.borderCyan,
          width: 1.0,
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowCyan,
            blurRadius: 8.0,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          // Editor header with line/column info
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: AppTheme.deepSpaceBlue,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(12),
                topRight: Radius.circular(12),
              ),
              border: Border(
                bottom: BorderSide(
                  color: AppTheme.borderCyan,
                  width: 1.0,
                ),
              ),
            ),
            child: Row(
              children: [
                Text(
                  widget.language.toUpperCase(),
                  style: AppTheme.darkTheme.textTheme.labelMedium?.copyWith(
                    color: AppTheme.primaryCyan,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                AnimatedBuilder(
                  animation: _glowAnimation,
                  builder: (context, child) {
                    return Container(
                      padding: EdgeInsets.symmetric(
                          horizontal: 2.w, vertical: 0.5.h),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryCyan.withValues(
                          alpha: _glowAnimation.value * 0.2,
                        ),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: AppTheme.primaryCyan.withValues(
                            alpha: _glowAnimation.value,
                          ),
                          width: 1.0,
                        ),
                      ),
                      child: Text(
                        'Ln $_currentLine, Col $_currentColumn',
                        style:
                            AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
                          color: AppTheme.pureWhite,
                          fontFamily: 'monospace',
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),

          // Code editor area
          Expanded(
            child: Container(
              padding: EdgeInsets.all(3.w),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Line numbers
                  Container(
                    width: 12.w,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: _buildLineNumbers(),
                    ),
                  ),

                  SizedBox(width: 2.w),

                  // Code input area
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      focusNode: _focusNode,
                      readOnly: widget.isReadOnly,
                      maxLines: null,
                      expands: true,
                      textAlignVertical: TextAlignVertical.top,
                      style: TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 14.sp,
                        color: AppTheme.pureWhite,
                        height: 1.4,
                      ),
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: widget.isReadOnly ? '' : 'Start coding...',
                        hintStyle: TextStyle(
                          color: AppTheme.textDisabledDark,
                          fontFamily: 'monospace',
                        ),
                      ),
                      cursorColor: AppTheme.primaryCyan,
                      cursorWidth: 2.0,
                      selectionControls: _CyberpunkTextSelectionControls(),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Programming keyboard toolbar
          if (!widget.isReadOnly) _buildProgrammingToolbar(),
        ],
      ),
    );
  }

  List<Widget> _buildLineNumbers() {
    final lines = _controller.text.split('\n');
    return List.generate(lines.length, (index) {
      final lineNumber = index + 1;
      final isCurrentLine = lineNumber == _currentLine;

      return Container(
        height: 19.6, // Match text line height
        alignment: Alignment.centerRight,
        child: Text(
          lineNumber.toString(),
          style: TextStyle(
            fontFamily: 'monospace',
            fontSize: 12.sp,
            color: isCurrentLine
                ? AppTheme.primaryCyan
                : AppTheme.lightGray.withValues(alpha: 0.6),
            fontWeight: isCurrentLine ? FontWeight.w600 : FontWeight.w400,
          ),
        ),
      );
    });
  }

  Widget _buildProgrammingToolbar() {
    final programmingKeys = [
      '{',
      '}',
      '(',
      ')',
      '[',
      ']',
      ';',
      ':',
      '"',
      "'",
      '<',
      '>',
      '/',
      '\\',
      '|',
      '&',
      '=',
      '+',
      '-',
      '*',
      '%',
      '!',
      '?',
      '#',
      '@',
      '\$',
      '^',
      '~',
      '`'
    ];

    return Container(
      height: 6.h,
      decoration: BoxDecoration(
        color: AppTheme.deepSpaceBlue,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(12),
          bottomRight: Radius.circular(12),
        ),
        border: Border(
          top: BorderSide(
            color: AppTheme.borderCyan,
            width: 1.0,
          ),
        ),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 2.w),
        child: Row(
          children: [
            // Tab button
            _buildToolbarButton('TAB', () {
              _insertText('    '); // 4 spaces for tab
            }),

            SizedBox(width: 1.w),

            // Programming symbols
            ...programmingKeys.map((key) => Padding(
                  padding: EdgeInsets.only(right: 1.w),
                  child: _buildToolbarButton(key, () {
                    _insertText(key);
                  }),
                )),
          ],
        ),
      ),
    );
  }

  Widget _buildToolbarButton(String text, VoidCallback onPressed) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        onPressed();
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
        decoration: BoxDecoration(
          color: AppTheme.elevatedDark,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: AppTheme.borderCyan.withValues(alpha: 0.5),
            width: 1.0,
          ),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: AppTheme.primaryCyan,
            fontSize: 12.sp,
            fontWeight: FontWeight.w500,
            fontFamily: text == 'TAB' ? null : 'monospace',
          ),
        ),
      ),
    );
  }
}

/// Custom text selection controls with cyberpunk styling
class _CyberpunkTextSelectionControls extends TextSelectionControls {
  @override
  Widget buildHandle(
      BuildContext context, TextSelectionHandleType type, double textLineHeight,
      [VoidCallback? onTap]) {
    return Container(
      width: 20,
      height: 20,
      decoration: BoxDecoration(
        color: AppTheme.primaryCyan,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryCyan.withValues(alpha: 0.5),
            blurRadius: 4.0,
            spreadRadius: 1.0,
          ),
        ],
      ),
    );
  }

  @override
  Widget buildToolbar(
      BuildContext context,
      Rect globalEditableRegion,
      double textLineHeight,
      Offset selectionMidpoint,
      List<TextSelectionPoint> endpoints,
      TextSelectionDelegate delegate,
      ValueListenable<ClipboardStatus>? clipboardStatus,
      Offset? lastSecondaryTapDownPosition) {
    return _CyberpunkTextSelectionToolbar(
      globalEditableRegion: globalEditableRegion,
      textLineHeight: textLineHeight,
      selectionMidpoint: selectionMidpoint,
      endpoints: endpoints,
      delegate: delegate,
      clipboardStatus: clipboardStatus,
    );
  }

  @override
  Size getHandleSize(double textLineHeight) {
    return const Size(20, 20);
  }

  // Add this method implementation to fix the missing member error
  @override
  Offset getHandleAnchor(TextSelectionHandleType type, double textLineHeight) {
    switch (type) {
      case TextSelectionHandleType.left:
        return Offset(10.0, textLineHeight);
      case TextSelectionHandleType.right:
        return Offset(10.0, textLineHeight);
      case TextSelectionHandleType.collapsed:
        return Offset(10.0, textLineHeight);
    }
  }
}

/// Custom text selection toolbar with cyberpunk styling
class _CyberpunkTextSelectionToolbar extends StatelessWidget {
  final Rect globalEditableRegion;
  final double textLineHeight;
  final Offset selectionMidpoint;
  final List<TextSelectionPoint> endpoints;
  final TextSelectionDelegate delegate;
  final ValueListenable<ClipboardStatus>? clipboardStatus;

  const _CyberpunkTextSelectionToolbar({
    required this.globalEditableRegion,
    required this.textLineHeight,
    required this.selectionMidpoint,
    required this.endpoints,
    required this.delegate,
    this.clipboardStatus,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.elevatedDark,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: AppTheme.borderCyan,
          width: 1.0,
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowCyan,
            blurRadius: 8.0,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildToolbarButton('Cut', () {
            delegate.cutSelection(SelectionChangedCause.toolbar);
          }),
          _buildToolbarButton('Copy', () {
            delegate.copySelection(SelectionChangedCause.toolbar);
          }),
          _buildToolbarButton('Paste', () {
            delegate.pasteText(SelectionChangedCause.toolbar);
          }),
        ],
      ),
    );
  }

  Widget _buildToolbarButton(String text, VoidCallback onPressed) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Text(
          text,
          style: TextStyle(
            color: AppTheme.primaryCyan,
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}