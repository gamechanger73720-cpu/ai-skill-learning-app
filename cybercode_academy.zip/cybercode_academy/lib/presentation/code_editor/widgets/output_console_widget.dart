import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart'; // Add this import for ValueListenable
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

/// Output console widget displaying code execution results
class OutputConsoleWidget extends StatefulWidget {
  final String output;
  final bool isLoading;
  final bool hasError;
  final VoidCallback? onClear;

  const OutputConsoleWidget({
    super.key,
    required this.output,
    this.isLoading = false,
    this.hasError = false,
    this.onClear,
  });

  @override
  State<OutputConsoleWidget> createState() => _OutputConsoleWidgetState();
}

class _OutputConsoleWidgetState extends State<OutputConsoleWidget>
    with TickerProviderStateMixin {
  late AnimationController _loadingController;
  late AnimationController _glowController;
  late Animation<double> _loadingAnimation;
  late Animation<double> _glowAnimation;
  late ScrollController _scrollController;

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();

    _loadingController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _loadingAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _loadingController,
      curve: Curves.easeInOut,
    ));

    _glowController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _glowAnimation = Tween<double>(
      begin: 0.4,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _glowController,
      curve: Curves.easeInOut,
    ));
    _glowController.repeat(reverse: true);

    if (widget.isLoading) {
      _loadingController.repeat();
    }
  }

  @override
  void didUpdateWidget(OutputConsoleWidget oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (widget.isLoading != oldWidget.isLoading) {
      if (widget.isLoading) {
        _loadingController.repeat();
      } else {
        _loadingController.stop();
      }
    }

    // Auto-scroll to bottom when new output is added
    if (widget.output != oldWidget.output && widget.output.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scrollController.hasClients) {
          _scrollController.animateTo(
            _scrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        }
      });
    }
  }

  @override
  void dispose() {
    _loadingController.dispose();
    _glowController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.deepSpaceBlue,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: widget.hasError
              ? AppTheme.brightRed.withValues(alpha: 0.5)
              : AppTheme.borderCyan,
          width: 1.0,
        ),
        boxShadow: [
          BoxShadow(
            color: widget.hasError
                ? AppTheme.brightRed.withValues(alpha: 0.2)
                : AppTheme.shadowCyan,
            blurRadius: 8.0,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          // Console header
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: AppTheme.elevatedDark,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(12),
                topRight: Radius.circular(12),
              ),
              border: Border(
                bottom: BorderSide(
                  color: widget.hasError
                      ? AppTheme.brightRed.withValues(alpha: 0.5)
                      : AppTheme.borderCyan,
                  width: 1.0,
                ),
              ),
            ),
            child: Row(
              children: [
                AnimatedBuilder(
                  animation: _glowAnimation,
                  builder: (context, child) {
                    return Container(
                      padding: EdgeInsets.symmetric(
                          horizontal: 2.w, vertical: 0.5.h),
                      decoration: BoxDecoration(
                        color: (widget.hasError
                                ? AppTheme.brightRed
                                : AppTheme.neonGreen)
                            .withValues(
                          alpha: _glowAnimation.value * 0.2,
                        ),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: (widget.hasError
                                  ? AppTheme.brightRed
                                  : AppTheme.neonGreen)
                              .withValues(
                            alpha: _glowAnimation.value,
                          ),
                          width: 1.0,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CustomIconWidget(
                            iconName: widget.hasError ? 'error' : 'terminal',
                            color: widget.hasError
                                ? AppTheme.brightRed
                                : AppTheme.neonGreen,
                            size: 16,
                          ),
                          SizedBox(width: 1.w),
                          Text(
                            widget.hasError ? 'ERROR' : 'OUTPUT',
                            style: AppTheme.darkTheme.textTheme.labelMedium
                                ?.copyWith(
                              color: AppTheme.pureWhite,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'monospace',
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                const Spacer(),
                if (widget.onClear != null && widget.output.isNotEmpty)
                  GestureDetector(
                    onTap: () {
                      HapticFeedback.lightImpact();
                      widget.onClear!();
                    },
                    child: Container(
                      padding: EdgeInsets.all(1.w),
                      decoration: BoxDecoration(
                        color: AppTheme.elevatedDark,
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: AppTheme.borderCyan.withValues(alpha: 0.5),
                          width: 1.0,
                        ),
                      ),
                      child: CustomIconWidget(
                        iconName: 'clear',
                        color: AppTheme.lightGray,
                        size: 16,
                      ),
                    ),
                  ),
              ],
            ),
          ),

          // Console output area
          Expanded(
            child: Container(
              padding: EdgeInsets.all(3.w),
              child: widget.isLoading
                  ? _buildLoadingIndicator()
                  : _buildOutputContent(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingIndicator() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        AnimatedBuilder(
          animation: _loadingAnimation,
          builder: (context, child) {
            return Container(
              width: 20.w,
              height: 20.w,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: AppTheme.primaryCyan.withValues(alpha: 0.3),
                  width: 2.0,
                ),
              ),
              child: CircularProgressIndicator(
                value: null,
                strokeWidth: 3.0,
                valueColor: AlwaysStoppedAnimation<Color>(
                  AppTheme.primaryCyan.withValues(
                    alpha: _loadingAnimation.value,
                  ),
                ),
              ),
            );
          },
        ),
        SizedBox(height: 2.h),
        AnimatedBuilder(
          animation: _loadingAnimation,
          builder: (context, child) {
            return Text(
              'Executing code...',
              style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.primaryCyan.withValues(
                  alpha: _loadingAnimation.value,
                ),
                fontFamily: 'monospace',
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildOutputContent() {
    if (widget.output.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'code',
              color: AppTheme.lightGray.withValues(alpha: 0.5),
              size: 48,
            ),
            SizedBox(height: 2.h),
            Text(
              'Run your code to see output here',
              style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightGray.withValues(alpha: 0.7),
                fontFamily: 'monospace',
              ),
            ),
          ],
        ),
      );
    }

    return SingleChildScrollView(
      controller: _scrollController,
      child: SelectableText(
        widget.output,
        style: TextStyle(
          fontFamily: 'monospace',
          fontSize: 13.sp,
          color: widget.hasError ? AppTheme.brightRed : AppTheme.pureWhite,
          height: 1.4,
        ),
        selectionControls: _CyberpunkTextSelectionControls(),
      ),
    );
  }
}

/// Custom text selection controls for console output
class _CyberpunkTextSelectionControls extends TextSelectionControls {
  @override
  Widget buildHandle(
      BuildContext context, TextSelectionHandleType type, double textLineHeight,
      [VoidCallback? onTap]) {
    return Container(
      width: 20,
      height: 20,
      decoration: BoxDecoration(
        color: AppTheme.primaryCyan,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryCyan.withValues(alpha: 0.5),
            blurRadius: 4.0,
            spreadRadius: 1.0,
          ),
        ],
      ),
    );
  }

  @override
  Offset getHandleAnchor(TextSelectionHandleType type, double textLineHeight) {
    return Offset.zero;
  }

  @override
  Widget buildToolbar(
      BuildContext context,
      Rect globalEditableRegion,
      double textLineHeight,
      Offset selectionMidpoint,
      List<TextSelectionPoint> endpoints,
      TextSelectionDelegate delegate,
      ValueListenable<ClipboardStatus>? clipboardStatus,
      Offset? lastSecondaryTapDownPosition) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.elevatedDark,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: AppTheme.borderCyan,
          width: 1.0,
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowCyan,
            blurRadius: 8.0,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          GestureDetector(
            onTap: () => delegate.copySelection(SelectionChangedCause.toolbar),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text(
                'Copy',
                style: TextStyle(
                  color: AppTheme.primaryCyan,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Size getHandleSize(double textLineHeight) {
    return const Size(20, 20);
  }
}