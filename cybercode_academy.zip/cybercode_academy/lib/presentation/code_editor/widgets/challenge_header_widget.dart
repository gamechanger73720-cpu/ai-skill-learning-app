import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

/// Collapsible header widget showing challenge details and timer
class ChallengeHeaderWidget extends StatefulWidget {
  final String challengeTitle;
  final String difficulty;
  final int timeLimit; // in seconds
  final int timeRemaining; // in seconds
  final VoidCallback? onCollapse;
  final VoidCallback? onExpand;
  final bool isCollapsed;

  const ChallengeHeaderWidget({
    super.key,
    required this.challengeTitle,
    required this.difficulty,
    required this.timeLimit,
    required this.timeRemaining,
    this.onCollapse,
    this.onExpand,
    this.isCollapsed = false,
  });

  @override
  State<ChallengeHeaderWidget> createState() => _ChallengeHeaderWidgetState();
}

class _ChallengeHeaderWidgetState extends State<ChallengeHeaderWidget>
    with TickerProviderStateMixin {
  late AnimationController _glowController;
  late AnimationController _warningController;
  late Animation<double> _glowAnimation;
  late Animation<double> _warningAnimation;

  @override
  void initState() {
    super.initState();

    _glowController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
    _glowAnimation = Tween<double>(
      begin: 0.4,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _glowController,
      curve: Curves.easeInOut,
    ));
    _glowController.repeat(reverse: true);

    _warningController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _warningAnimation = Tween<double>(
      begin: 0.3,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _warningController,
      curve: Curves.easeInOut,
    ));

    // Start warning animation if time is running low
    if (widget.timeRemaining <= 60) {
      _warningController.repeat(reverse: true);
    }
  }

  @override
  void didUpdateWidget(ChallengeHeaderWidget oldWidget) {
    super.didUpdateWidget(oldWidget);

    // Handle warning animation based on time remaining
    if (widget.timeRemaining <= 60 && oldWidget.timeRemaining > 60) {
      _warningController.repeat(reverse: true);
    } else if (widget.timeRemaining > 60 && oldWidget.timeRemaining <= 60) {
      _warningController.stop();
      _warningController.reset();
    }
  }

  @override
  void dispose() {
    _glowController.dispose();
    _warningController.dispose();
    super.dispose();
  }

  String _formatTime(int seconds) {
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  Color _getDifficultyColor(String difficulty) {
    switch (difficulty.toLowerCase()) {
      case 'easy':
        return AppTheme.neonGreen;
      case 'medium':
        return AppTheme.amberOrange;
      case 'hard':
        return AppTheme.brightRed;
      default:
        return AppTheme.primaryCyan;
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      height: widget.isCollapsed ? 8.h : 16.h,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.elevatedDark,
              AppTheme.elevatedDark.withValues(alpha: 0.9),
            ],
          ),
          border: Border(
            bottom: BorderSide(
              color: AppTheme.borderCyan,
              width: 1.0,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: AppTheme.shadowCyan,
              blurRadius: 8.0,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: widget.isCollapsed
            ? _buildCollapsedHeader()
            : _buildExpandedHeader(),
      ),
    );
  }

  Widget _buildCollapsedHeader() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Row(
        children: [
          // Expand button
          GestureDetector(
            onTap: () {
              HapticFeedback.lightImpact();
              widget.onExpand?.call();
            },
            child: Container(
              padding: EdgeInsets.all(1.w),
              decoration: BoxDecoration(
                color: AppTheme.deepSpaceBlue,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(
                  color: AppTheme.borderCyan.withValues(alpha: 0.5),
                  width: 1.0,
                ),
              ),
              child: CustomIconWidget(
                iconName: 'expand_more',
                color: AppTheme.primaryCyan,
                size: 20,
              ),
            ),
          ),

          SizedBox(width: 3.w),

          // Challenge title (truncated)
          Expanded(
            child: Text(
              widget.challengeTitle,
              style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                color: AppTheme.pureWhite,
                fontWeight: FontWeight.w600,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),

          // Timer (compact)
          _buildCompactTimer(),
        ],
      ),
    );
  }

  Widget _buildExpandedHeader() {
    return Padding(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row with collapse button
          Row(
            children: [
              // Collapse button
              GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  widget.onCollapse?.call();
                },
                child: Container(
                  padding: EdgeInsets.all(1.w),
                  decoration: BoxDecoration(
                    color: AppTheme.deepSpaceBlue,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: AppTheme.borderCyan.withValues(alpha: 0.5),
                      width: 1.0,
                    ),
                  ),
                  child: CustomIconWidget(
                    iconName: 'expand_less',
                    color: AppTheme.primaryCyan,
                    size: 20,
                  ),
                ),
              ),

              SizedBox(width: 3.w),

              // Challenge title
              Expanded(
                child: Text(
                  widget.challengeTitle,
                  style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                    color: AppTheme.pureWhite,
                    fontWeight: FontWeight.w700,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),

          SizedBox(height: 2.h),

          // Difficulty and timer row
          Row(
            children: [
              // Difficulty badge
              AnimatedBuilder(
                animation: _glowAnimation,
                builder: (context, child) {
                  return Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                    decoration: BoxDecoration(
                      color: _getDifficultyColor(widget.difficulty).withValues(
                        alpha: _glowAnimation.value * 0.2,
                      ),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color:
                            _getDifficultyColor(widget.difficulty).withValues(
                          alpha: _glowAnimation.value,
                        ),
                        width: 1.0,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color:
                              _getDifficultyColor(widget.difficulty).withValues(
                            alpha: _glowAnimation.value * 0.3,
                          ),
                          blurRadius: 8.0,
                          spreadRadius: 1.0,
                        ),
                      ],
                    ),
                    child: Text(
                      widget.difficulty.toUpperCase(),
                      style: AppTheme.darkTheme.textTheme.labelMedium?.copyWith(
                        color: AppTheme.pureWhite,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      ),
                    ),
                  );
                },
              ),

              const Spacer(),

              // Timer
              _buildFullTimer(),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCompactTimer() {
    final isWarning = widget.timeRemaining <= 60;

    return AnimatedBuilder(
      animation: isWarning ? _warningAnimation : _glowAnimation,
      builder: (context, child) {
        return Container(
          padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
          decoration: BoxDecoration(
            color: (isWarning ? AppTheme.brightRed : AppTheme.primaryCyan)
                .withValues(
              alpha:
                  (isWarning ? _warningAnimation.value : _glowAnimation.value) *
                      0.2,
            ),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(
              color: (isWarning ? AppTheme.brightRed : AppTheme.primaryCyan)
                  .withValues(
                alpha:
                    isWarning ? _warningAnimation.value : _glowAnimation.value,
              ),
              width: 1.0,
            ),
          ),
          child: Text(
            _formatTime(widget.timeRemaining),
            style: AppTheme.darkTheme.textTheme.labelMedium?.copyWith(
              color: AppTheme.pureWhite,
              fontWeight: FontWeight.w600,
              fontFamily: 'monospace',
            ),
          ),
        );
      },
    );
  }

  Widget _buildFullTimer() {
    final isWarning = widget.timeRemaining <= 60;
    final progress = widget.timeRemaining / widget.timeLimit;

    return AnimatedBuilder(
      animation: isWarning ? _warningAnimation : _glowAnimation,
      builder: (context, child) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            // Timer display
            Container(
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
              decoration: BoxDecoration(
                color: (isWarning ? AppTheme.brightRed : AppTheme.primaryCyan)
                    .withValues(
                  alpha: (isWarning
                          ? _warningAnimation.value
                          : _glowAnimation.value) *
                      0.2,
                ),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: (isWarning ? AppTheme.brightRed : AppTheme.primaryCyan)
                      .withValues(
                    alpha: isWarning
                        ? _warningAnimation.value
                        : _glowAnimation.value,
                  ),
                  width: 1.0,
                ),
                boxShadow: [
                  BoxShadow(
                    color:
                        (isWarning ? AppTheme.brightRed : AppTheme.primaryCyan)
                            .withValues(
                      alpha: (isWarning
                              ? _warningAnimation.value
                              : _glowAnimation.value) *
                          0.3,
                    ),
                    blurRadius: 8.0,
                    spreadRadius: 1.0,
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomIconWidget(
                    iconName: isWarning ? 'timer' : 'access_time',
                    color: AppTheme.pureWhite,
                    size: 16,
                  ),
                  SizedBox(width: 1.w),
                  Text(
                    _formatTime(widget.timeRemaining),
                    style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                      color: AppTheme.pureWhite,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'monospace',
                    ),
                  ),
                ],
              ),
            ),

            SizedBox(height: 1.h),

            // Progress bar
            Container(
              width: 25.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.elevatedDark,
                borderRadius: BorderRadius.circular(2),
                border: Border.all(
                  color: AppTheme.borderCyan.withValues(alpha: 0.3),
                  width: 0.5,
                ),
              ),
              child: FractionallySizedBox(
                alignment: Alignment.centerLeft,
                widthFactor: progress.clamp(0.0, 1.0),
                child: Container(
                  decoration: BoxDecoration(
                    color:
                        isWarning ? AppTheme.brightRed : AppTheme.primaryCyan,
                    borderRadius: BorderRadius.circular(2),
                    boxShadow: [
                      BoxShadow(
                        color: (isWarning
                                ? AppTheme.brightRed
                                : AppTheme.primaryCyan)
                            .withValues(alpha: 0.5),
                        blurRadius: 4.0,
                        spreadRadius: 1.0,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
