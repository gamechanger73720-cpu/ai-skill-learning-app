import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'dart:math' as math;

import '../../../core/app_export.dart';

/// Floating action buttons for code editor operations
class FloatingActionButtonsWidget extends StatefulWidget {
  final VoidCallback? onRun;
  final VoidCallback? onReset;
  final VoidCallback? onHint;
  final VoidCallback? onUndo;
  final VoidCallback? onRedo;
  final bool isRunning;
  final bool canUndo;
  final bool canRedo;

  const FloatingActionButtonsWidget({
    super.key,
    this.onRun,
    this.onReset,
    this.onHint,
    this.onUndo,
    this.onRedo,
    this.isRunning = false,
    this.canUndo = false,
    this.canRedo = false,
  });

  @override
  State<FloatingActionButtonsWidget> createState() =>
      _FloatingActionButtonsWidgetState();
}

class _FloatingActionButtonsWidgetState
    extends State<FloatingActionButtonsWidget> with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late AnimationController _particleController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _particleAnimation;
  bool _isExpanded = false;

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _pulseAnimation = Tween<double>(
      begin: 0.8,
      end: 1.2,
    ).animate(CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    ));
    _pulseController.repeat(reverse: true);

    _particleController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
    _particleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _particleController,
      curve: Curves.easeInOut,
    ));
    _particleController.repeat();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _particleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Main run button
        Positioned(
          bottom: 2.h,
          right: 4.w,
          child: _buildMainRunButton(),
        ),

        // Secondary action buttons
        if (_isExpanded) ...[
          Positioned(
            bottom: 12.h,
            right: 4.w,
            child: _buildSecondaryButton(
              icon: 'refresh',
              color: AppTheme.amberOrange,
              onTap: widget.onReset,
              tooltip: 'Reset Code',
            ),
          ),
          Positioned(
            bottom: 20.h,
            right: 4.w,
            child: _buildSecondaryButton(
              icon: 'lightbulb',
              color: AppTheme.neonGreen,
              onTap: widget.onHint,
              tooltip: 'Get Hint',
            ),
          ),
        ],

        // Undo/Redo buttons (left side)
        Positioned(
          bottom: 2.h,
          left: 4.w,
          child: Row(
            children: [
              _buildUndoRedoButton(
                icon: 'undo',
                onTap: widget.canUndo ? widget.onUndo : null,
                isEnabled: widget.canUndo,
              ),
              SizedBox(width: 2.w),
              _buildUndoRedoButton(
                icon: 'redo',
                onTap: widget.canRedo ? widget.onRedo : null,
                isEnabled: widget.canRedo,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMainRunButton() {
    return GestureDetector(
      onTap: () {
        if (!widget.isRunning) {
          HapticFeedback.mediumImpact();
          widget.onRun?.call();
        }
      },
      onLongPress: () {
        HapticFeedback.heavyImpact();
        setState(() {
          _isExpanded = !_isExpanded;
        });
      },
      child: AnimatedBuilder(
        animation: _pulseAnimation,
        builder: (context, child) {
          return Transform.scale(
            scale: widget.isRunning ? _pulseAnimation.value : 1.0,
            child: Container(
              width: 16.w,
              height: 16.w,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    AppTheme.primaryCyan,
                    AppTheme.primaryCyan.withValues(alpha: 0.8),
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.primaryCyan.withValues(alpha: 0.5),
                    blurRadius: widget.isRunning ? 20.0 : 12.0,
                    spreadRadius: widget.isRunning ? 4.0 : 2.0,
                  ),
                ],
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Particle effects for hint button
                  if (_isExpanded)
                    AnimatedBuilder(
                      animation: _particleAnimation,
                      builder: (context, child) {
                        return CustomPaint(
                          size: Size(16.w, 16.w),
                          painter: _ParticleEffectPainter(
                            animation: _particleAnimation,
                            color: AppTheme.primaryCyan,
                          ),
                        );
                      },
                    ),

                  // Main icon
                  CustomIconWidget(
                    iconName:
                        widget.isRunning ? 'hourglass_empty' : 'play_arrow',
                    color: AppTheme.deepSpaceBlue,
                    size: 32,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSecondaryButton({
    required String icon,
    required Color color,
    required VoidCallback? onTap,
    required String tooltip,
  }) {
    return AnimatedScale(
      scale: _isExpanded ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 300),
      curve: Curves.elasticOut,
      child: GestureDetector(
        onTap: () {
          if (onTap != null) {
            HapticFeedback.lightImpact();
            onTap();
            setState(() {
              _isExpanded = false;
            });
          }
        },
        child: Container(
          width: 12.w,
          height: 12.w,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color,
            boxShadow: [
              BoxShadow(
                color: color.withValues(alpha: 0.4),
                blurRadius: 8.0,
                spreadRadius: 1.0,
              ),
            ],
          ),
          child: CustomIconWidget(
            iconName: icon,
            color: AppTheme.deepSpaceBlue,
            size: 24,
          ),
        ),
      ),
    );
  }

  Widget _buildUndoRedoButton({
    required String icon,
    required VoidCallback? onTap,
    required bool isEnabled,
  }) {
    return GestureDetector(
      onTap: () {
        if (isEnabled && onTap != null) {
          HapticFeedback.lightImpact();
          onTap();
        }
      },
      child: Container(
        width: 12.w,
        height: 12.w,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: isEnabled
              ? AppTheme.elevatedDark
              : AppTheme.elevatedDark.withValues(alpha: 0.5),
          border: Border.all(
            color: isEnabled
                ? AppTheme.borderCyan
                : AppTheme.borderCyan.withValues(alpha: 0.3),
            width: 1.0,
          ),
          boxShadow: isEnabled
              ? [
                  BoxShadow(
                    color: AppTheme.shadowCyan,
                    blurRadius: 4.0,
                    offset: const Offset(0, 2),
                  ),
                ]
              : null,
        ),
        child: CustomIconWidget(
          iconName: icon,
          color: isEnabled
              ? AppTheme.primaryCyan
              : AppTheme.lightGray.withValues(alpha: 0.5),
          size: 20,
        ),
      ),
    );
  }
}

/// Custom painter for particle effects
class _ParticleEffectPainter extends CustomPainter {
  final Animation<double> animation;
  final Color color;

  _ParticleEffectPainter({
    required this.animation,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withValues(alpha: 0.6)
      ..style = PaintingStyle.fill;

    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    // Draw rotating particles
    for (int i = 0; i < 8; i++) {
      final angle = (i * 45.0 + animation.value * 360.0) * (3.14159 / 180.0);
      final particleRadius = radius * 0.8;
      final particleX = center.dx + particleRadius * math.cos(angle);
      final particleY = center.dy + particleRadius * math.sin(angle);

      final particlePaint = Paint()
        ..color = color.withValues(alpha: 0.4 * (1.0 - animation.value))
        ..style = PaintingStyle.fill;

      canvas.drawCircle(
        Offset(particleX, particleY),
        2.0 * (1.0 - animation.value),
        particlePaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

// Helper function for cos calculation
double cos(double radians) {
  return math.cos(radians);
}

// Extension for cos calculation
extension on double {
  double get cos {
    return math.cos(this);
  }
}