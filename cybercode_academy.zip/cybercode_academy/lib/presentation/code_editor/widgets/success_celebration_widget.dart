import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'dart:math' as math;

import '../../../core/app_export.dart';

/// Success celebration widget with holographic effects and XP display
class SuccessCelebrationWidget extends StatefulWidget {
  final int xpGained;
  final String nextChallengeTitle;
  final VoidCallback? onNextChallenge;
  final VoidCallback? onClose;

  const SuccessCelebrationWidget({
    super.key,
    required this.xpGained,
    required this.nextChallengeTitle,
    this.onNextChallenge,
    this.onClose,
  });

  @override
  State<SuccessCelebrationWidget> createState() =>
      _SuccessCelebrationWidgetState();
}

class _SuccessCelebrationWidgetState extends State<SuccessCelebrationWidget>
    with TickerProviderStateMixin {
  late AnimationController _holographicController;
  late AnimationController _xpController;
  late AnimationController _particleController;
  late Animation<double> _holographicAnimation;
  late Animation<double> _xpAnimation;
  late Animation<double> _particleAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();

    _holographicController = AnimationController(
      duration: const Duration(milliseconds: 3000),
      vsync: this,
    );
    _holographicAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _holographicController,
      curve: Curves.easeInOut,
    ));

    _xpController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
    _xpAnimation = Tween<double>(
      begin: 0.0,
      end: widget.xpGained.toDouble(),
    ).animate(CurvedAnimation(
      parent: _xpController,
      curve: Curves.elasticOut,
    ));

    _particleController = AnimationController(
      duration: const Duration(milliseconds: 4000),
      vsync: this,
    );
    _particleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _particleController,
      curve: Curves.easeOut,
    ));

    _scaleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _holographicController,
      curve: Curves.elasticOut,
    ));

    // Start animations
    _holographicController.forward();
    _xpController.forward();
    _particleController.forward();

    // Trigger haptic feedback
    HapticFeedback.heavyImpact();
  }

  @override
  void dispose() {
    _holographicController.dispose();
    _xpController.dispose();
    _particleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          color: AppTheme.deepSpaceBlue.withValues(alpha: 0.95),
        ),
        child: Stack(
          children: [
            // Particle effects background
            AnimatedBuilder(
              animation: _particleAnimation,
              builder: (context, child) {
                return CustomPaint(
                  size: Size(100.w, 100.h),
                  painter: _ParticleEffectPainter(
                    animation: _particleAnimation,
                    color: AppTheme.primaryCyan,
                  ),
                );
              },
            ),

            // Main celebration content
            Center(
              child: AnimatedBuilder(
                animation: _scaleAnimation,
                builder: (context, child) {
                  return Transform.scale(
                    scale: _scaleAnimation.value,
                    child: Container(
                      width: 80.w,
                      padding: EdgeInsets.all(6.w),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            AppTheme.elevatedDark.withValues(alpha: 0.9),
                            AppTheme.deepSpaceBlue.withValues(alpha: 0.9),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: AppTheme.primaryCyan,
                          width: 2.0,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.primaryCyan.withValues(alpha: 0.5),
                            blurRadius: 20.0,
                            spreadRadius: 4.0,
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Success icon with holographic effect
                          _buildHolographicIcon(),

                          SizedBox(height: 3.h),

                          // Success message
                          AnimatedBuilder(
                            animation: _holographicAnimation,
                            builder: (context, child) {
                              return Opacity(
                                opacity: _holographicAnimation.value,
                                child: Text(
                                  'CHALLENGE COMPLETED!',
                                  style: AppTheme
                                      .darkTheme.textTheme.headlineSmall
                                      ?.copyWith(
                                    color: AppTheme.neonGreen,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 2.0,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              );
                            },
                          ),

                          SizedBox(height: 2.h),

                          // XP gained display
                          _buildXPDisplay(),

                          SizedBox(height: 4.h),

                          // Next challenge info
                          _buildNextChallengeInfo(),

                          SizedBox(height: 4.h),

                          // Action buttons
                          _buildActionButtons(),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),

            // Close button
            Positioned(
              top: 8.h,
              right: 4.w,
              child: GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  widget.onClose?.call();
                },
                child: Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: AppTheme.elevatedDark.withValues(alpha: 0.8),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: AppTheme.borderCyan,
                      width: 1.0,
                    ),
                  ),
                  child: CustomIconWidget(
                    iconName: 'close',
                    color: AppTheme.lightGray,
                    size: 24,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHolographicIcon() {
    return AnimatedBuilder(
      animation: _holographicController,
      builder: (context, child) {
        return Container(
          width: 20.w,
          height: 20.w,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              colors: [
                AppTheme.neonGreen.withValues(
                  alpha: _holographicAnimation.value * 0.8,
                ),
                AppTheme.primaryCyan.withValues(
                  alpha: _holographicAnimation.value * 0.6,
                ),
                Colors.transparent,
              ],
            ),
            boxShadow: [
              BoxShadow(
                color: AppTheme.neonGreen.withValues(
                  alpha: _holographicAnimation.value * 0.8,
                ),
                blurRadius: 30.0,
                spreadRadius: 10.0,
              ),
            ],
          ),
          child: CustomIconWidget(
            iconName: 'check_circle',
            color: AppTheme.neonGreen,
            size: 64,
          ),
        );
      },
    );
  }

  Widget _buildXPDisplay() {
    return AnimatedBuilder(
      animation: _xpAnimation,
      builder: (context, child) {
        return Container(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                AppTheme.hotPink.withValues(alpha: 0.2),
                AppTheme.primaryCyan.withValues(alpha: 0.2),
              ],
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: AppTheme.hotPink,
              width: 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: AppTheme.hotPink.withValues(alpha: 0.3),
                blurRadius: 12.0,
                spreadRadius: 2.0,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomIconWidget(
                iconName: 'star',
                color: AppTheme.hotPink,
                size: 32,
              ),
              SizedBox(width: 2.w),
              Text(
                '+${_xpAnimation.value.round()} XP',
                style: AppTheme.darkTheme.textTheme.headlineMedium?.copyWith(
                  color: AppTheme.hotPink,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.0,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildNextChallengeInfo() {
    return AnimatedBuilder(
      animation: _holographicAnimation,
      builder: (context, child) {
        return Opacity(
          opacity: _holographicAnimation.value,
          child: Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.elevatedDark.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.borderCyan.withValues(alpha: 0.5),
                width: 1.0,
              ),
            ),
            child: Column(
              children: [
                Text(
                  'NEXT CHALLENGE',
                  style: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
                    color: AppTheme.primaryCyan,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 1.0,
                  ),
                ),
                SizedBox(height: 1.h),
                Text(
                  widget.nextChallengeTitle,
                  style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                    color: AppTheme.pureWhite,
                    fontWeight: FontWeight.w600,
                  ),
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildActionButtons() {
    return AnimatedBuilder(
      animation: _holographicAnimation,
      builder: (context, child) {
        return Opacity(
          opacity: _holographicAnimation.value,
          child: Row(
            children: [
              // Continue button
              Expanded(
                child: GestureDetector(
                  onTap: () {
                    HapticFeedback.mediumImpact();
                    widget.onNextChallenge?.call();
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 2.h),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          AppTheme.primaryCyan,
                          AppTheme.primaryCyan.withValues(alpha: 0.8),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.primaryCyan.withValues(alpha: 0.5),
                          blurRadius: 12.0,
                          spreadRadius: 2.0,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'CONTINUE',
                          style: AppTheme.darkTheme.textTheme.titleMedium
                              ?.copyWith(
                            color: AppTheme.deepSpaceBlue,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.0,
                          ),
                        ),
                        SizedBox(width: 2.w),
                        CustomIconWidget(
                          iconName: 'arrow_forward',
                          color: AppTheme.deepSpaceBlue,
                          size: 24,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// Custom painter for particle effects
class _ParticleEffectPainter extends CustomPainter {
  final Animation<double> animation;
  final Color color;

  _ParticleEffectPainter({
    required this.animation,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withValues(alpha: 0.6)
      ..style = PaintingStyle.fill;

    final center = Offset(size.width / 2, size.height / 2);

    // Draw floating particles
    for (int i = 0; i < 20; i++) {
      final angle = (i * 18.0) * (3.14159 / 180.0);
      final distance = (size.width * 0.3) * animation.value;
      final particleX = center.dx + distance * math.cos(angle);
      final particleY =
          center.dy + distance * math.sin(angle) - (animation.value * 100);

      final particlePaint = Paint()
        ..color = color.withValues(alpha: 0.8 * (1.0 - animation.value))
        ..style = PaintingStyle.fill;

      canvas.drawCircle(
        Offset(particleX, particleY),
        3.0 * (1.0 - animation.value),
        particlePaint,
      );
    }

    // Draw sparkle effects
    for (int i = 0; i < 15; i++) {
      final sparkleX = (i * size.width / 15) + (animation.value * 50);
      final sparkleY = size.height * 0.2 + (i % 3) * size.height * 0.3;

      final sparklePaint = Paint()
        ..color = color.withValues(alpha: 0.5 * animation.value)
        ..style = PaintingStyle.fill;

      canvas.drawCircle(
        Offset(sparkleX % size.width, sparkleY),
        2.0,
        sparklePaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}