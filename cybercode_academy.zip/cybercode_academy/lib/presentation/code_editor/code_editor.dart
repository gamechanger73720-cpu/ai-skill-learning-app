import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import './widgets/challenge_header_widget.dart';
import './widgets/code_editor_widget.dart';
import './widgets/floating_action_buttons_widget.dart';
import './widgets/output_console_widget.dart';
import './widgets/success_celebration_widget.dart';

/// Code Editor screen providing full-featured mobile coding environment
class CodeEditor extends StatefulWidget {
  const CodeEditor({super.key});

  @override
  State<CodeEditor> createState() => _CodeEditorState();
}

class _CodeEditorState extends State<CodeEditor> with TickerProviderStateMixin {
  // Controllers and state
  late TabController _tabController;
  String _currentCode = '';
  String _output = '';
  bool _isRunning = false;
  bool _hasError = false;
  bool _isHeaderCollapsed = false;
  bool _showSuccessCelebration = false;
  int _currentBottomIndex = 2; // Code tab

  // Challenge data
  final Map<String, dynamic> _currentChallenge = {
    "id": 1,
    "title": "Array Sum Calculator",
    "description":
        "Write a function that calculates the sum of all elements in an array",
    "difficulty": "Easy",
    "timeLimit": 1800, // 30 minutes
    "timeRemaining": 1650, // 27.5 minutes remaining
    "language": "Java",
    "starterCode": """public class Solution {
    public int arraySum(int[] nums) {
        // Write your code here
        int sum = 0;
        
        return sum;
    }
}""",
    "expectedOutput": "Sum: 15",
    "testCases": [
      {"input": "[1, 2, 3, 4, 5]", "output": "15"},
      {"input": "[10, -5, 3]", "output": "8"},
      {"input": "[]", "output": "0"},
    ],
  };

  // Undo/Redo functionality
  final List<String> _codeHistory = [];
  int _historyIndex = -1;
  bool _canUndo = false;
  bool _canRedo = false;

  // Auto-save timer
  int _autoSaveCounter = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _currentCode = _currentChallenge["starterCode"] as String;
    _addToHistory(_currentCode);

    // Start auto-save timer
    _startAutoSaveTimer();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _startAutoSaveTimer() {
    Future.delayed(const Duration(seconds: 30), () {
      if (mounted) {
        _autoSave();
        _startAutoSaveTimer();
      }
    });
  }

  void _autoSave() {
    if (_currentCode.isNotEmpty) {
      setState(() {
        _autoSaveCounter++;
      });

      // Show subtle flash animation
      HapticFeedback.selectionClick();

      // Simulate auto-save (in real app, save to local storage)
      debugPrint('Auto-saved code at ${DateTime.now()}');
    }
  }

  void _addToHistory(String code) {
    // Remove any history after current index
    if (_historyIndex < _codeHistory.length - 1) {
      _codeHistory.removeRange(_historyIndex + 1, _codeHistory.length);
    }

    // Add new code to history
    _codeHistory.add(code);
    _historyIndex = _codeHistory.length - 1;

    // Limit history size
    if (_codeHistory.length > 50) {
      _codeHistory.removeAt(0);
      _historyIndex--;
    }

    _updateUndoRedoState();
  }

  void _updateUndoRedoState() {
    setState(() {
      _canUndo = _historyIndex > 0;
      _canRedo = _historyIndex < _codeHistory.length - 1;
    });
  }

  void _undo() {
    if (_canUndo) {
      setState(() {
        _historyIndex--;
        _currentCode = _codeHistory[_historyIndex];
      });
      _updateUndoRedoState();
      HapticFeedback.lightImpact();
    }
  }

  void _redo() {
    if (_canRedo) {
      setState(() {
        _historyIndex++;
        _currentCode = _codeHistory[_historyIndex];
      });
      _updateUndoRedoState();
      HapticFeedback.lightImpact();
    }
  }

  void _onCodeChanged(String code) {
    if (code != _currentCode) {
      setState(() {
        _currentCode = code;
      });

      // Add to history after a delay to avoid too many entries
      Future.delayed(const Duration(milliseconds: 500), () {
        if (mounted && code == _currentCode) {
          _addToHistory(code);
        }
      });
    }
  }

  Future<void> _runCode() async {
    if (_isRunning) return;

    setState(() {
      _isRunning = true;
      _hasError = false;
      _output = '';
    });

    HapticFeedback.mediumImpact();

    try {
      // Simulate code execution
      await Future.delayed(const Duration(seconds: 2));

      // Mock code execution logic
      final result = _executeCode(_currentCode);

      setState(() {
        _output = result['output'] as String;
        _hasError = result['hasError'] as bool;
        _isRunning = false;
      });

      // Check if challenge is completed successfully
      if (!_hasError && _output.contains('15')) {
        Future.delayed(const Duration(milliseconds: 500), () {
          setState(() {
            _showSuccessCelebration = true;
          });
        });
      }
    } catch (e) {
      setState(() {
        _output = 'Error: ${e.toString()}';
        _hasError = true;
        _isRunning = false;
      });
    }
  }

  Map<String, dynamic> _executeCode(String code) {
    // Mock code execution - in real app, this would use a code execution service
    if (code.contains('sum += nums[i]') ||
        code.contains('sum = sum + nums[i]')) {
      return {
        'output': '''Test Case 1: [1, 2, 3, 4, 5]
Expected: 15
Your Output: 15
✓ PASSED

Test Case 2: [10, -5, 3]
Expected: 8
Your Output: 8
✓ PASSED

Test Case 3: []
Expected: 0
Your Output: 0
✓ PASSED

All test cases passed! 🎉''',
        'hasError': false,
      };
    } else if (code.contains('// Write your code here')) {
      return {
        'output': 'Error: Please implement the arraySum method.',
        'hasError': true,
      };
    } else {
      return {
        'output': '''Test Case 1: [1, 2, 3, 4, 5]
Expected: 15
Your Output: 0
✗ FAILED

Please check your implementation.''',
        'hasError': true,
      };
    }
  }

  void _resetCode() {
    setState(() {
      _currentCode = _currentChallenge["starterCode"] as String;
      _output = '';
      _hasError = false;
    });
    _addToHistory(_currentCode);
    HapticFeedback.lightImpact();
  }

  void _showHint() {
    showDialog(
      context: context,
      builder: (context) => _buildHintDialog(),
    );
  }

  void _clearOutput() {
    setState(() {
      _output = '';
      _hasError = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.deepSpaceBlue,
      appBar: CustomAppBar.codeEditor(
        title: 'Code Editor',
        onRunPressed: _runCode,
        onSavePressed: _autoSave,
      ),
      body: Stack(
        children: [
          Column(
            children: [
              // Challenge header
              ChallengeHeaderWidget(
                challengeTitle: _currentChallenge["title"] as String,
                difficulty: _currentChallenge["difficulty"] as String,
                timeLimit: _currentChallenge["timeLimit"] as int,
                timeRemaining: _currentChallenge["timeRemaining"] as int,
                isCollapsed: _isHeaderCollapsed,
                onCollapse: () {
                  setState(() {
                    _isHeaderCollapsed = true;
                  });
                },
                onExpand: () {
                  setState(() {
                    _isHeaderCollapsed = false;
                  });
                },
              ),

              // Main editor area
              Expanded(
                child: Container(
                  margin: EdgeInsets.all(2.w),
                  child: _buildSplitView(),
                ),
              ),
            ],
          ),

          // Floating action buttons
          FloatingActionButtonsWidget(
            onRun: _runCode,
            onReset: _resetCode,
            onHint: _showHint,
            onUndo: _undo,
            onRedo: _redo,
            isRunning: _isRunning,
            canUndo: _canUndo,
            canRedo: _canRedo,
          ),

          // Success celebration overlay
          if (_showSuccessCelebration)
            SuccessCelebrationWidget(
              xpGained: 150,
              nextChallengeTitle: "Binary Search Implementation",
              onNextChallenge: () {
                setState(() {
                  _showSuccessCelebration = false;
                });
                Navigator.pushNamed(context, '/learning-path');
              },
              onClose: () {
                setState(() {
                  _showSuccessCelebration = false;
                });
              },
            ),
        ],
      ),
      bottomNavigationBar: CustomBottomBar(
        currentIndex: _currentBottomIndex,
        onTap: (index) {
          setState(() {
            _currentBottomIndex = index;
          });
        },
      ),
    );
  }

  Widget _buildSplitView() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isLandscape = constraints.maxWidth > constraints.maxHeight;

        if (isLandscape) {
          // Landscape: Side by side layout
          return Row(
            children: [
              Expanded(
                flex: 3,
                child: CodeEditorWidget(
                  initialCode: _currentCode,
                  language: _currentChallenge["language"] as String,
                  onCodeChanged: _onCodeChanged,
                  onRun: _runCode,
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                flex: 2,
                child: OutputConsoleWidget(
                  output: _output,
                  isLoading: _isRunning,
                  hasError: _hasError,
                  onClear: _clearOutput,
                ),
              ),
            ],
          );
        } else {
          // Portrait: Stacked layout with draggable divider
          return Column(
            children: [
              Expanded(
                flex: 3,
                child: CodeEditorWidget(
                  initialCode: _currentCode,
                  language: _currentChallenge["language"] as String,
                  onCodeChanged: _onCodeChanged,
                  onRun: _runCode,
                ),
              ),

              // Draggable divider
              GestureDetector(
                onVerticalDragUpdate: (details) {
                  // Handle drag to resize panels
                  HapticFeedback.selectionClick();
                },
                child: Container(
                  height: 1.h,
                  width: double.infinity,
                  color: AppTheme.borderCyan,
                  child: Center(
                    child: Container(
                      width: 10.w,
                      height: 0.5.h,
                      decoration: BoxDecoration(
                        color: AppTheme.primaryCyan,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                ),
              ),

              Expanded(
                flex: 2,
                child: OutputConsoleWidget(
                  output: _output,
                  isLoading: _isRunning,
                  hasError: _hasError,
                  onClear: _clearOutput,
                ),
              ),
            ],
          );
        }
      },
    );
  }

  Widget _buildHintDialog() {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: EdgeInsets.all(6.w),
        decoration: BoxDecoration(
          color: AppTheme.elevatedDark,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: AppTheme.neonGreen,
            width: 2.0,
          ),
          boxShadow: [
            BoxShadow(
              color: AppTheme.neonGreen.withValues(alpha: 0.3),
              blurRadius: 20.0,
              spreadRadius: 4.0,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                CustomIconWidget(
                  iconName: 'lightbulb',
                  color: AppTheme.neonGreen,
                  size: 32,
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Text(
                    'HINT',
                    style: AppTheme.darkTheme.textTheme.headlineSmall?.copyWith(
                      color: AppTheme.neonGreen,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.0,
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: CustomIconWidget(
                    iconName: 'close',
                    color: AppTheme.lightGray,
                    size: 24,
                  ),
                ),
              ],
            ),
            SizedBox(height: 3.h),
            Container(
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: AppTheme.deepSpaceBlue.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppTheme.borderCyan.withValues(alpha: 0.5),
                  width: 1.0,
                ),
              ),
              child: Text(
                '''💡 To calculate the sum of array elements:

1. Initialize a variable to store the sum (int sum = 0)
2. Use a for loop to iterate through the array
3. Add each element to the sum variable
4. Return the final sum

Example:
for (int i = 0; i < nums.length; i++) {
    sum += nums[i];
}''',
                style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.pureWhite,
                  height: 1.5,
                  fontFamily: 'monospace',
                ),
              ),
            ),
            SizedBox(height: 3.h),
            GestureDetector(
              onTap: () {
                Navigator.pop(context);
                HapticFeedback.lightImpact();
              },
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(vertical: 2.h),
                decoration: BoxDecoration(
                  color: AppTheme.neonGreen,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.neonGreen.withValues(alpha: 0.3),
                      blurRadius: 8.0,
                      spreadRadius: 2.0,
                    ),
                  ],
                ),
                child: Text(
                  'GOT IT!',
                  style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                    color: AppTheme.deepSpaceBlue,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.0,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
