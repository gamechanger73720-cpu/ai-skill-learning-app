import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

enum LessonType { text, code, video, quiz }

class LessonContentWidget extends StatefulWidget {
  final LessonType lessonType;
  final Map<String, dynamic> contentData;
  final VoidCallback? onCodeCopy;
  final Function(String)? onCodeSubmit;
  final Function(int)? onQuizAnswer;

  const LessonContentWidget({
    super.key,
    required this.lessonType,
    required this.contentData,
    this.onCodeCopy,
    this.onCodeSubmit,
    this.onQuizAnswer,
  });

  @override
  State<LessonContentWidget> createState() => _LessonContentWidgetState();
}

class _LessonContentWidgetState extends State<LessonContentWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  final TextEditingController _codeController = TextEditingController();
  int? _selectedQuizAnswer;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    _animationController.forward();

    if (widget.lessonType == LessonType.code &&
        widget.contentData['initialCode'] != null) {
      _codeController.text = widget.contentData['initialCode'];
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    _codeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(4.w),
        child: _buildContentByType(),
      ),
    );
  }

  Widget _buildContentByType() {
    switch (widget.lessonType) {
      case LessonType.text:
        return _buildTextContent();
      case LessonType.code:
        return _buildCodeContent();
      case LessonType.video:
        return _buildVideoContent();
      case LessonType.quiz:
        return _buildQuizContent();
    }
  }

  Widget _buildTextContent() {
    final content = widget.contentData['content'] as String? ?? '';
    final highlights = widget.contentData['highlights'] as List<String>? ?? [];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: AppTheme.elevatedDark,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: AppTheme.borderCyan,
              width: 1.0,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                content,
                style: AppTheme.darkTheme.textTheme.bodyLarge?.copyWith(
                  color: AppTheme.pureWhite,
                  height: 1.6,
                ),
              ),
              if (highlights.isNotEmpty) ...[
                SizedBox(height: 3.h),
                Text(
                  'Key Points:',
                  style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                    color: AppTheme.primaryCyan,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 1.h),
                ...highlights.map((highlight) => Padding(
                      padding: EdgeInsets.only(bottom: 1.h),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.only(top: 0.5.h, right: 2.w),
                            width: 6,
                            height: 6,
                            decoration: const BoxDecoration(
                              color: AppTheme.primaryCyan,
                              shape: BoxShape.circle,
                            ),
                          ),
                          Expanded(
                            child: Text(
                              highlight,
                              style: AppTheme.darkTheme.textTheme.bodyMedium
                                  ?.copyWith(
                                color: AppTheme.lightGray,
                              ),
                            ),
                          ),
                        ],
                      ),
                    )),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildCodeContent() {
    final title = widget.contentData['title'] as String? ?? 'Code Challenge';
    final description = widget.contentData['description'] as String? ?? '';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Challenge description
        Container(
          width: double.infinity,
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: AppTheme.elevatedDark,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: AppTheme.borderCyan,
              width: 1.0,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                  color: AppTheme.primaryCyan,
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (description.isNotEmpty) ...[
                SizedBox(height: 2.h),
                Text(
                  description,
                  style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.lightGray,
                  ),
                ),
              ],
            ],
          ),
        ),
        SizedBox(height: 3.h),

        // Code editor
        Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: AppTheme.deepSpaceBlue,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: AppTheme.primaryCyan.withValues(alpha: 0.3),
              width: 1.0,
            ),
          ),
          child: Column(
            children: [
              // Editor header
              Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                decoration: BoxDecoration(
                  color: AppTheme.elevatedDark,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(16),
                    topRight: Radius.circular(16),
                  ),
                  border: Border(
                    bottom: BorderSide(
                      color: AppTheme.borderCyan,
                      width: 1.0,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    Text(
                      'Code Editor',
                      style: AppTheme.darkTheme.textTheme.titleSmall?.copyWith(
                        color: AppTheme.pureWhite,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () {
                        HapticFeedback.lightImpact();
                        Clipboard.setData(
                            ClipboardData(text: _codeController.text));
                        widget.onCodeCopy?.call();
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Code copied to clipboard',
                              style: AppTheme.darkTheme.textTheme.bodyMedium
                                  ?.copyWith(
                                color: AppTheme.pureWhite,
                              ),
                            ),
                            backgroundColor: AppTheme.elevatedDark,
                            behavior: SnackBarBehavior.floating,
                          ),
                        );
                      },
                      child: Container(
                        padding: EdgeInsets.all(1.w),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryCyan.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: AppTheme.primaryCyan,
                            width: 1.0,
                          ),
                        ),
                        child: CustomIconWidget(
                          iconName: 'content_copy',
                          color: AppTheme.primaryCyan,
                          size: 16,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Code input area
              Container(
                width: double.infinity,
                constraints: BoxConstraints(minHeight: 20.h),
                padding: EdgeInsets.all(4.w),
                child: TextField(
                  controller: _codeController,
                  maxLines: null,
                  style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                    fontFamily: 'monospace',
                    color: AppTheme.pureWhite,
                  ),
                  decoration: InputDecoration(
                    hintText: 'Write your code here...',
                    hintStyle:
                        AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                      fontFamily: 'monospace',
                      color: AppTheme.lightGray.withValues(alpha: 0.6),
                    ),
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 3.h),

        // Submit button
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () {
              HapticFeedback.mediumImpact();
              widget.onCodeSubmit?.call(_codeController.text);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.neonGreen,
              foregroundColor: AppTheme.deepSpaceBlue,
              padding: EdgeInsets.symmetric(vertical: 2.h),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: Text(
              'Run Code',
              style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                color: AppTheme.deepSpaceBlue,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildVideoContent() {
    final videoUrl = widget.contentData['videoUrl'] as String? ?? '';
    final title = widget.contentData['title'] as String? ?? 'Video Lesson';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
            color: AppTheme.primaryCyan,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 2.h),

        // Video player placeholder
        Container(
          width: double.infinity,
          height: 25.h,
          decoration: BoxDecoration(
            color: AppTheme.deepSpaceBlue,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: AppTheme.borderCyan,
              width: 1.0,
            ),
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Video thumbnail placeholder
              Container(
                width: double.infinity,
                height: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      AppTheme.elevatedDark,
                      AppTheme.deepSpaceBlue,
                    ],
                  ),
                ),
              ),

              // Play button
              Container(
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: AppTheme.primaryCyan.withValues(alpha: 0.9),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.primaryCyan.withValues(alpha: 0.5),
                      blurRadius: 16.0,
                      spreadRadius: 4.0,
                    ),
                  ],
                ),
                child: CustomIconWidget(
                  iconName: 'play_arrow',
                  color: AppTheme.deepSpaceBlue,
                  size: 32,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildQuizContent() {
    final question = widget.contentData['question'] as String? ?? '';
    final options = widget.contentData['options'] as List<String>? ?? [];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Question
        Container(
          width: double.infinity,
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: AppTheme.elevatedDark,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: AppTheme.borderCyan,
              width: 1.0,
            ),
          ),
          child: Text(
            question,
            style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
              color: AppTheme.pureWhite,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        SizedBox(height: 3.h),

        // Answer options
        ...options.asMap().entries.map((entry) {
          final index = entry.key;
          final option = entry.value;
          final isSelected = _selectedQuizAnswer == index;

          return Padding(
            padding: EdgeInsets.only(bottom: 2.h),
            child: GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                setState(() {
                  _selectedQuizAnswer = index;
                });
                widget.onQuizAnswer?.call(index);
              },
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: isSelected
                      ? AppTheme.primaryCyan.withValues(alpha: 0.1)
                      : AppTheme.elevatedDark,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color:
                        isSelected ? AppTheme.primaryCyan : AppTheme.borderCyan,
                    width: isSelected ? 2.0 : 1.0,
                  ),
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: AppTheme.primaryCyan.withValues(alpha: 0.3),
                            blurRadius: 8.0,
                            spreadRadius: 1.0,
                          ),
                        ]
                      : null,
                ),
                child: Row(
                  children: [
                    Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        color: isSelected
                            ? AppTheme.primaryCyan
                            : Colors.transparent,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: isSelected
                              ? AppTheme.primaryCyan
                              : AppTheme.lightGray,
                          width: 2.0,
                        ),
                      ),
                      child: isSelected
                          ? CustomIconWidget(
                              iconName: 'check',
                              color: AppTheme.deepSpaceBlue,
                              size: 16,
                            )
                          : null,
                    ),
                    SizedBox(width: 3.w),
                    Expanded(
                      child: Text(
                        option,
                        style:
                            AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                          color: isSelected
                              ? AppTheme.primaryCyan
                              : AppTheme.pureWhite,
                          fontWeight:
                              isSelected ? FontWeight.w600 : FontWeight.w400,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ],
    );
  }
}
