import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class LessonProgressWidget extends StatefulWidget {
  final double progress;
  final String buttonText;
  final VoidCallback? onButtonTap;
  final bool isCompleted;

  const LessonProgressWidget({
    super.key,
    required this.progress,
    required this.buttonText,
    this.onButtonTap,
    this.isCompleted = false,
  });

  @override
  State<LessonProgressWidget> createState() => _LessonProgressWidgetState();
}

class _LessonProgressWidgetState extends State<LessonProgressWidget>
    with TickerProviderStateMixin {
  late AnimationController _progressController;
  late AnimationController _particleController;
  late Animation<double> _progressAnimation;
  late Animation<double> _particleAnimation;

  @override
  void initState() {
    super.initState();
    _progressController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _particleController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );

    _progressAnimation = Tween<double>(
      begin: 0.0,
      end: widget.progress,
    ).animate(CurvedAnimation(
      parent: _progressController,
      curve: Curves.easeInOut,
    ));

    _particleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _particleController,
      curve: Curves.easeInOut,
    ));

    _progressController.forward();
    if (widget.progress > 0) {
      _particleController.repeat();
    }
  }

  @override
  void didUpdateWidget(LessonProgressWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.progress != widget.progress) {
      _progressAnimation = Tween<double>(
        begin: oldWidget.progress,
        end: widget.progress,
      ).animate(CurvedAnimation(
        parent: _progressController,
        curve: Curves.easeInOut,
      ));
      _progressController.forward(from: 0);

      if (widget.progress > 0 && !_particleController.isAnimating) {
        _particleController.repeat();
      } else if (widget.progress == 0) {
        _particleController.stop();
      }
    }
  }

  @override
  void dispose() {
    _progressController.dispose();
    _particleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.elevatedDark,
        border: Border(
          top: BorderSide(
            color: AppTheme.borderCyan,
            width: 1.0,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowCyan,
            blurRadius: 8.0,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Column(
          children: [
            // Progress section
            Row(
              children: [
                Text(
                  'Progress',
                  style: AppTheme.darkTheme.textTheme.titleSmall?.copyWith(
                    color: AppTheme.lightGray,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const Spacer(),
                Text(
                  '${(widget.progress * 100).toInt()}%',
                  style: AppTheme.darkTheme.textTheme.titleSmall?.copyWith(
                    color: AppTheme.primaryCyan,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            SizedBox(height: 2.h),

            // Progress bar with particle effects
            AnimatedBuilder(
              animation:
                  Listenable.merge([_progressAnimation, _particleAnimation]),
              builder: (context, child) {
                return Container(
                  width: double.infinity,
                  height: 8,
                  decoration: BoxDecoration(
                    color: AppTheme.deepSpaceBlue,
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(
                      color: AppTheme.borderCyan,
                      width: 1.0,
                    ),
                  ),
                  child: Stack(
                    children: [
                      // Progress fill
                      FractionallySizedBox(
                        widthFactor: _progressAnimation.value,
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                AppTheme.primaryCyan,
                                AppTheme.neonGreen,
                              ],
                            ),
                            borderRadius: BorderRadius.circular(4),
                            boxShadow: [
                              BoxShadow(
                                color:
                                    AppTheme.primaryCyan.withValues(alpha: 0.5),
                                blurRadius: 8.0,
                                spreadRadius: 1.0,
                              ),
                            ],
                          ),
                        ),
                      ),

                      // Particle trail effect
                      if (_progressAnimation.value > 0)
                        Positioned(
                          left: (MediaQuery.of(context).size.width - 8.w) *
                                  _progressAnimation.value -
                              4,
                          top: -2,
                          child: Container(
                            width: 12,
                            height: 12,
                            decoration: BoxDecoration(
                              color: AppTheme.neonGreen,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: AppTheme.neonGreen.withValues(
                                    alpha: _particleAnimation.value * 0.8,
                                  ),
                                  blurRadius: 12.0,
                                  spreadRadius: 2.0,
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                );
              },
            ),
            SizedBox(height: 3.h),

            // Action button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: widget.onButtonTap != null
                    ? () {
                        HapticFeedback.mediumImpact();
                        widget.onButtonTap!();
                      }
                    : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: widget.isCompleted
                      ? AppTheme.neonGreen
                      : AppTheme.primaryCyan,
                  foregroundColor: AppTheme.deepSpaceBlue,
                  padding: EdgeInsets.symmetric(vertical: 2.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 4.0,
                  shadowColor: widget.isCompleted
                      ? AppTheme.neonGreen.withValues(alpha: 0.5)
                      : AppTheme.primaryCyan.withValues(alpha: 0.5),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (widget.isCompleted)
                      Padding(
                        padding: EdgeInsets.only(right: 2.w),
                        child: CustomIconWidget(
                          iconName: 'check_circle',
                          color: AppTheme.deepSpaceBlue,
                          size: 20,
                        ),
                      ),
                    Text(
                      widget.buttonText,
                      style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                        color: AppTheme.deepSpaceBlue,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (!widget.isCompleted)
                      Padding(
                        padding: EdgeInsets.only(left: 2.w),
                        child: CustomIconWidget(
                          iconName: 'arrow_forward',
                          color: AppTheme.deepSpaceBlue,
                          size: 20,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
