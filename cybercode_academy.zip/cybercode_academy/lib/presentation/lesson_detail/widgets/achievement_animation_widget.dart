import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class AchievementAnimationWidget extends StatefulWidget {
  final int xpGained;
  final String achievementTitle;
  final bool isVisible;
  final VoidCallback? onAnimationComplete;
  final VoidCallback? onShareTap;

  const AchievementAnimationWidget({
    super.key,
    required this.xpGained,
    required this.achievementTitle,
    required this.isVisible,
    this.onAnimationComplete,
    this.onShareTap,
  });

  @override
  State<AchievementAnimationWidget> createState() =>
      _AchievementAnimationWidgetState();
}

class _AchievementAnimationWidgetState extends State<AchievementAnimationWidget>
    with TickerProviderStateMixin {
  late AnimationController _scaleController;
  late AnimationController _glowController;
  late AnimationController _particleController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _glowAnimation;
  late Animation<double> _particleAnimation;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _particleController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _scaleController,
      curve: Curves.elasticOut,
    ));

    _glowAnimation = Tween<double>(
      begin: 0.3,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _glowController,
      curve: Curves.easeInOut,
    ));

    _particleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _particleController,
      curve: Curves.easeOut,
    ));

    if (widget.isVisible) {
      _startAnimation();
    }
  }

  @override
  void didUpdateWidget(AchievementAnimationWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isVisible && !oldWidget.isVisible) {
      _startAnimation();
    } else if (!widget.isVisible && oldWidget.isVisible) {
      _stopAnimation();
    }
  }

  void _startAnimation() {
    HapticFeedback.heavyImpact();
    _scaleController.forward();
    _glowController.repeat(reverse: true);
    _particleController.forward();

    Future.delayed(const Duration(milliseconds: 3000), () {
      if (mounted) {
        widget.onAnimationComplete?.call();
      }
    });
  }

  void _stopAnimation() {
    _scaleController.reverse();
    _glowController.stop();
    _particleController.stop();
  }

  @override
  void dispose() {
    _scaleController.dispose();
    _glowController.dispose();
    _particleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isVisible) return const SizedBox.shrink();

    return Positioned.fill(
      child: Container(
        color: AppTheme.deepSpaceBlue.withValues(alpha: 0.9),
        child: Center(
          child: AnimatedBuilder(
            animation: Listenable.merge([
              _scaleAnimation,
              _glowAnimation,
              _particleAnimation,
            ]),
            builder: (context, child) {
              return Stack(
                alignment: Alignment.center,
                children: [
                  // Particle effects
                  ..._buildParticleEffects(),

                  // Main achievement card
                  Transform.scale(
                    scale: _scaleAnimation.value,
                    child: Container(
                      width: 80.w,
                      padding: EdgeInsets.all(6.w),
                      decoration: BoxDecoration(
                        color: AppTheme.elevatedDark,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: AppTheme.neonGreen,
                          width: 2.0,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.neonGreen.withValues(
                              alpha: _glowAnimation.value * 0.6,
                            ),
                            blurRadius: 20.0,
                            spreadRadius: 4.0,
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Achievement icon
                          Container(
                            padding: EdgeInsets.all(4.w),
                            decoration: BoxDecoration(
                              color: AppTheme.neonGreen.withValues(alpha: 0.2),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: AppTheme.neonGreen,
                                width: 2.0,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: AppTheme.neonGreen.withValues(
                                    alpha: _glowAnimation.value * 0.5,
                                  ),
                                  blurRadius: 16.0,
                                  spreadRadius: 2.0,
                                ),
                              ],
                            ),
                            child: CustomIconWidget(
                              iconName: 'emoji_events',
                              color: AppTheme.neonGreen,
                              size: 48,
                            ),
                          ),
                          SizedBox(height: 3.h),

                          // Achievement title
                          Text(
                            'Achievement Unlocked!',
                            style: AppTheme.darkTheme.textTheme.titleLarge
                                ?.copyWith(
                              color: AppTheme.neonGreen,
                              fontWeight: FontWeight.w700,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          SizedBox(height: 1.h),

                          Text(
                            widget.achievementTitle,
                            style: AppTheme.darkTheme.textTheme.titleMedium
                                ?.copyWith(
                              color: AppTheme.pureWhite,
                              fontWeight: FontWeight.w600,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          SizedBox(height: 3.h),

                          // XP gained
                          Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 4.w,
                              vertical: 2.h,
                            ),
                            decoration: BoxDecoration(
                              color:
                                  AppTheme.primaryCyan.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: AppTheme.primaryCyan,
                                width: 1.0,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                CustomIconWidget(
                                  iconName: 'stars',
                                  color: AppTheme.primaryCyan,
                                  size: 24,
                                ),
                                SizedBox(width: 2.w),
                                Text(
                                  '+${widget.xpGained} XP',
                                  style: AppTheme
                                      .darkTheme.textTheme.titleMedium
                                      ?.copyWith(
                                    color: AppTheme.primaryCyan,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 4.h),

                          // Action buttons
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton(
                                  onPressed: () {
                                    HapticFeedback.lightImpact();
                                    widget.onShareTap?.call();
                                  },
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: AppTheme.primaryCyan,
                                    side: BorderSide(
                                      color: AppTheme.primaryCyan,
                                      width: 1.0,
                                    ),
                                    padding:
                                        EdgeInsets.symmetric(vertical: 1.5.h),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                  child: Text(
                                    'Share',
                                    style: AppTheme
                                        .darkTheme.textTheme.bodyMedium
                                        ?.copyWith(
                                      color: AppTheme.primaryCyan,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(width: 3.w),
                              Expanded(
                                child: ElevatedButton(
                                  onPressed: () {
                                    HapticFeedback.lightImpact();
                                    widget.onAnimationComplete?.call();
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: AppTheme.neonGreen,
                                    foregroundColor: AppTheme.deepSpaceBlue,
                                    padding:
                                        EdgeInsets.symmetric(vertical: 1.5.h),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                  child: Text(
                                    'Continue',
                                    style: AppTheme
                                        .darkTheme.textTheme.bodyMedium
                                        ?.copyWith(
                                      color: AppTheme.deepSpaceBlue,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  List<Widget> _buildParticleEffects() {
    final particles = <Widget>[];
    for (int i = 0; i < 8; i++) {
      final angle = (i * 45) * (3.14159 / 180);
      final distance = 100 * _particleAnimation.value;
      final x = distance * cos(angle);
      final y = distance * sin(angle);

      particles.add(
        Positioned(
          left: 50.w + x - 4,
          top: 50.h + y - 4,
          child: Opacity(
            opacity: 1.0 - _particleAnimation.value,
            child: Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: i.isEven ? AppTheme.primaryCyan : AppTheme.neonGreen,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color:
                        (i.isEven ? AppTheme.primaryCyan : AppTheme.neonGreen)
                            .withValues(alpha: 0.8),
                    blurRadius: 8.0,
                    spreadRadius: 2.0,
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }
    return particles;
  }
}

// Helper function for cos calculation
double cos(double radians) {
  return radians.cos();
}

// Add this helper function for sin calculation
double sin(double radians) {
  return radians.sin();
}

// Extension for cos method
extension on double {
  double cos() {
    return (this -
        (this * this * this) / 6 +
        (this * this * this * this * this) / 120);
  }
  
  // Add sin method to the extension
  double sin() {
    return (this -
        (this * this * this) / 6 +
        (this * this * this * this * this) / 120);
  }
}