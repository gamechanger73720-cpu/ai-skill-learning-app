import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class LessonHeaderWidget extends StatefulWidget {
  final String title;
  final String duration;
  final int xpReward;
  final bool isBookmarked;
  final VoidCallback? onBookmarkTap;
  final VoidCallback? onBackTap;

  const LessonHeaderWidget({
    super.key,
    required this.title,
    required this.duration,
    required this.xpReward,
    this.isBookmarked = false,
    this.onBookmarkTap,
    this.onBackTap,
  });

  @override
  State<LessonHeaderWidget> createState() => _LessonHeaderWidgetState();
}

class _LessonHeaderWidgetState extends State<LessonHeaderWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
    _glowAnimation = Tween<double>(
      begin: 0.3,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _glowController,
      curve: Curves.easeInOut,
    ));
    _glowController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            AppTheme.deepSpaceBlue,
            AppTheme.elevatedDark.withValues(alpha: 0.9),
          ],
        ),
        border: Border(
          bottom: BorderSide(
            color: AppTheme.primaryCyan.withValues(alpha: 0.3),
            width: 1.0,
          ),
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header controls
              Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      HapticFeedback.lightImpact();
                      widget.onBackTap?.call();
                    },
                    child: Container(
                      padding: EdgeInsets.all(2.w),
                      decoration: BoxDecoration(
                        color: AppTheme.elevatedDark.withValues(alpha: 0.8),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: AppTheme.borderCyan,
                          width: 1.0,
                        ),
                      ),
                      child: CustomIconWidget(
                        iconName: 'arrow_back_ios_new',
                        color: AppTheme.primaryCyan,
                        size: 20,
                      ),
                    ),
                  ),
                  const Spacer(),
                  AnimatedBuilder(
                    animation: _glowAnimation,
                    builder: (context, child) {
                      return GestureDetector(
                        onTap: () {
                          HapticFeedback.lightImpact();
                          widget.onBookmarkTap?.call();
                        },
                        child: Container(
                          padding: EdgeInsets.all(2.w),
                          decoration: BoxDecoration(
                            color: widget.isBookmarked
                                ? AppTheme.primaryCyan.withValues(alpha: 0.2)
                                : AppTheme.elevatedDark.withValues(alpha: 0.8),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: widget.isBookmarked
                                  ? AppTheme.primaryCyan
                                  : AppTheme.borderCyan,
                              width: 1.0,
                            ),
                            boxShadow: widget.isBookmarked
                                ? [
                                    BoxShadow(
                                      color: AppTheme.primaryCyan.withValues(
                                        alpha: _glowAnimation.value * 0.5,
                                      ),
                                      blurRadius: 12.0,
                                      spreadRadius: 2.0,
                                    ),
                                  ]
                                : null,
                          ),
                          child: CustomIconWidget(
                            iconName: widget.isBookmarked
                                ? 'bookmark'
                                : 'bookmark_border',
                            color: widget.isBookmarked
                                ? AppTheme.primaryCyan
                                : AppTheme.lightGray,
                            size: 20,
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
              SizedBox(height: 3.h),

              // Lesson title
              Text(
                widget.title,
                style: AppTheme.darkTheme.textTheme.headlineMedium?.copyWith(
                  color: AppTheme.pureWhite,
                  fontWeight: FontWeight.w700,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(height: 2.h),

              // Lesson metadata
              Row(
                children: [
                  // Duration
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 3.w,
                      vertical: 1.h,
                    ),
                    decoration: BoxDecoration(
                      color: AppTheme.elevatedDark,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: AppTheme.borderCyan,
                        width: 1.0,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CustomIconWidget(
                          iconName: 'access_time',
                          color: AppTheme.primaryCyan,
                          size: 16,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          widget.duration,
                          style:
                              AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                            color: AppTheme.lightGray,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 3.w),

                  // XP Reward
                  AnimatedBuilder(
                    animation: _glowAnimation,
                    builder: (context, child) {
                      return Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 3.w,
                          vertical: 1.h,
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.neonGreen.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: AppTheme.neonGreen,
                            width: 1.0,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: AppTheme.neonGreen.withValues(
                                alpha: _glowAnimation.value * 0.3,
                              ),
                              blurRadius: 8.0,
                              spreadRadius: 1.0,
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CustomIconWidget(
                              iconName: 'stars',
                              color: AppTheme.neonGreen,
                              size: 16,
                            ),
                            SizedBox(width: 2.w),
                            Text(
                              '+${widget.xpReward} XP',
                              style: AppTheme.darkTheme.textTheme.bodyMedium
                                  ?.copyWith(
                                color: AppTheme.neonGreen,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
