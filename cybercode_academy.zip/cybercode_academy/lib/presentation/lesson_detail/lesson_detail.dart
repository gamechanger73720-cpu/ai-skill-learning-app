import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/achievement_animation_widget.dart';
import './widgets/lesson_content_widget.dart';
import './widgets/lesson_header_widget.dart';
import './widgets/lesson_progress_widget.dart';

class LessonDetail extends StatefulWidget {
  const LessonDetail({super.key});

  @override
  State<LessonDetail> createState() => _LessonDetailState();
}

class _LessonDetailState extends State<LessonDetail>
    with TickerProviderStateMixin {
  late PageController _pageController;
  late TabController _sectionController;

  int _currentSectionIndex = 0;
  double _lessonProgress = 0.0;
  bool _isBookmarked = false;
  bool _showAchievement = false;

  // Mock lesson data
  final Map<String, dynamic> _lessonData = {
    "id": 1,
    "title": "Introduction to Flutter Widgets",
    "duration": "15 min",
    "xpReward": 50,
    "totalSections": 4,
    "sections": [
      {
        "type": "text",
        "title": "Understanding Widgets",
        "content":
            """Flutter is built around the concept of widgets. Everything in Flutter is a widget - from structural elements like buttons and menus, to layout properties like padding and alignment.

Widgets describe what their view should look like given their current configuration and state. When a widget's state changes, the widget rebuilds its description, which the framework diffs against the previous description to determine the minimal changes needed in the underlying render tree to transition from one state to the next.""",
        "highlights": [
          "Everything in Flutter is a widget",
          "Widgets are immutable descriptions of UI",
          "Flutter uses a reactive programming model",
          "State changes trigger widget rebuilds"
        ]
      },
      {
        "type": "code",
        "title": "Creating Your First Widget",
        "description":
            "Let's create a simple StatelessWidget that displays a welcome message. Complete the code below:",
        "initialCode": """class WelcomeWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      // Add your code here
    );
  }
}""",
        "solution": """class WelcomeWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.0),
      child: Text(
        'Welcome to Flutter!',
        style: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}"""
      },
      {
        "type": "video",
        "title": "Widget Tree Visualization",
        "videoUrl": "https://flutter.dev/videos/widget-tree.mp4",
        "description":
            "Watch this video to understand how Flutter builds and manages the widget tree."
      },
      {
        "type": "quiz",
        "title": "Test Your Knowledge",
        "question": "What happens when a widget's state changes in Flutter?",
        "options": [
          "The entire app restarts",
          "The widget rebuilds its description",
          "Nothing happens automatically",
          "The widget is permanently destroyed"
        ],
        "correctAnswer": 1
      }
    ]
  };

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _sectionController = TabController(
      length: _lessonData['totalSections'],
      vsync: this,
    );
    _updateProgress();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _sectionController.dispose();
    super.dispose();
  }

  void _updateProgress() {
    setState(() {
      _lessonProgress =
          (_currentSectionIndex + 1) / _lessonData['totalSections'];
    });
  }

  void _navigateToSection(int index) {
    if (index >= 0 && index < _lessonData['totalSections']) {
      setState(() {
        _currentSectionIndex = index;
      });
      _pageController.animateToPage(
        index,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
      _sectionController.animateTo(index);
      _updateProgress();
    }
  }

  void _handleNextSection() {
    if (_currentSectionIndex < _lessonData['totalSections'] - 1) {
      _navigateToSection(_currentSectionIndex + 1);
    } else {
      _completeLessonWithAchievement();
    }
  }

  void _completeLessonWithAchievement() {
    setState(() {
      _showAchievement = true;
      _lessonProgress = 1.0;
    });
  }

  void _handleBookmarkToggle() {
    setState(() {
      _isBookmarked = !_isBookmarked;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _isBookmarked ? 'Lesson bookmarked' : 'Bookmark removed',
          style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.pureWhite,
          ),
        ),
        backgroundColor: AppTheme.elevatedDark,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _handleCodeSubmit(String code) {
    // Simulate code execution
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.elevatedDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: AppTheme.borderCyan, width: 1.0),
        ),
        title: Text(
          'Code Execution',
          style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
            color: AppTheme.primaryCyan,
          ),
        ),
        content: Text(
          'Great job! Your code compiled successfully.',
          style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.pureWhite,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _handleNextSection();
            },
            child: Text(
              'Continue',
              style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.primaryCyan,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _handleQuizAnswer(int selectedIndex) {
    final correctAnswer =
        _lessonData['sections'][_currentSectionIndex]['correctAnswer'] as int;
    final isCorrect = selectedIndex == correctAnswer;

    Future.delayed(const Duration(milliseconds: 500), () {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          backgroundColor: AppTheme.elevatedDark,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: AppTheme.borderCyan, width: 1.0),
          ),
          title: Row(
            children: [
              CustomIconWidget(
                iconName: isCorrect ? 'check_circle' : 'cancel',
                color: isCorrect ? AppTheme.neonGreen : AppTheme.brightRed,
                size: 24,
              ),
              SizedBox(width: 2.w),
              Text(
                isCorrect ? 'Correct!' : 'Incorrect',
                style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                  color: isCorrect ? AppTheme.neonGreen : AppTheme.brightRed,
                ),
              ),
            ],
          ),
          content: Text(
            isCorrect
                ? 'Well done! You got the right answer.'
                : 'The correct answer is: "${_lessonData['sections'][_currentSectionIndex]['options'][correctAnswer]}"',
            style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.pureWhite,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _handleNextSection();
              },
              child: Text(
                'Continue',
                style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.primaryCyan,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      );
    });
  }

  void _handleAchievementComplete() {
    setState(() {
      _showAchievement = false;
    });
    Navigator.pushReplacementNamed(context, '/learning-path');
  }

  void _handleShare() {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Achievement shared successfully!',
          style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.pureWhite,
          ),
        ),
        backgroundColor: AppTheme.elevatedDark,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  String _getButtonText() {
    if (_currentSectionIndex == _lessonData['totalSections'] - 1) {
      return 'Complete Lesson';
    }

    final currentSection = _lessonData['sections'][_currentSectionIndex];
    switch (currentSection['type']) {
      case 'code':
        return 'Submit Code';
      case 'quiz':
        return 'Submit Answer';
      case 'video':
        return 'Mark as Watched';
      default:
        return 'Continue';
    }
  }

  LessonType _getCurrentLessonType() {
    final currentSection = _lessonData['sections'][_currentSectionIndex];
    switch (currentSection['type']) {
      case 'code':
        return LessonType.code;
      case 'video':
        return LessonType.video;
      case 'quiz':
        return LessonType.quiz;
      default:
        return LessonType.text;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.deepSpaceBlue,
      body: Stack(
        children: [
          Column(
            children: [
              // Lesson header
              LessonHeaderWidget(
                title: _lessonData['title'],
                duration: _lessonData['duration'],
                xpReward: _lessonData['xpReward'],
                isBookmarked: _isBookmarked,
                onBookmarkTap: _handleBookmarkToggle,
                onBackTap: () => Navigator.pop(context),
              ),

              // Section tabs
              if (_lessonData['totalSections'] > 1)
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: AppTheme.elevatedDark,
                    border: Border(
                      bottom: BorderSide(
                        color: AppTheme.borderCyan,
                        width: 1.0,
                      ),
                    ),
                  ),
                  child: TabBar(
                    controller: _sectionController,
                    isScrollable: true,
                    labelColor: AppTheme.primaryCyan,
                    unselectedLabelColor: AppTheme.lightGray,
                    indicatorColor: AppTheme.primaryCyan,
                    indicatorWeight: 3.0,
                    labelStyle:
                        AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                    unselectedLabelStyle:
                        AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w400,
                    ),
                    onTap: _navigateToSection,
                    tabs: List.generate(
                      _lessonData['totalSections'],
                      (index) => Tab(
                        text: 'Section ${index + 1}',
                      ),
                    ),
                  ),
                ),

              // Content area
              Expanded(
                child: PageView.builder(
                  controller: _pageController,
                  onPageChanged: (index) {
                    setState(() {
                      _currentSectionIndex = index;
                    });
                    _sectionController.animateTo(index);
                    _updateProgress();
                  },
                  itemCount: _lessonData['totalSections'],
                  itemBuilder: (context, index) {
                    final section = _lessonData['sections'][index];
                    return SingleChildScrollView(
                      padding: EdgeInsets.only(bottom: 20.h),
                      child: LessonContentWidget(
                        lessonType: _getCurrentLessonType(),
                        contentData: section,
                        onCodeSubmit: _handleCodeSubmit,
                        onQuizAnswer: _handleQuizAnswer,
                        onCodeCopy: () {
                          HapticFeedback.lightImpact();
                        },
                      ),
                    );
                  },
                ),
              ),
            ],
          ),

          // Bottom progress bar
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: LessonProgressWidget(
              progress: _lessonProgress,
              buttonText: _getButtonText(),
              isCompleted: _lessonProgress >= 1.0,
              onButtonTap: _handleNextSection,
            ),
          ),

          // Achievement animation overlay
          AchievementAnimationWidget(
            xpGained: _lessonData['xpReward'],
            achievementTitle: 'Lesson Completed!',
            isVisible: _showAchievement,
            onAnimationComplete: _handleAchievementComplete,
            onShareTap: _handleShare,
          ),
        ],
      ),
    );
  }
}
