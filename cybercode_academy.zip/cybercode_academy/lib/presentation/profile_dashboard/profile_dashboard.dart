import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import './widgets/learning_statistics_section.dart';
import './widgets/portfolio_projects_section.dart';
import './widgets/recent_achievements_section.dart';
import './widgets/skills_mastered_section.dart';
import './widgets/user_profile_header.dart';

class ProfileDashboard extends StatefulWidget {
  const ProfileDashboard({super.key});

  @override
  State<ProfileDashboard> createState() => _ProfileDashboardState();
}

class _ProfileDashboardState extends State<ProfileDashboard>
    with TickerProviderStateMixin {
  late AnimationController _refreshController;
  late Animation<double> _refreshAnimation;
  bool _isRefreshing = false;

  // Mock user data
  final Map<String, dynamic> _userData = {
    'username': 'CyberCoder_Alex',
    'avatar':
        'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face',
    'level': 42,
    'currentXP': 8750,
    'nextLevelXP': 10000,
    'streak': 15,
    'totalHours': 247,
  };

  final List<Map<String, dynamic>> _skillsData = [
    {
      'name': 'Java',
      'proficiency': 85,
      'lessonsCompleted': 34,
      'totalLessons': 40,
      'icon':
          'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg',
    },
    {
      'name': 'Flutter',
      'proficiency': 92,
      'lessonsCompleted': 28,
      'totalLessons': 30,
      'icon':
          'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/flutter/flutter-original.svg',
    },
    {
      'name': 'Web Development',
      'proficiency': 78,
      'lessonsCompleted': 45,
      'totalLessons': 60,
      'icon':
          'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg',
    },
    {
      'name': 'Python',
      'proficiency': 67,
      'lessonsCompleted': 22,
      'totalLessons': 35,
      'icon':
          'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg',
    },
  ];

  final List<Map<String, dynamic>> _achievementsData = [
    {
      'title': 'Code Ninja',
      'rarity': 'Legendary',
      'icon':
          'https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=100&h=100&fit=crop',
      'earnedDate': DateTime.now().subtract(const Duration(days: 2)),
      'description': 'Complete 100 coding challenges without a single error',
    },
    {
      'title': 'Speed Demon',
      'rarity': 'Epic',
      'icon':
          'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=100&h=100&fit=crop',
      'earnedDate': DateTime.now().subtract(const Duration(days: 5)),
      'description': 'Solve 10 problems in under 5 minutes each',
    },
    {
      'title': 'Streak Master',
      'rarity': 'Rare',
      'icon':
          'https://images.unsplash.com/photo-1574192324001-ee41e18ed679?w=100&h=100&fit=crop',
      'earnedDate': DateTime.now().subtract(const Duration(days: 7)),
      'description': 'Maintain a 14-day learning streak',
    },
    {
      'title': 'First Steps',
      'rarity': 'Common',
      'icon':
          'https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?w=100&h=100&fit=crop',
      'earnedDate': DateTime.now().subtract(const Duration(days: 30)),
      'description': 'Complete your first lesson',
    },
  ];

  final Map<String, dynamic> _statisticsData = {
    'weeklyHours': 18,
    'averageDaily': 2.6,
    'bestDay': 5.2,
    'weeklyData': [2.5, 4.0, 3.5, 5.0, 2.0, 1.5, 3.0],
  };

  final List<Map<String, dynamic>> _projectsData = [
    {
      'title': 'E-Commerce App',
      'description':
          'Full-stack mobile application with payment integration and real-time chat',
      'status': 'Completed',
      'thumbnail':
          'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=300&h=200&fit=crop',
      'technologies': ['Flutter', 'Firebase', 'Stripe'],
    },
    {
      'title': 'AI Chatbot',
      'description':
          'Intelligent conversational AI with natural language processing capabilities',
      'status': 'In Progress',
      'thumbnail':
          'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=300&h=200&fit=crop',
      'technologies': ['Python', 'TensorFlow', 'NLP'],
    },
    {
      'title': 'Portfolio Website',
      'description':
          'Responsive personal portfolio with modern design and smooth animations',
      'status': 'Deployed',
      'thumbnail':
          'https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=300&h=200&fit=crop',
      'technologies': ['React', 'CSS3', 'JavaScript'],
    },
    {
      'title': 'Task Manager',
      'description':
          'Collaborative project management tool with team features and analytics',
      'status': 'Planning',
      'thumbnail':
          'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=300&h=200&fit=crop',
      'technologies': ['Vue.js', 'Node.js', 'MongoDB'],
    },
  ];

  @override
  void initState() {
    super.initState();
    _refreshController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );

    _refreshAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _refreshController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _refreshController.dispose();
    super.dispose();
  }

  Future<void> _handleRefresh() async {
    if (_isRefreshing) return;

    setState(() => _isRefreshing = true);
    HapticFeedback.lightImpact();

    _refreshController.forward();

    // Simulate data refresh
    await Future.delayed(const Duration(milliseconds: 1500));

    _refreshController.reverse();
    setState(() => _isRefreshing = false);

    HapticFeedback.selectionClick();
  }

  void _showSettingsModal() {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildSettingsModal(),
    );
  }

  void _showSkillDetails(Map<String, dynamic> skill) {
    HapticFeedback.lightImpact();
    showDialog(
      context: context,
      builder: (context) => _buildSkillDetailsDialog(skill),
    );
  }

  void _showAchievementDetails(Map<String, dynamic> achievement) {
    HapticFeedback.lightImpact();
    showDialog(
      context: context,
      builder: (context) => _buildAchievementDetailsDialog(achievement),
    );
  }

  void _openProject(Map<String, dynamic> project) {
    HapticFeedback.lightImpact();
    // Navigate to project details or external link
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Opening ${project['title']}...'),
        backgroundColor: AppTheme.primaryCyan,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.deepSpaceBlue,
      appBar: CustomAppBar.dashboard(
        title: 'Profile Dashboard',
        actions: [
          IconButton(
            icon: CustomIconWidget(
              iconName: 'share',
              color: AppTheme.primaryCyan,
              size: 24,
            ),
            onPressed: () {
              HapticFeedback.lightImpact();
              _shareProfile();
            },
            tooltip: 'Share Profile',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _handleRefresh,
        color: AppTheme.primaryCyan,
        backgroundColor: AppTheme.elevatedDark,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: EdgeInsets.all(4.w),
          child: Column(
            children: [
              // User Profile Header
              UserProfileHeader(
                userData: _userData,
                onSettingsPressed: _showSettingsModal,
              ),

              SizedBox(height: 3.h),

              // Skills Mastered Section
              SkillsMasteredSection(
                skills: _skillsData,
                onSkillTapped: _showSkillDetails,
              ),

              SizedBox(height: 3.h),

              // Recent Achievements Section
              RecentAchievementsSection(
                achievements: _achievementsData,
                onAchievementLongPressed: _showAchievementDetails,
              ),

              SizedBox(height: 3.h),

              // Learning Statistics Section
              LearningStatisticsSection(
                statisticsData: _statisticsData,
              ),

              SizedBox(height: 3.h),

              // Portfolio Projects Section
              PortfolioProjectsSection(
                projects: _projectsData,
                onProjectTapped: _openProject,
              ),

              SizedBox(height: 10.h), // Bottom padding for navigation
            ],
          ),
        ),
      ),
      bottomNavigationBar: const CustomBottomBar(
        currentIndex: 3, // Profile tab active
        variant: CustomBottomBarVariant.primary,
      ),
    );
  }

  Widget _buildSettingsModal() {
    return Container(
      height: 60.h,
      decoration: BoxDecoration(
        color: AppTheme.elevatedDark,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
        border: Border.all(
          color: AppTheme.borderCyan,
          width: 1.0,
        ),
      ),
      child: Column(
        children: [
          // Handle bar
          Container(
            width: 12.w,
            height: 0.5.h,
            margin: EdgeInsets.symmetric(vertical: 2.h),
            decoration: BoxDecoration(
              color: AppTheme.lightGray,
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Settings content
          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Settings',
                    style: AppTheme.darkTheme.textTheme.headlineSmall?.copyWith(
                      color: AppTheme.pureWhite,
                    ),
                  ),
                  SizedBox(height: 3.h),
                  _buildSettingsItem(
                    icon: 'palette',
                    title: 'Theme Options',
                    subtitle: 'Customize your cyberpunk experience',
                    onTap: () {},
                  ),
                  _buildSettingsItem(
                    icon: 'notifications',
                    title: 'Notification Preferences',
                    subtitle: 'Manage learning reminders',
                    onTap: () {},
                  ),
                  _buildSettingsItem(
                    icon: 'account_circle',
                    title: 'Account Management',
                    subtitle: 'Profile settings and privacy',
                    onTap: () {},
                  ),
                  _buildSettingsItem(
                    icon: 'visibility_off',
                    title: 'Privacy Settings',
                    subtitle: 'Control what others can see',
                    onTap: () {},
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsItem({
    required String icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.only(bottom: 2.h),
        padding: EdgeInsets.all(3.w),
        decoration: BoxDecoration(
          color: AppTheme.deepSpaceBlue.withValues(alpha: 0.5),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: AppTheme.borderCyan.withValues(alpha: 0.3),
            width: 1.0,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: AppTheme.primaryCyan.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: CustomIconWidget(
                iconName: icon,
                color: AppTheme.primaryCyan,
                size: 20,
              ),
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                      color: AppTheme.pureWhite,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.lightGray,
                    ),
                  ),
                ],
              ),
            ),
            CustomIconWidget(
              iconName: 'arrow_forward_ios',
              color: AppTheme.lightGray,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSkillDetailsDialog(Map<String, dynamic> skill) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: AppTheme.elevatedDark,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: AppTheme.borderCyan,
            width: 1.0,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              '${skill['name']} Progress',
              style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                color: AppTheme.pureWhite,
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              'Completion Rate: ${skill['proficiency']}%',
              style: AppTheme.darkTheme.textTheme.bodyLarge?.copyWith(
                color: AppTheme.primaryCyan,
              ),
            ),
            Text(
              'Lessons: ${skill['lessonsCompleted']}/${skill['totalLessons']}',
              style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightGray,
              ),
            ),
            SizedBox(height: 3.h),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAchievementDetailsDialog(Map<String, dynamic> achievement) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: AppTheme.elevatedDark,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: AppTheme.borderCyan,
            width: 1.0,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              achievement['title'] as String,
              style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                color: AppTheme.pureWhite,
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              'Rarity: ${achievement['rarity']}',
              style: AppTheme.darkTheme.textTheme.bodyLarge?.copyWith(
                color: AppTheme.hotPink,
              ),
            ),
            SizedBox(height: 1.h),
            Text(
              achievement['description'] as String,
              textAlign: TextAlign.center,
              style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightGray,
              ),
            ),
            SizedBox(height: 3.h),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
          ],
        ),
      ),
    );
  }

  void _shareProfile() {
    // Implement profile sharing functionality
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Profile shared successfully!'),
        backgroundColor: AppTheme.neonGreen,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
