import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class RecentAchievementsSection extends StatefulWidget {
  final List<Map<String, dynamic>> achievements;
  final Function(Map<String, dynamic>)? onAchievementLongPressed;

  const RecentAchievementsSection({
    super.key,
    required this.achievements,
    this.onAchievementLongPressed,
  });

  @override
  State<RecentAchievementsSection> createState() =>
      _RecentAchievementsSectionState();
}

class _RecentAchievementsSectionState extends State<RecentAchievementsSection>
    with TickerProviderStateMixin {
  late AnimationController _particleController;
  late AnimationController _badgeController;
  late List<Animation<double>> _badgeAnimations;
  late Animation<double> _particleAnimation;

  @override
  void initState() {
    super.initState();
    _particleController = AnimationController(
      duration: const Duration(milliseconds: 3000),
      vsync: this,
    );
    _badgeController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _particleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _particleController,
      curve: Curves.easeInOut,
    ));

    _badgeAnimations = List.generate(
      widget.achievements.length,
      (index) => Tween<double>(
        begin: 0.0,
        end: 1.0,
      ).animate(CurvedAnimation(
        parent: _badgeController,
        curve: Interval(
          index * 0.2,
          (index * 0.2) + 0.8,
          curve: Curves.elasticOut,
        ),
      )),
    );

    _particleController.repeat();
    _badgeController.forward();
  }

  @override
  void dispose() {
    _particleController.dispose();
    _badgeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.elevatedDark,
        border: Border.all(
          color: AppTheme.borderCyan,
          width: 1.0,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowCyan,
            blurRadius: 8.0,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'emoji_events',
                color: AppTheme.hotPink,
                size: 24,
              ),
              SizedBox(width: 2.w),
              Text(
                'Recent Achievements',
                style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                  color: AppTheme.pureWhite,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          SizedBox(
            height: 20.h,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: widget.achievements.length,
              itemBuilder: (context, index) {
                final achievement = widget.achievements[index];
                return _buildAchievementBadge(achievement, index);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAchievementBadge(Map<String, dynamic> achievement, int index) {
    return GestureDetector(
      onLongPress: () => widget.onAchievementLongPressed?.call(achievement),
      child: AnimatedBuilder(
        animation: _badgeAnimations[index],
        builder: (context, child) {
          return Transform.scale(
            scale: _badgeAnimations[index].value,
            child: Container(
              width: 35.w,
              margin: EdgeInsets.only(right: 3.w),
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    _getRarityColor(achievement['rarity'] as String)
                        .withValues(alpha: 0.2),
                    AppTheme.deepSpaceBlue.withValues(alpha: 0.8),
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: _getRarityColor(achievement['rarity'] as String),
                  width: 2.0,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _getRarityColor(achievement['rarity'] as String)
                        .withValues(alpha: 0.3),
                    blurRadius: 12.0,
                    spreadRadius: 2.0,
                  ),
                ],
              ),
              child: Stack(
                children: [
                  // Particle effects
                  AnimatedBuilder(
                    animation: _particleAnimation,
                    builder: (context, child) {
                      return Positioned.fill(
                        child: CustomPaint(
                          painter: ParticleEffectPainter(
                            animation: _particleAnimation,
                            color: _getRarityColor(
                                achievement['rarity'] as String),
                          ),
                        ),
                      );
                    },
                  ),

                  // Badge content
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Badge icon
                      Container(
                        width: 15.w,
                        height: 15.w,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [
                              _getRarityColor(achievement['rarity'] as String),
                              _getRarityColor(achievement['rarity'] as String)
                                  .withValues(alpha: 0.3),
                            ],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _getRarityColor(
                                      achievement['rarity'] as String)
                                  .withValues(alpha: 0.5),
                              blurRadius: 8.0,
                              spreadRadius: 2.0,
                            ),
                          ],
                        ),
                        child: CustomImageWidget(
                          imageUrl: achievement['icon'] as String,
                          width: 15.w,
                          height: 15.w,
                          fit: BoxFit.contain,
                        ),
                      ),

                      SizedBox(height: 2.h),

                      // Badge title
                      Text(
                        achievement['title'] as String,
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style:
                            AppTheme.darkTheme.textTheme.titleSmall?.copyWith(
                          color: AppTheme.pureWhite,
                          fontWeight: FontWeight.w600,
                        ),
                      ),

                      SizedBox(height: 1.h),

                      // Rarity indicator
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 2.w, vertical: 0.5.h),
                        decoration: BoxDecoration(
                          color:
                              _getRarityColor(achievement['rarity'] as String)
                                  .withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color:
                                _getRarityColor(achievement['rarity'] as String)
                                    .withValues(alpha: 0.5),
                            width: 1.0,
                          ),
                        ),
                        child: Text(
                          achievement['rarity'] as String,
                          style:
                              AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                            color: _getRarityColor(
                                achievement['rarity'] as String),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),

                      SizedBox(height: 1.h),

                      // Earned date
                      Text(
                        _formatDate(achievement['earnedDate'] as DateTime),
                        style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                          color: AppTheme.lightGray,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Color _getRarityColor(String rarity) {
    switch (rarity.toLowerCase()) {
      case 'legendary':
        return AppTheme.hotPink;
      case 'epic':
        return AppTheme.amberOrange;
      case 'rare':
        return AppTheme.primaryCyan;
      case 'common':
        return AppTheme.neonGreen;
      default:
        return AppTheme.lightGray;
    }
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inMinutes}m ago';
    }
  }
}

class ParticleEffectPainter extends CustomPainter {
  final Animation<double> animation;
  final Color color;

  ParticleEffectPainter({
    required this.animation,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withValues(alpha: 0.3)
      ..style = PaintingStyle.fill;

    // Draw floating particles
    for (int i = 0; i < 8; i++) {
      final angle = (i * 45.0) * (3.14159 / 180.0);
      final radius = 20.0 + (animation.value * 15.0);
      final x = (size.width / 2) + (radius * cos(angle));
      final y = (size.height / 2) + (radius * sin(angle));

      canvas.drawCircle(
        Offset(x, y),
        2.0 * (1.0 - animation.value),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

double cos(double radians) => radians.cos();
double sin(double radians) => radians.sin();

extension on double {
  double cos() {
    // Simple approximation for cos function
    final x = this % (2 * 3.14159);
    return 1 - (x * x) / 2 + (x * x * x * x) / 24;
  }

  double sin() {
    // Simple approximation for sin function
    final x = this % (2 * 3.14159);
    return x - (x * x * x) / 6 + (x * x * x * x * x) / 120;
  }
}
