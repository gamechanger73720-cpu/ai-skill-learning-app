import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SkillsMasteredSection extends StatefulWidget {
  final List<Map<String, dynamic>> skills;
  final Function(Map<String, dynamic>)? onSkillTapped;

  const SkillsMasteredSection({
    super.key,
    required this.skills,
    this.onSkillTapped,
  });

  @override
  State<SkillsMasteredSection> createState() => _SkillsMasteredSectionState();
}

class _SkillsMasteredSectionState extends State<SkillsMasteredSection>
    with TickerProviderStateMixin {
  late AnimationController _progressController;
  late List<Animation<double>> _progressAnimations;

  @override
  void initState() {
    super.initState();
    _progressController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );

    _progressAnimations = widget.skills.map((skill) {
      return Tween<double>(
        begin: 0.0,
        end: (skill['proficiency'] as num).toDouble() / 100.0,
      ).animate(CurvedAnimation(
        parent: _progressController,
        curve: Curves.easeOutCubic,
      ));
    }).toList();

    _progressController.forward();
  }

  @override
  void dispose() {
    _progressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.elevatedDark,
        border: Border.all(
          color: AppTheme.borderCyan,
          width: 1.0,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowCyan,
            blurRadius: 8.0,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'code',
                color: AppTheme.primaryCyan,
                size: 24,
              ),
              SizedBox(width: 2.w),
              Text(
                'Skills Mastered',
                style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                  color: AppTheme.pureWhite,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          ...widget.skills.asMap().entries.map((entry) {
            final index = entry.key;
            final skill = entry.value;
            return _buildSkillItem(skill, index);
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildSkillItem(Map<String, dynamic> skill, int index) {
    return GestureDetector(
      onTap: () => widget.onSkillTapped?.call(skill),
      child: Container(
        margin: EdgeInsets.only(bottom: 2.h),
        padding: EdgeInsets.all(3.w),
        decoration: BoxDecoration(
          color: AppTheme.deepSpaceBlue.withValues(alpha: 0.5),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: AppTheme.borderCyan.withValues(alpha: 0.3),
            width: 1.0,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 12.w,
                  height: 12.w,
                  decoration: BoxDecoration(
                    color: _getSkillColor(skill['name'] as String)
                        .withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: _getSkillColor(skill['name'] as String)
                          .withValues(alpha: 0.3),
                      width: 1.0,
                    ),
                  ),
                  child: CustomImageWidget(
                    imageUrl: skill['icon'] as String,
                    width: 12.w,
                    height: 12.w,
                    fit: BoxFit.contain,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        skill['name'] as String,
                        style:
                            AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                          color: AppTheme.pureWhite,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 0.5.h),
                      Text(
                        '${skill['proficiency']}% Mastery',
                        style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                          color: _getSkillColor(skill['name'] as String),
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  '${skill['lessonsCompleted']}/${skill['totalLessons']}',
                  style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.lightGray,
                  ),
                ),
              ],
            ),

            SizedBox(height: 2.h),

            // Progress bar with electric blue glow
            Container(
              height: 1.h,
              decoration: BoxDecoration(
                color: AppTheme.lightGray.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(4),
              ),
              child: AnimatedBuilder(
                animation: _progressAnimations[index],
                builder: (context, child) {
                  return Stack(
                    children: [
                      Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: AppTheme.lightGray.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                      FractionallySizedBox(
                        widthFactor: _progressAnimations[index].value,
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                _getSkillColor(skill['name'] as String),
                                _getSkillColor(skill['name'] as String)
                                    .withValues(alpha: 0.7),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(4),
                            boxShadow: [
                              BoxShadow(
                                color: _getSkillColor(skill['name'] as String)
                                    .withValues(alpha: 0.4),
                                blurRadius: 4.0,
                                spreadRadius: 1.0,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getSkillColor(String skillName) {
    switch (skillName.toLowerCase()) {
      case 'java':
        return AppTheme.hotPink;
      case 'flutter':
        return AppTheme.primaryCyan;
      case 'web development':
        return AppTheme.neonGreen;
      case 'python':
        return AppTheme.amberOrange;
      default:
        return AppTheme.primaryCyan;
    }
  }
}
