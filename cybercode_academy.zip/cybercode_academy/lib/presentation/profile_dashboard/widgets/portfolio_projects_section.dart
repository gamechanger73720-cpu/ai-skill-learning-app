import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class PortfolioProjectsSection extends StatefulWidget {
  final List<Map<String, dynamic>> projects;
  final Function(Map<String, dynamic>)? onProjectTapped;

  const PortfolioProjectsSection({
    super.key,
    required this.projects,
    this.onProjectTapped,
  });

  @override
  State<PortfolioProjectsSection> createState() =>
      _PortfolioProjectsSectionState();
}

class _PortfolioProjectsSectionState extends State<PortfolioProjectsSection>
    with TickerProviderStateMixin {
  late AnimationController _hoverController;
  late Animation<double> _hoverAnimation;
  int _hoveredIndex = -1;

  @override
  void initState() {
    super.initState();
    _hoverController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _hoverAnimation = Tween<double>(
      begin: 1.0,
      end: 1.05,
    ).animate(CurvedAnimation(
      parent: _hoverController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _hoverController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.elevatedDark,
        border: Border.all(
          color: AppTheme.borderCyan,
          width: 1.0,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowCyan,
            blurRadius: 8.0,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  CustomIconWidget(
                    iconName: 'work',
                    color: AppTheme.amberOrange,
                    size: 24,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Portfolio Projects',
                    style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                      color: AppTheme.pureWhite,
                    ),
                  ),
                ],
              ),
              GestureDetector(
                onTap: () {
                  // Navigate to full portfolio view
                },
                child: Text(
                  'View All',
                  style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.primaryCyan,
                    decoration: TextDecoration.underline,
                    decorationColor: AppTheme.primaryCyan,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 3.w,
              mainAxisSpacing: 2.h,
              childAspectRatio: 0.8,
            ),
            itemCount: widget.projects.length > 4 ? 4 : widget.projects.length,
            itemBuilder: (context, index) {
              final project = widget.projects[index];
              return _buildProjectCard(project, index);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildProjectCard(Map<String, dynamic> project, int index) {
    return GestureDetector(
      onTap: () => widget.onProjectTapped?.call(project),
      onTapDown: (_) {
        setState(() => _hoveredIndex = index);
        _hoverController.forward();
      },
      onTapUp: (_) {
        setState(() => _hoveredIndex = -1);
        _hoverController.reverse();
      },
      onTapCancel: () {
        setState(() => _hoveredIndex = -1);
        _hoverController.reverse();
      },
      child: AnimatedBuilder(
        animation: _hoverAnimation,
        builder: (context, child) {
          return Transform.scale(
            scale: _hoveredIndex == index ? _hoverAnimation.value : 1.0,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    AppTheme.deepSpaceBlue.withValues(alpha: 0.8),
                    AppTheme.elevatedDark,
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: _getProjectStatusColor(project['status'] as String),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _getProjectStatusColor(project['status'] as String)
                        .withValues(alpha: 0.3),
                    blurRadius: _hoveredIndex == index ? 12.0 : 6.0,
                    spreadRadius: _hoveredIndex == index ? 2.0 : 1.0,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Project thumbnail
                  Expanded(
                    flex: 3,
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(16),
                          topRight: Radius.circular(16),
                        ),
                        image: DecorationImage(
                          image: NetworkImage(project['thumbnail'] as String),
                          fit: BoxFit.cover,
                        ),
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(16),
                            topRight: Radius.circular(16),
                          ),
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              AppTheme.deepSpaceBlue.withValues(alpha: 0.7),
                            ],
                          ),
                        ),
                        child: Stack(
                          children: [
                            // Status badge
                            Positioned(
                              top: 2.w,
                              right: 2.w,
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                  horizontal: 2.w,
                                  vertical: 0.5.h,
                                ),
                                decoration: BoxDecoration(
                                  color: _getProjectStatusColor(
                                          project['status'] as String)
                                      .withValues(alpha: 0.9),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  project['status'] as String,
                                  style: AppTheme.darkTheme.textTheme.bodySmall
                                      ?.copyWith(
                                    color: AppTheme.pureWhite,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 10.sp,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  // Project details
                  Expanded(
                    flex: 2,
                    child: Padding(
                      padding: EdgeInsets.all(3.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            project['title'] as String,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppTheme.darkTheme.textTheme.titleSmall
                                ?.copyWith(
                              color: AppTheme.pureWhite,
                              fontWeight: FontWeight.w600,
                            ),
                          ),

                          SizedBox(height: 0.5.h),

                          Text(
                            project['description'] as String,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: AppTheme.darkTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme.lightGray,
                            ),
                          ),

                          const Spacer(),

                          // Technology tags
                          Wrap(
                            spacing: 1.w,
                            children: ((project['technologies']
                                        as List<dynamic>?) ??
                                    [])
                                .take(2)
                                .map((tech) => Container(
                                      padding: EdgeInsets.symmetric(
                                        horizontal: 1.5.w,
                                        vertical: 0.3.h,
                                      ),
                                      decoration: BoxDecoration(
                                        color: AppTheme.primaryCyan
                                            .withValues(alpha: 0.2),
                                        borderRadius: BorderRadius.circular(6),
                                        border: Border.all(
                                          color: AppTheme.primaryCyan
                                              .withValues(alpha: 0.5),
                                          width: 0.5,
                                        ),
                                      ),
                                      child: Text(
                                        tech as String,
                                        style: AppTheme
                                            .darkTheme.textTheme.bodySmall
                                            ?.copyWith(
                                          color: AppTheme.primaryCyan,
                                          fontSize: 8.sp,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ))
                                .toList(),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Color _getProjectStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'completed':
        return AppTheme.neonGreen;
      case 'in progress':
        return AppTheme.amberOrange;
      case 'planning':
        return AppTheme.primaryCyan;
      case 'deployed':
        return AppTheme.hotPink;
      default:
        return AppTheme.lightGray;
    }
  }
}
