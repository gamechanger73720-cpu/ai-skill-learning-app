import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class UserProfileHeader extends StatefulWidget {
  final Map<String, dynamic> userData;
  final VoidCallback? onSettingsPressed;

  const UserProfileHeader({
    super.key,
    required this.userData,
    this.onSettingsPressed,
  });

  @override
  State<UserProfileHeader> createState() => _UserProfileHeaderState();
}

class _UserProfileHeaderState extends State<UserProfileHeader>
    with TickerProviderStateMixin {
  late AnimationController _glowController;
  late AnimationController _xpRingController;
  late Animation<double> _glowAnimation;
  late Animation<double> _xpRingAnimation;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
    _xpRingController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _glowAnimation = Tween<double>(
      begin: 0.4,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _glowController,
      curve: Curves.easeInOut,
    ));

    _xpRingAnimation = Tween<double>(
      begin: 0.0,
      end: (widget.userData['currentXP'] as num).toDouble() /
          (widget.userData['nextLevelXP'] as num).toDouble(),
    ).animate(CurvedAnimation(
      parent: _xpRingController,
      curve: Curves.easeOutCubic,
    ));

    _glowController.repeat(reverse: true);
    _xpRingController.forward();
  }

  @override
  void dispose() {
    _glowController.dispose();
    _xpRingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppTheme.elevatedDark,
            AppTheme.deepSpaceBlue.withValues(alpha: 0.8),
          ],
        ),
        border: Border.all(
          color: AppTheme.borderCyan,
          width: 1.0,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowCyan,
            blurRadius: 12.0,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header with settings
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Profile Command Center',
                style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                  color: AppTheme.primaryCyan,
                ),
              ),
              GestureDetector(
                onTap: widget.onSettingsPressed,
                child: AnimatedBuilder(
                  animation: _glowAnimation,
                  builder: (context, child) {
                    return Container(
                      padding: EdgeInsets.all(2.w),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: AppTheme.primaryCyan.withValues(
                            alpha: _glowAnimation.value,
                          ),
                          width: 1.5,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.primaryCyan.withValues(
                              alpha: _glowAnimation.value * 0.3,
                            ),
                            blurRadius: 8.0,
                            spreadRadius: 1.0,
                          ),
                        ],
                      ),
                      child: CustomIconWidget(
                        iconName: 'settings',
                        color: AppTheme.primaryCyan,
                        size: 20,
                      ),
                    );
                  },
                ),
              ),
            ],
          ),

          SizedBox(height: 3.h),

          // User avatar with XP ring
          Stack(
            alignment: Alignment.center,
            children: [
              // XP Progress Ring
              AnimatedBuilder(
                animation: _xpRingAnimation,
                builder: (context, child) {
                  return SizedBox(
                    width: 25.w,
                    height: 25.w,
                    child: CircularProgressIndicator(
                      value: _xpRingAnimation.value,
                      strokeWidth: 4.0,
                      backgroundColor:
                          AppTheme.lightGray.withValues(alpha: 0.2),
                      valueColor: AlwaysStoppedAnimation<Color>(
                        AppTheme.primaryCyan,
                      ),
                    ),
                  );
                },
              ),

              // Holographic frame
              AnimatedBuilder(
                animation: _glowAnimation,
                builder: (context, child) {
                  return Container(
                    width: 20.w,
                    height: 20.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: AppTheme.primaryCyan.withValues(
                          alpha: _glowAnimation.value,
                        ),
                        width: 2.0,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.primaryCyan.withValues(
                            alpha: _glowAnimation.value * 0.4,
                          ),
                          blurRadius: 16.0,
                          spreadRadius: 2.0,
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: CustomImageWidget(
                        imageUrl: widget.userData['avatar'] as String,
                        width: 20.w,
                        height: 20.w,
                        fit: BoxFit.cover,
                      ),
                    ),
                  );
                },
              ),

              // Level indicator
              Positioned(
                bottom: 0,
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.h),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryCyan,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.primaryCyan.withValues(alpha: 0.3),
                        blurRadius: 8.0,
                        spreadRadius: 1.0,
                      ),
                    ],
                  ),
                  child: Text(
                    'LVL ${widget.userData['level']}',
                    style: AppTheme.darkTheme.textTheme.labelMedium?.copyWith(
                      color: AppTheme.deepSpaceBlue,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ],
          ),

          SizedBox(height: 2.h),

          // Username with neon glow
          AnimatedBuilder(
            animation: _glowAnimation,
            builder: (context, child) {
              return Text(
                widget.userData['username'] as String,
                style: AppTheme.darkTheme.textTheme.headlineSmall?.copyWith(
                  color: AppTheme.pureWhite,
                  shadows: [
                    Shadow(
                      color: AppTheme.primaryCyan.withValues(
                        alpha: _glowAnimation.value * 0.6,
                      ),
                      blurRadius: 8.0,
                    ),
                  ],
                ),
              );
            },
          ),

          SizedBox(height: 2.h),

          // Stats row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildStatItem(
                icon: 'local_fire_department',
                value: '${widget.userData['streak']}',
                label: 'Day Streak',
                color: AppTheme.hotPink,
              ),
              _buildStatItem(
                icon: 'access_time',
                value: '${widget.userData['totalHours']}h',
                label: 'Learning Time',
                color: AppTheme.neonGreen,
              ),
              _buildStatItem(
                icon: 'stars',
                value: '${widget.userData['currentXP']}',
                label: 'Total XP',
                color: AppTheme.primaryCyan,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem({
    required String icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(2.w),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color.withValues(alpha: 0.1),
            border: Border.all(
              color: color.withValues(alpha: 0.3),
              width: 1.0,
            ),
          ),
          child: CustomIconWidget(
            iconName: icon,
            color: color,
            size: 20,
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          value,
          style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
            color: color,
            fontWeight: FontWeight.w700,
          ),
        ),
        Text(
          label,
          style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
            color: AppTheme.lightGray,
          ),
        ),
      ],
    );
  }
}
