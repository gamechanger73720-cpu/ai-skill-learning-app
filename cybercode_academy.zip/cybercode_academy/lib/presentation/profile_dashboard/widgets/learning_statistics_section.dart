import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class LearningStatisticsSection extends StatefulWidget {
  final Map<String, dynamic> statisticsData;

  const LearningStatisticsSection({
    super.key,
    required this.statisticsData,
  });

  @override
  State<LearningStatisticsSection> createState() =>
      _LearningStatisticsSectionState();
}

class _LearningStatisticsSectionState extends State<LearningStatisticsSection>
    with TickerProviderStateMixin {
  late AnimationController _chartController;
  late Animation<double> _chartAnimation;

  @override
  void initState() {
    super.initState();
    _chartController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );

    _chartAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _chartController,
      curve: Curves.easeOutCubic,
    ));

    _chartController.forward();
  }

  @override
  void dispose() {
    _chartController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.elevatedDark,
        border: Border.all(
          color: AppTheme.borderCyan,
          width: 1.0,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowCyan,
            blurRadius: 8.0,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'analytics',
                color: AppTheme.neonGreen,
                size: 24,
              ),
              SizedBox(width: 2.w),
              Text(
                'Learning Statistics',
                style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                  color: AppTheme.pureWhite,
                ),
              ),
            ],
          ),

          SizedBox(height: 3.h),

          // Weekly activity chart
          Container(
            height: 25.h,
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: AppTheme.deepSpaceBlue.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.borderCyan.withValues(alpha: 0.3),
                width: 1.0,
              ),
            ),
            child: AnimatedBuilder(
              animation: _chartAnimation,
              builder: (context, child) {
                return LineChart(
                  LineChartData(
                    gridData: FlGridData(
                      show: true,
                      drawVerticalLine: true,
                      drawHorizontalLine: true,
                      horizontalInterval: 1,
                      verticalInterval: 1,
                      getDrawingHorizontalLine: (value) {
                        return FlLine(
                          color: AppTheme.borderCyan.withValues(alpha: 0.2),
                          strokeWidth: 1,
                        );
                      },
                      getDrawingVerticalLine: (value) {
                        return FlLine(
                          color: AppTheme.borderCyan.withValues(alpha: 0.2),
                          strokeWidth: 1,
                        );
                      },
                    ),
                    titlesData: FlTitlesData(
                      show: true,
                      rightTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      topTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 30,
                          interval: 1,
                          getTitlesWidget: (double value, TitleMeta meta) {
                            const style = TextStyle(
                              color: AppTheme.lightGray,
                              fontWeight: FontWeight.w400,
                              fontSize: 12,
                            );
                            Widget text;
                            switch (value.toInt()) {
                              case 0:
                                text = const Text('Mon', style: style);
                                break;
                              case 1:
                                text = const Text('Tue', style: style);
                                break;
                              case 2:
                                text = const Text('Wed', style: style);
                                break;
                              case 3:
                                text = const Text('Thu', style: style);
                                break;
                              case 4:
                                text = const Text('Fri', style: style);
                                break;
                              case 5:
                                text = const Text('Sat', style: style);
                                break;
                              case 6:
                                text = const Text('Sun', style: style);
                                break;
                              default:
                                text = const Text('', style: style);
                                break;
                            }
                            return SideTitleWidget(
                              axisSide: meta.axisSide,
                              child: text,
                            );
                          },
                        ),
                      ),
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          interval: 1,
                          getTitlesWidget: (double value, TitleMeta meta) {
                            const style = TextStyle(
                              color: AppTheme.lightGray,
                              fontWeight: FontWeight.w400,
                              fontSize: 12,
                            );
                            return Text('${value.toInt()}h', style: style);
                          },
                          reservedSize: 42,
                        ),
                      ),
                    ),
                    borderData: FlBorderData(
                      show: true,
                      border: Border.all(
                        color: AppTheme.borderCyan.withValues(alpha: 0.3),
                        width: 1,
                      ),
                    ),
                    minX: 0,
                    maxX: 6,
                    minY: 0,
                    maxY: 6,
                    lineBarsData: [
                      LineChartBarData(
                        spots: _getWeeklyData().asMap().entries.map((entry) {
                          return FlSpot(
                            entry.key.toDouble(),
                            entry.value * _chartAnimation.value,
                          );
                        }).toList(),
                        isCurved: true,
                        gradient: LinearGradient(
                          colors: [
                            AppTheme.primaryCyan,
                            AppTheme.neonGreen,
                          ],
                        ),
                        barWidth: 3,
                        isStrokeCapRound: true,
                        dotData: FlDotData(
                          show: true,
                          getDotPainter: (spot, percent, barData, index) {
                            return FlDotCirclePainter(
                              radius: 4,
                              color: AppTheme.primaryCyan,
                              strokeWidth: 2,
                              strokeColor: AppTheme.pureWhite,
                            );
                          },
                        ),
                        belowBarData: BarAreaData(
                          show: true,
                          gradient: LinearGradient(
                            colors: [
                              AppTheme.primaryCyan.withValues(alpha: 0.3),
                              AppTheme.neonGreen.withValues(alpha: 0.1),
                            ],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),

          SizedBox(height: 3.h),

          // Statistics summary
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildStatCard(
                title: 'This Week',
                value: '${widget.statisticsData['weeklyHours']}h',
                icon: 'calendar_today',
                color: AppTheme.primaryCyan,
              ),
              _buildStatCard(
                title: 'Avg/Day',
                value: '${widget.statisticsData['averageDaily']}h',
                icon: 'trending_up',
                color: AppTheme.neonGreen,
              ),
              _buildStatCard(
                title: 'Best Day',
                value: '${widget.statisticsData['bestDay']}h',
                icon: 'star',
                color: AppTheme.hotPink,
              ),
            ],
          ),
        ],
      ),
    );
  }

  List<double> _getWeeklyData() {
    final weeklyData = widget.statisticsData['weeklyData'] as List<dynamic>?;
    if (weeklyData != null) {
      return weeklyData.map((e) => (e as num).toDouble()).toList();
    }
    return [2.5, 4.0, 3.5, 5.0, 2.0, 1.5, 3.0]; // Default data
  }

  Widget _buildStatCard({
    required String title,
    required String value,
    required String icon,
    required Color color,
  }) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: color.withValues(alpha: 0.3),
          width: 1.0,
        ),
      ),
      child: Column(
        children: [
          CustomIconWidget(
            iconName: icon,
            color: color,
            size: 20,
          ),
          SizedBox(height: 1.h),
          Text(
            value,
            style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
              color: color,
              fontWeight: FontWeight.w700,
            ),
          ),
          Text(
            title,
            style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightGray,
            ),
          ),
        ],
      ),
    );
  }
}
