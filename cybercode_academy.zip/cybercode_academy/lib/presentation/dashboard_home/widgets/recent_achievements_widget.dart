import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

/// Recent achievements section widget
class RecentAchievementsWidget extends StatelessWidget {
  final List<Map<String, dynamic>> achievements;
  final VoidCallback onViewAll;

  const RecentAchievementsWidget({
    super.key,
    required this.achievements,
    required this.onViewAll,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Recent Achievements',
                style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                  color: AppTheme.pureWhite,
                  fontWeight: FontWeight.bold,
                ),
              ),
              GestureDetector(
                onTap: onViewAll,
                child: Text(
                  'View All',
                  style: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
                    color: AppTheme.primaryCyan,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          SizedBox(
            height: 15.h,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: achievements.length,
              separatorBuilder: (context, index) => SizedBox(width: 3.w),
              itemBuilder: (context, index) {
                final achievement = achievements[index];
                return _AchievementBadge(achievement: achievement);
              },
            ),
          ),
        ],
      ),
    );
  }
}

/// Individual achievement badge widget with particle effects
class _AchievementBadge extends StatefulWidget {
  final Map<String, dynamic> achievement;

  const _AchievementBadge({
    required this.achievement,
  });

  @override
  State<_AchievementBadge> createState() => _AchievementBadgeState();
}

class _AchievementBadgeState extends State<_AchievementBadge>
    with TickerProviderStateMixin {
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
    _glowAnimation = Tween<double>(
      begin: 0.3,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _glowController,
      curve: Curves.easeInOut,
    ));
    _glowController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  Color _getRarityColor(String rarity) {
    switch (rarity.toLowerCase()) {
      case 'common':
        return AppTheme.lightGray;
      case 'rare':
        return AppTheme.primaryCyan;
      case 'epic':
        return AppTheme.hotPink;
      case 'legendary':
        return AppTheme.amberOrange;
      default:
        return AppTheme.neonGreen;
    }
  }

  @override
  Widget build(BuildContext context) {
    final rarityColor = _getRarityColor(widget.achievement['rarity'] as String);
    final isNew = widget.achievement['isNew'] as bool;

    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, child) {
        return Container(
          width: 25.w,
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppTheme.elevatedDark,
                AppTheme.elevatedDark.withValues(alpha: 0.8),
              ],
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: rarityColor.withValues(alpha: 0.5),
              width: 2,
            ),
            boxShadow: [
              BoxShadow(
                color: rarityColor.withValues(
                  alpha: isNew ? _glowAnimation.value * 0.4 : 0.2,
                ),
                blurRadius: isNew ? 16 : 8,
                spreadRadius: isNew ? 2 : 1,
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Achievement icon with glow effect
              Container(
                width: 12.w,
                height: 12.w,
                decoration: BoxDecoration(
                  color: rarityColor.withValues(alpha: 0.2),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: rarityColor.withValues(alpha: 0.5),
                    width: 2,
                  ),
                  boxShadow: isNew
                      ? [
                          BoxShadow(
                            color: rarityColor.withValues(
                              alpha: _glowAnimation.value * 0.6,
                            ),
                            blurRadius: 12,
                            spreadRadius: 2,
                          ),
                        ]
                      : null,
                ),
                child: CustomIconWidget(
                  iconName: widget.achievement['icon'] as String,
                  color: rarityColor,
                  size: 24,
                ),
              ),
              SizedBox(height: 2.h),
              Text(
                widget.achievement['title'] as String,
                style: AppTheme.darkTheme.textTheme.labelMedium?.copyWith(
                  color: AppTheme.pureWhite,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(height: 0.5.h),
              Container(
                padding:
                    EdgeInsets.symmetric(horizontal: 1.5.w, vertical: 0.3.h),
                decoration: BoxDecoration(
                  color: rarityColor.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color: rarityColor.withValues(alpha: 0.5),
                    width: 1,
                  ),
                ),
                child: Text(
                  widget.achievement['rarity'] as String,
                  style: AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
                    color: rarityColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              if (isNew) ...[
                SizedBox(height: 1.h),
                Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 1.5.w, vertical: 0.3.h),
                  decoration: BoxDecoration(
                    color: AppTheme.neonGreen.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: AppTheme.neonGreen.withValues(alpha: 0.5),
                      width: 1,
                    ),
                  ),
                  child: Text(
                    'NEW!',
                    style: AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
                      color: AppTheme.neonGreen,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }
}
