import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

/// Leaderboard preview section widget
class LeaderboardPreviewWidget extends StatelessWidget {
  final List<Map<String, dynamic>> topUsers;
  final VoidCallback onViewFull;

  const LeaderboardPreviewWidget({
    super.key,
    required this.topUsers,
    required this.onViewFull,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Leaderboard',
                style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                  color: AppTheme.pureWhite,
                  fontWeight: FontWeight.bold,
                ),
              ),
              GestureDetector(
                onTap: onViewFull,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'View Full',
                      style: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
                        color: AppTheme.primaryCyan,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(width: 1.w),
                    CustomIconWidget(
                      iconName: 'arrow_forward_ios',
                      color: AppTheme.primaryCyan,
                      size: 14,
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppTheme.elevatedDark,
                  AppTheme.elevatedDark.withValues(alpha: 0.8),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: AppTheme.primaryCyan.withValues(alpha: 0.3),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.primaryCyan.withValues(alpha: 0.1),
                  blurRadius: 8,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Column(
              children: [
                // Podium display for top 3
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    if (topUsers.length > 1)
                      _PodiumPosition(user: topUsers[1], position: 2),
                    if (topUsers.isNotEmpty)
                      _PodiumPosition(user: topUsers[0], position: 1),
                    if (topUsers.length > 2)
                      _PodiumPosition(user: topUsers[2], position: 3),
                  ],
                ),
                SizedBox(height: 3.h),
                // Additional users list
                if (topUsers.length > 3) ...[
                  Divider(
                    color: AppTheme.primaryCyan.withValues(alpha: 0.3),
                    thickness: 1,
                  ),
                  SizedBox(height: 2.h),
                  ...topUsers.skip(3).take(2).map((user) {
                    final index = topUsers.indexOf(user);
                    return _LeaderboardListItem(
                      user: user,
                      position: index + 1,
                    );
                  }),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Podium position widget for top 3 users
class _PodiumPosition extends StatelessWidget {
  final Map<String, dynamic> user;
  final int position;

  const _PodiumPosition({
    required this.user,
    required this.position,
  });

  Color _getPositionColor(int position) {
    switch (position) {
      case 1:
        return AppTheme.amberOrange;
      case 2:
        return AppTheme.lightGray;
      case 3:
        return const Color(0xFFCD7F32); // Bronze
      default:
        return AppTheme.primaryCyan;
    }
  }

  double _getPodiumHeight(int position) {
    switch (position) {
      case 1:
        return 12.h;
      case 2:
        return 10.h;
      case 3:
        return 8.h;
      default:
        return 8.h;
    }
  }

  @override
  Widget build(BuildContext context) {
    final positionColor = _getPositionColor(position);
    final podiumHeight = _getPodiumHeight(position);

    return Column(
      children: [
        // User avatar and info
        Column(
          children: [
            Stack(
              children: [
                Container(
                  width: 15.w,
                  height: 15.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: positionColor,
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: positionColor.withValues(alpha: 0.3),
                        blurRadius: 8,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: CustomImageWidget(
                      imageUrl: user['avatar'] as String,
                      width: 15.w,
                      height: 15.w,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Positioned(
                  bottom: -2,
                  right: -2,
                  child: Container(
                    width: 6.w,
                    height: 6.w,
                    decoration: BoxDecoration(
                      color: positionColor,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: AppTheme.deepSpaceBlue,
                        width: 2,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        '$position',
                        style:
                            AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
                          color: AppTheme.deepSpaceBlue,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 1.h),
            Text(
              user['name'] as String,
              style: AppTheme.darkTheme.textTheme.labelMedium?.copyWith(
                color: AppTheme.pureWhite,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              '${user['xp']} XP',
              style: AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
                color: positionColor,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        SizedBox(height: 1.h),
        // Podium base
        Container(
          width: 20.w,
          height: podiumHeight,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                positionColor.withValues(alpha: 0.3),
                positionColor.withValues(alpha: 0.1),
              ],
            ),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(8),
              topRight: Radius.circular(8),
            ),
            border: Border.all(
              color: positionColor.withValues(alpha: 0.5),
              width: 1,
            ),
          ),
          child: Center(
            child: CustomIconWidget(
              iconName: position == 1 ? 'emoji_events' : 'military_tech',
              color: positionColor,
              size: position == 1 ? 32 : 24,
            ),
          ),
        ),
      ],
    );
  }
}

/// Leaderboard list item for positions 4+
class _LeaderboardListItem extends StatelessWidget {
  final Map<String, dynamic> user;
  final int position;

  const _LeaderboardListItem({
    required this.user,
    required this.position,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 1.h),
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: AppTheme.elevatedDark.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.primaryCyan.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 8.w,
            height: 8.w,
            decoration: BoxDecoration(
              color: AppTheme.primaryCyan.withValues(alpha: 0.2),
              shape: BoxShape.circle,
              border: Border.all(
                color: AppTheme.primaryCyan.withValues(alpha: 0.5),
                width: 1,
              ),
            ),
            child: Center(
              child: Text(
                '$position',
                style: AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
                  color: AppTheme.primaryCyan,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          SizedBox(width: 3.w),
          Container(
            width: 10.w,
            height: 10.w,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: AppTheme.primaryCyan.withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: ClipOval(
              child: CustomImageWidget(
                imageUrl: user['avatar'] as String,
                width: 10.w,
                height: 10.w,
                fit: BoxFit.cover,
              ),
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['name'] as String,
                  style: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
                    color: AppTheme.pureWhite,
                    fontWeight: FontWeight.bold,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  'Level ${user['level']}',
                  style: AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
                    color: AppTheme.lightGray,
                  ),
                ),
              ],
            ),
          ),
          Text(
            '${user['xp']} XP',
            style: AppTheme.darkTheme.textTheme.labelMedium?.copyWith(
              color: AppTheme.primaryCyan,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
