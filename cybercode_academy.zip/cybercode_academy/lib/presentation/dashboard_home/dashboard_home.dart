import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import './widgets/continue_learning_widget.dart';
import './widgets/daily_challenges_widget.dart';
import './widgets/greeting_header_widget.dart';
import './widgets/leaderboard_preview_widget.dart';
import './widgets/quick_lesson_selector_widget.dart';
import './widgets/recent_achievements_widget.dart';

/// Dashboard Home screen - Central cyberpunk command center
class DashboardHome extends StatefulWidget {
  const DashboardHome({super.key});

  @override
  State<DashboardHome> createState() => _DashboardHomeState();
}

class _DashboardHomeState extends State<DashboardHome>
    with TickerProviderStateMixin {
  late AnimationController _matrixController;
  late Animation<double> _matrixAnimation;
  bool _isRefreshing = false;
  DateTime _lastSyncTime = DateTime.now();

  // Mock user data
  final Map<String, dynamic> _userData = {
    "name": "Alex Chen",
    "avatar":
        "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
    "level": 12,
    "currentXP": 2850,
    "maxXP": 3500,
    "streakCount": 7,
  };

  // Mock current lesson data
  final Map<String, dynamic> _currentLesson = {
    "id": 1,
    "title": "Advanced Flutter Animations",
    "category": "Mobile Development",
    "icon": "animation",
    "progress": 65,
    "completedSteps": 13,
    "totalSteps": 20,
  };

  // Mock daily challenges data
  final List<Map<String, dynamic>> _dailyChallenges = [
    {
      "id": 1,
      "title": "Binary Tree Traversal",
      "description": "Implement in-order traversal for a binary tree structure",
      "difficulty": "Medium",
      "xpReward": 150,
      "duration": "15 min",
      "completed": false,
    },
    {
      "id": 2,
      "title": "CSS Grid Layout",
      "description":
          "Create a responsive grid layout using CSS Grid properties",
      "difficulty": "Easy",
      "xpReward": 100,
      "duration": "10 min",
      "completed": true,
    },
    {
      "id": 3,
      "title": "API Integration",
      "description": "Connect to REST API and handle error responses properly",
      "difficulty": "Hard",
      "xpReward": 250,
      "duration": "25 min",
      "completed": false,
    },
  ];

  // Mock recent achievements data
  final List<Map<String, dynamic>> _recentAchievements = [
    {
      "id": 1,
      "title": "Code Warrior",
      "icon": "code",
      "rarity": "Epic",
      "isNew": true,
    },
    {
      "id": 2,
      "title": "Bug Hunter",
      "icon": "bug_report",
      "rarity": "Rare",
      "isNew": false,
    },
    {
      "id": 3,
      "title": "Speed Coder",
      "icon": "flash_on",
      "rarity": "Common",
      "isNew": true,
    },
    {
      "id": 4,
      "title": "Team Player",
      "icon": "group",
      "rarity": "Legendary",
      "isNew": false,
    },
  ];

  // Mock leaderboard data
  final List<Map<String, dynamic>> _topUsers = [
    {
      "id": 1,
      "name": "Sarah Kim",
      "avatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "level": 18,
      "xp": 4250,
    },
    {
      "id": 2,
      "name": "Mike Johnson",
      "avatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "level": 16,
      "xp": 3890,
    },
    {
      "id": 3,
      "name": "Emma Davis",
      "avatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "level": 15,
      "xp": 3650,
    },
    {
      "id": 4,
      "name": "James Wilson",
      "avatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "level": 14,
      "xp": 3420,
    },
    {
      "id": 5,
      "name": "Lisa Brown",
      "avatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "level": 13,
      "xp": 3180,
    },
  ];

  // Mock quick lessons data
  final List<Map<String, dynamic>> _quickLessons = [
    {
      "id": 1,
      "title": "Flutter State Management",
      "category": "Mobile Development",
      "description":
          "Learn about different state management solutions in Flutter",
      "difficulty": "Intermediate",
      "icon": "widgets",
      "progress": 0,
      "duration": "45 min",
      "xpReward": 200,
    },
    {
      "id": 2,
      "title": "JavaScript Promises",
      "category": "Web Development",
      "description":
          "Master asynchronous programming with Promises and async/await",
      "difficulty": "Beginner",
      "icon": "code",
      "progress": 25,
      "duration": "30 min",
      "xpReward": 150,
    },
    {
      "id": 3,
      "title": "Database Design Patterns",
      "category": "Backend Development",
      "description":
          "Explore common database design patterns and best practices",
      "difficulty": "Advanced",
      "icon": "storage",
      "progress": 100,
      "duration": "60 min",
      "xpReward": 300,
    },
    {
      "id": 4,
      "title": "UI/UX Principles",
      "category": "Design",
      "description":
          "Fundamental principles of user interface and experience design",
      "difficulty": "Beginner",
      "icon": "design_services",
      "progress": 50,
      "duration": "40 min",
      "xpReward": 180,
    },
  ];

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
  }

  void _initializeAnimations() {
    _matrixController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _matrixAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _matrixController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _matrixController.dispose();
    super.dispose();
  }

  Future<void> _handleRefresh() async {
    if (_isRefreshing) return;

    setState(() {
      _isRefreshing = true;
    });

    HapticFeedback.lightImpact();
    _matrixController.forward().then((_) {
      _matrixController.reverse();
    });

    // Simulate data refresh
    await Future.delayed(const Duration(milliseconds: 1500));

    setState(() {
      _isRefreshing = false;
      _lastSyncTime = DateTime.now();
    });

    HapticFeedback.selectionClick();
  }

  void _handleContinueLearning() {
    HapticFeedback.lightImpact();
    Navigator.pushNamed(context, '/lesson-detail');
  }

  void _handleChallengesTap(Map<String, dynamic> challenge) {
    HapticFeedback.lightImpact();
    Navigator.pushNamed(context, '/code-editor');
  }

  void _handleViewAllAchievements() {
    HapticFeedback.lightImpact();
    Navigator.pushNamed(context, '/profile-dashboard');
  }

  void _handleViewFullLeaderboard() {
    HapticFeedback.lightImpact();
    // Navigate to full leaderboard screen
  }

  void _handleQuickLessonSelector() {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => QuickLessonSelectorWidget(
        lessons: _quickLessons,
        onLessonSelected: _handleLessonSelected,
      ),
    );
  }

  void _handleLessonSelected(Map<String, dynamic> lesson) {
    HapticFeedback.lightImpact();
    Navigator.pushNamed(context, '/lesson-detail');
  }

  void _handleBottomNavTap(int index) {
    HapticFeedback.lightImpact();
    // Navigation is handled by CustomBottomBar
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.deepSpaceBlue,
      appBar: CustomAppBar.dashboard(
        title: 'CyberCode Academy',
        actions: [
          IconButton(
            icon: Stack(
              children: [
                CustomIconWidget(
                  iconName: 'notifications_outlined',
                  color: AppTheme.primaryCyan,
                  size: 24,
                ),
                Positioned(
                  right: 0,
                  top: 0,
                  child: Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: AppTheme.hotPink,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.hotPink.withValues(alpha: 0.5),
                          blurRadius: 4,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            onPressed: () {
              HapticFeedback.lightImpact();
              // Handle notifications
            },
            tooltip: 'Notifications',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _handleRefresh,
        color: AppTheme.primaryCyan,
        backgroundColor: AppTheme.elevatedDark,
        child: Stack(
          children: [
            // Main content
            SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              child: SafeArea(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 2.h),
                    // Greeting header
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: GreetingHeaderWidget(
                        userName: _userData['name'] as String,
                        userAvatar: _userData['avatar'] as String,
                        currentLevel: _userData['level'] as int,
                        currentXP: _userData['currentXP'] as int,
                        maxXP: _userData['maxXP'] as int,
                        streakCount: _userData['streakCount'] as int,
                      ),
                    ),
                    SizedBox(height: 4.h),
                    // Continue learning section
                    ContinueLearningWidget(
                      currentLesson: _currentLesson,
                      onTap: _handleContinueLearning,
                    ),
                    SizedBox(height: 4.h),
                    // Daily challenges section
                    DailyChallengesWidget(
                      challenges: _dailyChallenges,
                      onChallengeTap: _handleChallengesTap,
                    ),
                    SizedBox(height: 4.h),
                    // Recent achievements section
                    RecentAchievementsWidget(
                      achievements: _recentAchievements,
                      onViewAll: _handleViewAllAchievements,
                    ),
                    SizedBox(height: 4.h),
                    // Leaderboard preview section
                    LeaderboardPreviewWidget(
                      topUsers: _topUsers,
                      onViewFull: _handleViewFullLeaderboard,
                    ),
                    SizedBox(height: 4.h),
                    // Last sync info
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomIconWidget(
                            iconName: 'sync',
                            color: AppTheme.lightGray.withValues(alpha: 0.7),
                            size: 16,
                          ),
                          SizedBox(width: 2.w),
                          Text(
                            'Last synced: ${_formatSyncTime(_lastSyncTime)}',
                            style: AppTheme.darkTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme.lightGray.withValues(alpha: 0.7),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 10.h), // Bottom padding for FAB
                  ],
                ),
              ),
            ),
            // Matrix loading animation overlay
            if (_isRefreshing)
              AnimatedBuilder(
                animation: _matrixAnimation,
                builder: (context, child) {
                  return Container(
                    color: AppTheme.deepSpaceBlue.withValues(
                      alpha: _matrixAnimation.value * 0.8,
                    ),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 20.w,
                            height: 20.w,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: AppTheme.primaryCyan.withValues(
                                  alpha: _matrixAnimation.value,
                                ),
                                width: 2,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: AppTheme.primaryCyan.withValues(
                                    alpha: _matrixAnimation.value * 0.5,
                                  ),
                                  blurRadius: 16,
                                  spreadRadius: 4,
                                ),
                              ],
                            ),
                            child: Center(
                              child: CustomIconWidget(
                                iconName: 'refresh',
                                color: AppTheme.primaryCyan.withValues(
                                  alpha: _matrixAnimation.value,
                                ),
                                size: 32,
                              ),
                            ),
                          ),
                          SizedBox(height: 3.h),
                          Text(
                            'Syncing data...',
                            style: AppTheme.darkTheme.textTheme.titleMedium
                                ?.copyWith(
                              color: AppTheme.primaryCyan.withValues(
                                alpha: _matrixAnimation.value,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _handleQuickLessonSelector,
        backgroundColor: AppTheme.primaryCyan,
        foregroundColor: AppTheme.deepSpaceBlue,
        child: CustomIconWidget(
          iconName: 'school',
          color: AppTheme.deepSpaceBlue,
          size: 28,
        ),
      ),
      bottomNavigationBar: CustomBottomBar(
        currentIndex: 0,
        onTap: _handleBottomNavTap,
        variant: CustomBottomBarVariant.primary,
      ),
    );
  }

  String _formatSyncTime(DateTime time) {
    final now = DateTime.now();
    final difference = now.difference(time);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }
}
