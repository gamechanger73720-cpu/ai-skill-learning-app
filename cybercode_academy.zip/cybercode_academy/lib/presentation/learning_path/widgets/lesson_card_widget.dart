import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class LessonCardWidget extends StatefulWidget {
  final Map<String, dynamic> lessonData;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;

  const LessonCardWidget({
    super.key,
    required this.lessonData,
    required this.onTap,
    this.onLongPress,
  });

  @override
  State<LessonCardWidget> createState() => _LessonCardWidgetState();
}

class _LessonCardWidgetState extends State<LessonCardWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _connectionController;
  late Animation<double> _connectionAnimation;

  @override
  void initState() {
    super.initState();
    _connectionController = AnimationController(
      duration: const Duration(milliseconds: 2500),
      vsync: this,
    );
    _connectionAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _connectionController,
      curve: Curves.easeInOut,
    ));

    if (widget.lessonData['isUnlocked'] as bool) {
      _connectionController.repeat();
    }
  }

  @override
  void dispose() {
    _connectionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final String title = widget.lessonData['title'] as String;
    final String description = widget.lessonData['description'] as String;
    final bool isUnlocked = widget.lessonData['isUnlocked'] as bool;
    final bool isCompleted = widget.lessonData['isCompleted'] as bool;
    final String duration = widget.lessonData['duration'] as String;
    final int xpReward = widget.lessonData['xpReward'] as int;
    final String type = widget.lessonData['type'] as String;

    Color statusColor = _getStatusColor(isCompleted, isUnlocked);
    IconData statusIcon = _getStatusIcon(isCompleted, isUnlocked);

    return GestureDetector(
      onTap: isUnlocked
          ? () {
              HapticFeedback.lightImpact();
              widget.onTap();
            }
          : null,
      onLongPress: isUnlocked
          ? () {
              HapticFeedback.mediumImpact();
              widget.onLongPress?.call();
            }
          : null,
      child: AnimatedBuilder(
        animation: _connectionAnimation,
        builder: (context, child) {
          return Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: isUnlocked
                  ? AppTheme.elevatedDark
                  : AppTheme.elevatedDark.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isUnlocked
                    ? statusColor.withValues(
                        alpha: isCompleted
                            ? 0.8
                            : _connectionAnimation.value * 0.6 + 0.2,
                      )
                    : AppTheme.lightGray.withValues(alpha: 0.3),
                width: isCompleted ? 2.0 : 1.0,
              ),
              boxShadow: isUnlocked
                  ? [
                      BoxShadow(
                        color: statusColor.withValues(
                          alpha: isCompleted
                              ? 0.3
                              : _connectionAnimation.value * 0.2,
                        ),
                        blurRadius: 8.0,
                        spreadRadius: 1.0,
                      ),
                    ]
                  : null,
            ),
            child: Padding(
              padding: EdgeInsets.all(4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header with status and type
                  Row(
                    children: [
                      // Status icon with holographic effect
                      Container(
                        padding: EdgeInsets.all(2.w),
                        decoration: BoxDecoration(
                          color: statusColor.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: statusColor.withValues(alpha: 0.5),
                            width: 1.0,
                          ),
                        ),
                        child: CustomIconWidget(
                          iconName: _getIconName(statusIcon),
                          color: statusColor,
                          size: 20,
                        ),
                      ),

                      SizedBox(width: 3.w),

                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              title,
                              style: AppTheme.darkTheme.textTheme.titleMedium
                                  ?.copyWith(
                                color: isUnlocked
                                    ? AppTheme.pureWhite
                                    : AppTheme.lightGray.withValues(alpha: 0.6),
                                fontWeight: FontWeight.w600,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            SizedBox(height: 0.5.h),
                            Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 2.w, vertical: 0.5.h),
                              decoration: BoxDecoration(
                                color:
                                    _getTypeColor(type).withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(
                                  color: _getTypeColor(type)
                                      .withValues(alpha: 0.5),
                                  width: 1.0,
                                ),
                              ),
                              child: Text(
                                type.toUpperCase(),
                                style: AppTheme.darkTheme.textTheme.labelSmall
                                    ?.copyWith(
                                  color: _getTypeColor(type),
                                  fontWeight: FontWeight.w600,
                                  fontSize: 9.sp,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // XP reward badge
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 2.w, vertical: 1.h),
                        decoration: BoxDecoration(
                          color: AppTheme.neonGreen.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: AppTheme.neonGreen.withValues(alpha: 0.5),
                            width: 1.0,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CustomIconWidget(
                              iconName: 'stars',
                              color: AppTheme.neonGreen,
                              size: 14,
                            ),
                            SizedBox(width: 1.w),
                            Text(
                              '+$xpReward XP',
                              style: AppTheme.darkTheme.textTheme.labelSmall
                                  ?.copyWith(
                                color: AppTheme.neonGreen,
                                fontWeight: FontWeight.w700,
                                fontSize: 10.sp,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 2.h),

                  // Description
                  Text(
                    description,
                    style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                      color: isUnlocked
                          ? AppTheme.lightGray
                          : AppTheme.lightGray.withValues(alpha: 0.5),
                      height: 1.4,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),

                  SizedBox(height: 2.h),

                  // Footer with duration and circuit connection
                  Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'access_time',
                        color: isUnlocked
                            ? AppTheme.lightGray
                            : AppTheme.lightGray.withValues(alpha: 0.5),
                        size: 16,
                      ),
                      SizedBox(width: 2.w),
                      Text(
                        duration,
                        style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                          color: isUnlocked
                              ? AppTheme.lightGray
                              : AppTheme.lightGray.withValues(alpha: 0.5),
                          fontWeight: FontWeight.w500,
                        ),
                      ),

                      const Spacer(),

                      // Circuit connection indicator
                      if (isUnlocked && !isCompleted)
                        Container(
                          width: 8.w,
                          height: 2,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                statusColor.withValues(
                                  alpha: _connectionAnimation.value * 0.8,
                                ),
                                Colors.transparent,
                              ],
                              stops: [
                                0.0,
                                _connectionAnimation.value,
                                1.0,
                              ],
                            ),
                          ),
                        ),

                      if (isCompleted)
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 2.w, vertical: 0.5.h),
                          decoration: BoxDecoration(
                            color: AppTheme.neonGreen.withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                              color: AppTheme.neonGreen,
                              width: 1.0,
                            ),
                          ),
                          child: Text(
                            'COMPLETED',
                            style: AppTheme.darkTheme.textTheme.labelSmall
                                ?.copyWith(
                              color: AppTheme.neonGreen,
                              fontWeight: FontWeight.w700,
                              fontSize: 9.sp,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Color _getStatusColor(bool isCompleted, bool isUnlocked) {
    if (isCompleted) return AppTheme.neonGreen;
    if (isUnlocked) return AppTheme.primaryCyan;
    return AppTheme.lightGray;
  }

  IconData _getStatusIcon(bool isCompleted, bool isUnlocked) {
    if (isCompleted) return Icons.check_circle;
    if (isUnlocked) return Icons.play_circle_outline;
    return Icons.lock;
  }

  String _getIconName(IconData icon) {
    if (icon == Icons.check_circle) return 'check_circle';
    if (icon == Icons.play_circle_outline) return 'play_circle_outline';
    return 'lock';
  }

  Color _getTypeColor(String type) {
    switch (type.toLowerCase()) {
      case 'video':
        return AppTheme.hotPink;
      case 'coding':
        return AppTheme.primaryCyan;
      case 'quiz':
        return AppTheme.amberOrange;
      case 'project':
        return AppTheme.neonGreen;
      default:
        return AppTheme.lightGray;
    }
  }
}
