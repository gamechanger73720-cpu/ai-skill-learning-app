import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SkillTrackCard extends StatefulWidget {
  final Map<String, dynamic> trackData;
  final VoidCallback onTap;

  const SkillTrackCard({
    super.key,
    required this.trackData,
    required this.onTap,
  });

  @override
  State<SkillTrackCard> createState() => _SkillTrackCardState();
}

class _SkillTrackCardState extends State<SkillTrackCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
    _glowAnimation = Tween<double>(
      begin: 0.3,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _glowController,
      curve: Curves.easeInOut,
    ));
    _glowController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final String title = widget.trackData['title'] as String;
    final String description = widget.trackData['description'] as String;
    final double progress = (widget.trackData['progress'] as num).toDouble();
    final String estimatedTime = widget.trackData['estimatedTime'] as String;
    final String difficulty = widget.trackData['difficulty'] as String;
    final int totalLessons = widget.trackData['totalLessons'] as int;
    final int completedLessons = widget.trackData['completedLessons'] as int;
    final String iconName = widget.trackData['iconName'] as String;

    Color difficultyColor = _getDifficultyColor(difficulty);
    Color trackColor = _getTrackColor(title);

    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        widget.onTap();
      },
      child: AnimatedBuilder(
        animation: _glowAnimation,
        builder: (context, child) {
          return Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: AppTheme.elevatedDark,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: trackColor.withValues(alpha: _glowAnimation.value * 0.8),
                width: 2.0,
              ),
              boxShadow: [
                BoxShadow(
                  color:
                      trackColor.withValues(alpha: _glowAnimation.value * 0.3),
                  blurRadius: 16.0,
                  spreadRadius: 2.0,
                ),
                BoxShadow(
                  color: AppTheme.shadowCyan,
                  blurRadius: 8.0,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Padding(
              padding: EdgeInsets.all(4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header with icon and difficulty badge
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(2.w),
                        decoration: BoxDecoration(
                          color: trackColor.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: trackColor.withValues(alpha: 0.5),
                            width: 1.0,
                          ),
                        ),
                        child: CustomIconWidget(
                          iconName: iconName,
                          color: trackColor,
                          size: 24,
                        ),
                      ),
                      SizedBox(width: 3.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              title,
                              style: AppTheme.darkTheme.textTheme.titleLarge
                                  ?.copyWith(
                                color: AppTheme.pureWhite,
                                fontWeight: FontWeight.w700,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            SizedBox(height: 0.5.h),
                            Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 2.w, vertical: 0.5.h),
                              decoration: BoxDecoration(
                                color: difficultyColor.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: difficultyColor.withValues(alpha: 0.6),
                                  width: 1.0,
                                ),
                              ),
                              child: Text(
                                difficulty.toUpperCase(),
                                style: AppTheme.darkTheme.textTheme.labelSmall
                                    ?.copyWith(
                                  color: difficultyColor,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.8,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 2.h),

                  // Description
                  Text(
                    description,
                    style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                      color: AppTheme.lightGray,
                      height: 1.4,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),

                  SizedBox(height: 2.h),

                  // Progress section
                  Row(
                    children: [
                      Expanded(
                        flex: 2,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Progress',
                                  style: AppTheme
                                      .darkTheme.textTheme.labelMedium
                                      ?.copyWith(
                                    color: AppTheme.lightGray,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                Text(
                                  '${(progress * 100).toInt()}%',
                                  style: AppTheme
                                      .darkTheme.textTheme.labelMedium
                                      ?.copyWith(
                                    color: trackColor,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 1.h),
                            LinearPercentIndicator(
                              padding: EdgeInsets.zero,
                              lineHeight: 6,
                              percent: progress,
                              backgroundColor: AppTheme.elevatedDark,
                              progressColor: trackColor,
                              barRadius: const Radius.circular(3),
                              animation: true,
                              animationDuration: 1000,
                            ),
                            SizedBox(height: 1.h),
                            Text(
                              '$completedLessons of $totalLessons lessons',
                              style: AppTheme.darkTheme.textTheme.bodySmall
                                  ?.copyWith(
                                color:
                                    AppTheme.lightGray.withValues(alpha: 0.8),
                              ),
                            ),
                          ],
                        ),
                      ),

                      SizedBox(width: 4.w),

                      // Circular progress indicator
                      CircularPercentIndicator(
                        radius: 8.w,
                        lineWidth: 4.0,
                        percent: progress,
                        center: Text(
                          '${(progress * 100).toInt()}%',
                          style: AppTheme.darkTheme.textTheme.labelMedium
                              ?.copyWith(
                            color: trackColor,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        backgroundColor: AppTheme.elevatedDark,
                        progressColor: trackColor,
                        circularStrokeCap: CircularStrokeCap.round,
                        animation: true,
                        animationDuration: 1000,
                      ),
                    ],
                  ),

                  SizedBox(height: 2.h),

                  // Footer with time estimate
                  Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'access_time',
                        color: AppTheme.lightGray,
                        size: 16,
                      ),
                      SizedBox(width: 2.w),
                      Text(
                        estimatedTime,
                        style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                          color: AppTheme.lightGray,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 3.w, vertical: 1.h),
                        decoration: BoxDecoration(
                          color: trackColor.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: trackColor.withValues(alpha: 0.3),
                            width: 1.0,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'Continue',
                              style: AppTheme.darkTheme.textTheme.labelMedium
                                  ?.copyWith(
                                color: trackColor,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            SizedBox(width: 1.w),
                            CustomIconWidget(
                              iconName: 'arrow_forward_ios',
                              color: trackColor,
                              size: 12,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Color _getDifficultyColor(String difficulty) {
    switch (difficulty.toLowerCase()) {
      case 'beginner':
        return AppTheme.neonGreen;
      case 'intermediate':
        return AppTheme.amberOrange;
      case 'advanced':
        return AppTheme.brightRed;
      default:
        return AppTheme.primaryCyan;
    }
  }

  Color _getTrackColor(String title) {
    switch (title.toLowerCase()) {
      case 'programming fundamentals':
        return AppTheme.primaryCyan;
      case 'web development':
        return AppTheme.neonGreen;
      case 'mobile apps':
        return AppTheme.hotPink;
      case 'freelancing skills':
        return AppTheme.amberOrange;
      default:
        return AppTheme.primaryCyan;
    }
  }
}
