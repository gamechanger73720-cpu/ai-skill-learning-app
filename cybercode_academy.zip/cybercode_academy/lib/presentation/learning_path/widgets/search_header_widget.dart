import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SearchHeaderWidget extends StatefulWidget {
  final TextEditingController searchController;
  final VoidCallback onFilterTap;
  final ValueChanged<String> onSearchChanged;

  const SearchHeaderWidget({
    super.key,
    required this.searchController,
    required this.onFilterTap,
    required this.onSearchChanged,
  });

  @override
  State<SearchHeaderWidget> createState() => _SearchHeaderWidgetState();
}

class _SearchHeaderWidgetState extends State<SearchHeaderWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _circuitController;
  late Animation<double> _circuitAnimation;
  bool _isSearchFocused = false;

  @override
  void initState() {
    super.initState();
    _circuitController = AnimationController(
      duration: const Duration(milliseconds: 3000),
      vsync: this,
    );
    _circuitAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _circuitController,
      curve: Curves.easeInOut,
    ));
    _circuitController.repeat();
  }

  @override
  void dispose() {
    _circuitController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: AppTheme.elevatedDark,
        border: Border(
          bottom: BorderSide(
            color: AppTheme.borderCyan.withValues(alpha: 0.3),
            width: 1.0,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowCyan,
            blurRadius: 8.0,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            // Title
            Text(
              'Learning Paths',
              style: AppTheme.darkTheme.textTheme.headlineSmall?.copyWith(
                color: AppTheme.pureWhite,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.0,
              ),
            ),

            SizedBox(height: 2.h),

            // Search bar with circuit elements
            Row(
              children: [
                Expanded(
                  child: AnimatedBuilder(
                    animation: _circuitAnimation,
                    builder: (context, child) {
                      return Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: _isSearchFocused
                                ? AppTheme.primaryCyan
                                : AppTheme.borderCyan.withValues(
                                    alpha:
                                        0.5 + (_circuitAnimation.value * 0.3),
                                  ),
                            width: _isSearchFocused ? 2.0 : 1.0,
                          ),
                          boxShadow: _isSearchFocused
                              ? [
                                  BoxShadow(
                                    color: AppTheme.primaryCyan
                                        .withValues(alpha: 0.3),
                                    blurRadius: 8.0,
                                    spreadRadius: 1.0,
                                  ),
                                ]
                              : null,
                        ),
                        child: TextField(
                          controller: widget.searchController,
                          onChanged: widget.onSearchChanged,
                          onTap: () {
                            setState(() => _isSearchFocused = true);
                            HapticFeedback.lightImpact();
                          },
                          onTapOutside: (_) {
                            setState(() => _isSearchFocused = false);
                            FocusScope.of(context).unfocus();
                          },
                          style:
                              AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                            color: AppTheme.pureWhite,
                          ),
                          decoration: InputDecoration(
                            hintText: 'Search learning paths...',
                            hintStyle: AppTheme.darkTheme.textTheme.bodyMedium
                                ?.copyWith(
                              color: AppTheme.lightGray.withValues(alpha: 0.7),
                            ),
                            prefixIcon: Padding(
                              padding: EdgeInsets.all(3.w),
                              child: CustomIconWidget(
                                iconName: 'search',
                                color: _isSearchFocused
                                    ? AppTheme.primaryCyan
                                    : AppTheme.lightGray,
                                size: 20,
                              ),
                            ),
                            suffixIcon: widget.searchController.text.isNotEmpty
                                ? GestureDetector(
                                    onTap: () {
                                      widget.searchController.clear();
                                      widget.onSearchChanged('');
                                      HapticFeedback.lightImpact();
                                    },
                                    child: Padding(
                                      padding: EdgeInsets.all(3.w),
                                      child: CustomIconWidget(
                                        iconName: 'clear',
                                        color: AppTheme.lightGray,
                                        size: 20,
                                      ),
                                    ),
                                  )
                                : null,
                            border: InputBorder.none,
                            enabledBorder: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            contentPadding: EdgeInsets.symmetric(
                              horizontal: 4.w,
                              vertical: 2.h,
                            ),
                            filled: true,
                            fillColor:
                                AppTheme.deepSpaceBlue.withValues(alpha: 0.5),
                          ),
                        ),
                      );
                    },
                  ),
                ),

                SizedBox(width: 3.w),

                // Filter button with circuit styling
                GestureDetector(
                  onTap: () {
                    HapticFeedback.lightImpact();
                    widget.onFilterTap();
                  },
                  child: AnimatedBuilder(
                    animation: _circuitAnimation,
                    builder: (context, child) {
                      return Container(
                        padding: EdgeInsets.all(3.w),
                        decoration: BoxDecoration(
                          color: AppTheme.elevatedDark,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: AppTheme.borderCyan.withValues(
                              alpha: 0.5 + (_circuitAnimation.value * 0.3),
                            ),
                            width: 1.0,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: AppTheme.primaryCyan.withValues(
                                alpha: _circuitAnimation.value * 0.2,
                              ),
                              blurRadius: 6.0,
                              spreadRadius: 1.0,
                            ),
                          ],
                        ),
                        child: CustomIconWidget(
                          iconName: 'tune',
                          color: AppTheme.primaryCyan,
                          size: 24,
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),

            SizedBox(height: 1.h),

            // Circuit pattern decoration
            AnimatedBuilder(
              animation: _circuitAnimation,
              builder: (context, child) {
                return Container(
                  height: 2,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.transparent,
                        AppTheme.primaryCyan.withValues(
                          alpha: _circuitAnimation.value * 0.5,
                        ),
                        Colors.transparent,
                      ],
                      stops: [
                        0.0,
                        _circuitAnimation.value,
                        1.0,
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
