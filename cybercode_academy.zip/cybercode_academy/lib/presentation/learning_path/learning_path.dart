import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_bottom_bar.dart';
import './widgets/filter_chip_widget.dart';
import './widgets/lesson_card_widget.dart';
import './widgets/search_header_widget.dart';
import './widgets/skill_track_card.dart';

class LearningPath extends StatefulWidget {
  const LearningPath({super.key});

  @override
  State<LearningPath> createState() => _LearningPathState();
}

class _LearningPathState extends State<LearningPath>
    with TickerProviderStateMixin {
  late TabController _tabController;
  late AnimationController _fabController;
  late Animation<double> _fabAnimation;

  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  String _searchQuery = '';
  List<String> _activeFilters = [];
  bool _isOfflineMode = false;
  bool _isRefreshing = false;
  int _selectedTrackIndex = -1;

  // Mock data for skill tracks
  final List<Map<String, dynamic>> _skillTracks = [
    {
      'id': 1,
      'title': 'Programming Fundamentals',
      'description':
          'Master the core concepts of programming with hands-on exercises and real-world projects.',
      'progress': 0.65,
      'estimatedTime': '8-12 weeks',
      'difficulty': 'Beginner',
      'totalLessons': 24,
      'completedLessons': 16,
      'iconName': 'code',
    },
    {
      'id': 2,
      'title': 'Web Development',
      'description':
          'Build modern web applications using HTML, CSS, JavaScript, and popular frameworks.',
      'progress': 0.35,
      'estimatedTime': '12-16 weeks',
      'difficulty': 'Intermediate',
      'totalLessons': 32,
      'completedLessons': 11,
      'iconName': 'web',
    },
    {
      'id': 3,
      'title': 'Mobile Apps',
      'description':
          'Create cross-platform mobile applications with Flutter and native development.',
      'progress': 0.15,
      'estimatedTime': '10-14 weeks',
      'difficulty': 'Intermediate',
      'totalLessons': 28,
      'completedLessons': 4,
      'iconName': 'phone_android',
    },
    {
      'id': 4,
      'title': 'Freelancing Skills',
      'description':
          'Learn essential business skills for successful freelancing and client management.',
      'progress': 0.80,
      'estimatedTime': '6-8 weeks',
      'difficulty': 'Advanced',
      'totalLessons': 20,
      'completedLessons': 16,
      'iconName': 'work',
    },
  ];

  // Mock data for lessons
  final List<Map<String, dynamic>> _lessons = [
    {
      'id': 1,
      'title': 'Variables and Data Types',
      'description':
          'Learn about different data types and how to declare variables in programming.',
      'isUnlocked': true,
      'isCompleted': true,
      'duration': '15 min',
      'xpReward': 50,
      'type': 'Video',
      'trackId': 1,
    },
    {
      'id': 2,
      'title': 'Control Structures',
      'description':
          'Master if statements, loops, and conditional logic in programming.',
      'isUnlocked': true,
      'isCompleted': true,
      'duration': '20 min',
      'xpReward': 75,
      'type': 'Coding',
      'trackId': 1,
    },
    {
      'id': 3,
      'title': 'Functions and Methods',
      'description':
          'Understand how to create reusable code blocks with functions and methods.',
      'isUnlocked': true,
      'isCompleted': false,
      'duration': '25 min',
      'xpReward': 100,
      'type': 'Project',
      'trackId': 1,
    },
    {
      'id': 4,
      'title': 'Object-Oriented Programming',
      'description':
          'Dive into classes, objects, inheritance, and polymorphism concepts.',
      'isUnlocked': false,
      'isCompleted': false,
      'duration': '30 min',
      'xpReward': 125,
      'type': 'Quiz',
      'trackId': 1,
    },
  ];

  // Filter options
  final Map<String, int> _filterOptions = {
    'Beginner': 8,
    'Intermediate': 12,
    'Advanced': 6,
    'Video': 15,
    'Coding': 18,
    'Quiz': 10,
    'Project': 8,
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _fabController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _fabAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fabController,
      curve: Curves.easeInOut,
    ));

    _checkConnectivity();
    _fabController.forward();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _fabController.dispose();
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _checkConnectivity() async {
    final connectivityResult = await Connectivity().checkConnectivity();
    setState(() {
      _isOfflineMode = connectivityResult == ConnectivityResult.none;
    });
  }

  Future<void> _refreshContent() async {
    if (_isRefreshing) return;

    setState(() => _isRefreshing = true);
    HapticFeedback.lightImpact();

    // Simulate network request
    await Future.delayed(const Duration(seconds: 2));

    await _checkConnectivity();

    setState(() => _isRefreshing = false);

    if (!_isOfflineMode) {
      Fluttertoast.showToast(
        msg: "Progress synced successfully!",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: AppTheme.neonGreen,
        textColor: AppTheme.deepSpaceBlue,
      );
    }
  }

  void _onSearchChanged(String query) {
    setState(() => _searchQuery = query.toLowerCase());
  }

  void _toggleFilter(String filter) {
    setState(() {
      if (_activeFilters.contains(filter)) {
        _activeFilters.remove(filter);
      } else {
        _activeFilters.add(filter);
      }
    });
    HapticFeedback.lightImpact();
  }

  void _showFilterModal() {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.elevatedDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Filter Learning Paths',
              style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                color: AppTheme.pureWhite,
                fontWeight: FontWeight.w700,
              ),
            ),
            SizedBox(height: 2.h),
            Wrap(
              spacing: 2.w,
              runSpacing: 1.h,
              children: _filterOptions.entries.map((entry) {
                return FilterChipWidget(
                  label: entry.key,
                  count: entry.value,
                  isSelected: _activeFilters.contains(entry.key),
                  onTap: () => _toggleFilter(entry.key),
                );
              }).toList(),
            ),
            SizedBox(height: 3.h),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() => _activeFilters.clear());
                      Navigator.pop(context);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.elevatedDark,
                      foregroundColor: AppTheme.lightGray,
                      side: BorderSide(color: AppTheme.borderCyan),
                    ),
                    child: const Text('Clear All'),
                  ),
                ),
                SizedBox(width: 4.w),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Apply Filters'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showCustomPathBuilder() {
    HapticFeedback.mediumImpact();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.elevatedDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: AppTheme.borderCyan),
        ),
        title: Text(
          'Custom Path Builder',
          style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
            color: AppTheme.primaryCyan,
            fontWeight: FontWeight.w700,
          ),
        ),
        content: Text(
          'Create your personalized learning sequence based on your goals and interests. This feature will be available soon!',
          style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.lightGray,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Got it'),
          ),
        ],
      ),
    );
  }

  void _showLessonQuickActions(Map<String, dynamic> lesson) {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.elevatedDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              lesson['title'] as String,
              style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                color: AppTheme.pureWhite,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 3.h),
            _buildQuickActionTile(
              icon: 'favorite_border',
              title: 'Add to Favorites',
              onTap: () {
                Navigator.pop(context);
                Fluttertoast.showToast(msg: "Added to favorites!");
              },
            ),
            _buildQuickActionTile(
              icon: 'download',
              title: 'Download for Offline',
              onTap: () {
                Navigator.pop(context);
                Fluttertoast.showToast(msg: "Download started!");
              },
            ),
            _buildQuickActionTile(
              icon: 'share',
              title: 'Share with Friends',
              onTap: () {
                Navigator.pop(context);
                Fluttertoast.showToast(msg: "Sharing options opened!");
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActionTile({
    required String icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: icon,
        color: AppTheme.primaryCyan,
        size: 24,
      ),
      title: Text(
        title,
        style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
          color: AppTheme.pureWhite,
        ),
      ),
      onTap: onTap,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
    );
  }

  List<Map<String, dynamic>> _getFilteredTracks() {
    return _skillTracks.where((track) {
      final matchesSearch = _searchQuery.isEmpty ||
          (track['title'] as String).toLowerCase().contains(_searchQuery) ||
          (track['description'] as String).toLowerCase().contains(_searchQuery);

      final matchesFilter = _activeFilters.isEmpty ||
          _activeFilters.contains(track['difficulty']);

      return matchesSearch && matchesFilter;
    }).toList();
  }

  List<Map<String, dynamic>> _getFilteredLessons() {
    return _lessons.where((lesson) {
      final matchesSearch = _searchQuery.isEmpty ||
          (lesson['title'] as String).toLowerCase().contains(_searchQuery) ||
          (lesson['description'] as String)
              .toLowerCase()
              .contains(_searchQuery);

      final matchesFilter =
          _activeFilters.isEmpty || _activeFilters.contains(lesson['type']);

      return matchesSearch && matchesFilter;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.deepSpaceBlue,
      body: Column(
        children: [
          // Offline mode indicator
          if (_isOfflineMode)
            Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(vertical: 1.h),
              color: AppTheme.amberOrange.withValues(alpha: 0.2),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomIconWidget(
                    iconName: 'wifi_off',
                    color: AppTheme.amberOrange,
                    size: 16,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Offline Mode - Cached content only',
                    style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.amberOrange,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),

          // Search header
          SearchHeaderWidget(
            searchController: _searchController,
            onFilterTap: _showFilterModal,
            onSearchChanged: _onSearchChanged,
          ),

          // Active filters
          if (_activeFilters.isNotEmpty)
            Container(
              height: 6.h,
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _activeFilters.length,
                itemBuilder: (context, index) {
                  final filter = _activeFilters[index];
                  return FilterChipWidget(
                    label: filter,
                    count: _filterOptions[filter] ?? 0,
                    isSelected: true,
                    onTap: () => _toggleFilter(filter),
                  );
                },
              ),
            ),

          // Tab bar
          Container(
            color: AppTheme.elevatedDark,
            child: TabBar(
              controller: _tabController,
              tabs: const [
                Tab(text: 'Skill Tracks'),
                Tab(text: 'All Lessons'),
              ],
              labelColor: AppTheme.primaryCyan,
              unselectedLabelColor: AppTheme.lightGray,
              indicatorColor: AppTheme.primaryCyan,
            ),
          ),

          // Content
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                // Skill Tracks Tab
                RefreshIndicator(
                  onRefresh: _refreshContent,
                  color: AppTheme.primaryCyan,
                  backgroundColor: AppTheme.elevatedDark,
                  child: ListView.builder(
                    controller: _scrollController,
                    physics: const AlwaysScrollableScrollPhysics(),
                    itemCount: _getFilteredTracks().length,
                    itemBuilder: (context, index) {
                      final track = _getFilteredTracks()[index];
                      return SkillTrackCard(
                        trackData: track,
                        onTap: () {
                          Navigator.pushNamed(context, '/lesson-detail');
                        },
                      );
                    },
                  ),
                ),

                // All Lessons Tab
                RefreshIndicator(
                  onRefresh: _refreshContent,
                  color: AppTheme.primaryCyan,
                  backgroundColor: AppTheme.elevatedDark,
                  child: ListView.builder(
                    controller: _scrollController,
                    physics: const AlwaysScrollableScrollPhysics(),
                    itemCount: _getFilteredLessons().length,
                    itemBuilder: (context, index) {
                      final lesson = _getFilteredLessons()[index];
                      return LessonCardWidget(
                        lessonData: lesson,
                        onTap: () {
                          Navigator.pushNamed(context, '/lesson-detail');
                        },
                        onLongPress: () => _showLessonQuickActions(lesson),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),

      // Floating Action Button
      floatingActionButton: ScaleTransition(
        scale: _fabAnimation,
        child: FloatingActionButton.extended(
          onPressed: _showCustomPathBuilder,
          backgroundColor: AppTheme.primaryCyan,
          foregroundColor: AppTheme.deepSpaceBlue,
          icon: CustomIconWidget(
            iconName: 'auto_awesome',
            color: AppTheme.deepSpaceBlue,
            size: 24,
          ),
          label: Text(
            'Custom Path',
            style: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
              color: AppTheme.deepSpaceBlue,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),

      // Bottom Navigation
      bottomNavigationBar: const CustomBottomBar(
        currentIndex: 1, // Learn tab active
      ),
    );
  }
}